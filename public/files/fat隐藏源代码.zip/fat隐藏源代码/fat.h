/*
 * fat.h -- FAT32 "目录项隐藏" 核心引擎（单头文件，函数全部 static，即插即用）
 *
 * 独立头文件库：任何其它程序只要 #include "fat.h" 即可复用下面的隐藏机制，
 * 不需要另外链接实现文件（本头文件本身含全部实现）。
 *
 * 设计（与 fat.cpp 交互工具配套）：
 *   在 FAT32 分区【根目录】里放一个固定名字的子目录（默认 FAT；重名则依次
 *   FAT1..FAT4），把要藏的文件放进去。随后：
 *     - “隐藏”：把根目录里该子目录项的 32 字节目录项【首字节改为 0xE5（删除
 *       标记）】；FAT 表与簇数据【完全不动】。因此簇项非 0 仍视为“已分配”，
 *       操作系统不会覆盖，目录链可 100% 恢复，且隐藏后仍能按簇遍历/读/写。
 *     - 首簇号(4字节) 冗余写入 4 个备份位置，防止根目录项槽被 OS 复用时丢信息：
 *         槽1 保留扇区末尾（首要读取）
 *         槽2 磁盘真正尾部（仅当最后一个分区后确有 ≥4 字节空闲）
 *         槽3 引导扇区 BPB 保留扩展区（+0x34..0x3F 末 4 字节；规范要求为 0，
 *             对挂载有无影响需实测）
 *         槽4 MBR 最后一个分区表项（空闲时用其末 4 字节）
 *       读取顺序：槽1 -> 槽2 -> 槽3 -> 槽4，逐个回退；写入四处都写。
 *     - “恢复”：优先把根目录里尚存的 0xE5 特殊目录项改回（FAT 链原样），
 *       若该槽已被 OS 复用，则按保存的簇号在根目录重建目录项。
 *
 * 注意：
 *   - 隐藏期间不要对卷运行 chkdsk 之类“孤儿簇回收”工具，否则可能回收这些簇。
 *   - 引擎只负责磁盘读写与结构操作，不做交互式确认/提权/锁卷；交互层在 fat.cpp。
 *   - 本头文件假设 Windows（CreateFile 裸磁盘/镜像读写）；中文输出用 UTF-8。
 *
 * 编译（含菜单的完整工具）：
 *   x86_64-w64-mingw32-g++ -O2 -Wall -o fat.exe fat.cpp     (仅编译 fat.cpp)
 */
#ifndef FAT_HIDELIB_H
#define FAT_HIDELIB_H

#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <wchar.h>
#include <wctype.h>

/* ------------------------------------------------------------------ */
/* 引擎方案选择                                                         */
/* ------------------------------------------------------------------ */
/* 本头文件内含【两个相互独立】的隐藏方案引擎，都 #include 进来复用：
 *
 *   方案一  fat_sp_* / fat_stash_*  —— “目录项隐藏”引擎（根目录 FAT/FAT1..FAT4
 *            特殊子目录，0xE5 删除标记隐藏，簇号 4 槽备份）。fat.cpp 使用。
 *
 *   方案二  fat_b_*                 —— “坏簇私有文件系统”引擎（自建依附于 FAT32
 *            的文件系统：把数据簇、以及自建的自定义FAT簇/自定义目录簇都标成
 *            0x0FFFFFF7“损坏”，chkdsk 不会把损坏簇当孤儿回收，从而比方案一更抗
 *            chkdsk）。fat1.cpp 使用。
 *
 * 因函数全是 static，宿主若编入自己用不到的方案会触发 -Wall 的
 * “defined but not used” 警告。故用宏控制：
 *     - 默认（不定义任何宏）        → 只编方案一（与旧 fat.cpp 行为一致）。
 *     - #define FAT_ENGINE_SCHEME2 → 只编方案二（fat1.cpp 用）。
 *     - 若确要两个方案同编，可同时定义两个宏；宿主自带代码少时会有 unused 警告，
 *       可自行加 -Wno-unused-function，或只 include 自己需要的引擎。
 * 底层公共件（设备层/几何/FAT项读写/8.3名/4槽位）两个方案共用，恒被编入。
 */
#if !defined(FAT_ENGINE_SCHEME1) && !defined(FAT_ENGINE_SCHEME2)
#define FAT_ENGINE_SCHEME1 1
#endif

/* ---- 裸写诊断状态（fat_wr_sec 记录最近一次扇区写的成败/错误码） ---- */
static int           g_wr_failed=0;   /* 最近一次扇区写是否失败(上层报错用)  */
static unsigned long g_wr_err=0;      /* 失败时的 Windows 错误码(GetLastError)*/
static int           g_rd_failed=0;   /* 最近一次扇区读是否失败(自检取证用)  */
static unsigned long g_rd_err=0;      /* 读失败时的 Windows 错误码           */
static int           g_wr_fell_back=0;/* 设备写调用次数（诊断用：1=整笔一次，8=逐扇区）*/
#ifdef FAT_ENGINE_SCHEME1
static int           g_alloc_wrfail=0;/* alloc 因“写 FAT 失败”而非“无空闲簇” */
#endif

/* ------------------------------------------------------------------ */
/* 小工具                                                              */
/* ------------------------------------------------------------------ */

static unsigned fat_rd16(const unsigned char*p){return (unsigned)p[0]|((unsigned)p[1]<<8);}
static unsigned long fat_rd32(const unsigned char*p)
{return (unsigned long)p[0]|((unsigned long)p[1]<<8)
      |((unsigned long)p[2]<<16)|((unsigned long)p[3]<<24);}
static void fat_wr16(unsigned char*p,unsigned v){p[0]=(unsigned char)(v&255);p[1]=(unsigned char)((v>>8)&255);}
static void fat_wr32(unsigned char*p,unsigned long v)
{p[0]=(unsigned char)(v&255);p[1]=(unsigned char)((v>>8)&255);
 p[2]=(unsigned char)((v>>16)&255);p[3]=(unsigned char)((v>>24)&255);}

static int fat_toupper(int c){return (c>='a'&&c<='z')?c-32:c;}

static void fat_human(unsigned long long b,char*d,size_t cap)
{
    static const char*U[]={"B","KiB","MiB","GiB","TiB"};
    double v=(double)b; int u=0;
    while(v>=1024.0&&u<4){v/=1024.0;u++;}
    if(u==0)snprintf(d,cap,"%llu B",(unsigned long long)b);
    else    snprintf(d,cap,"%.2f %s",v,U[u]);
}

/* ------------------------------------------------------------------ */
/* 对齐缓冲（裸盘 I/O 需要扇区对齐缓冲）                                */
/* ------------------------------------------------------------------ */

typedef struct { void*buf; void*base; size_t cap; } FatABuf;
static void fat_abuf_free(FatABuf*a){if(a&&a->base){free(a->base);a->base=NULL;a->buf=NULL;a->cap=0;}}
static int fat_abuf_ensure(FatABuf*a,size_t n,size_t align)
{
    if(a->cap>=n&&a->buf)return 1;
    fat_abuf_free(a);
    a->base=malloc(n+align);
    if(!a->base)return 0;
    a->cap=n+align;
    a->buf=(void*)((((unsigned long long)(a->base))+(unsigned long long)(align-1))
                   &~((unsigned long long)(align-1)));
    return 1;
}

/* ------------------------------------------------------------------ */
/* 设备抽象：物理盘 或 raw 镜像                                         */
/* ------------------------------------------------------------------ */

typedef struct {
    HANDLE    h;
    int       is_image;      /* 1=raw 镜像, 0=物理盘 */
    int       disknum;       /* 物理盘号（取证读要另开一个无缓存句柄时用） */
    int       nobuf;         /* 1=句柄以 FILE_FLAG_NO_BUFFERING 打开（缓冲区须扇区对齐） */
    DWORD     sector;        /* 逻辑扇区字节数 */
    ULONGLONG total;         /* 设备总字节数 */
    char      title[96];
    /* 物理盘写入一律经 d->h 以【绝对字节偏移】裸写。裸写“挂载中”卷的扇区会被 Windows 拒，
     * 因此写前宿主负责“短暂卸卷接管”(见 fat.cpp seize_volume)：用 GENERIC_READ 打开该分区卷
     * -> FSCTL_LOCK_VOLUME + FSCTL_DISMOUNT_VOLUME，之后裸写即被放行。vol_h 记录“正被接管
     * (已锁定+卸卷)”的卷句柄：fat_wr_sec 不使用它，仅作 fat_dev_close 退出时的 UNLOCK+Close
     * 安全网。分区外的字节(保留区/盘尾/MBR)不属于任何挂载卷，本就允许直写。 */
    HANDLE    vol_h;
} FatDev;

static int fat_dev_open(FatDev*d,int disknum,const char*image,int for_write,int quiet)
{
    char   path[96];
    HANDLE h;
    DWORD  access = for_write? (GENERIC_READ|GENERIC_WRITE) : GENERIC_READ;

    memset(d,0,sizeof *d);
    d->sector=512;
    if(image){
        h=CreateFileA(image,access,FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
        if(h==INVALID_HANDLE_VALUE){
            if(!quiet)printf("  无法打开镜像文件 %s (err %lu)\n",image,(unsigned long)GetLastError());
            return 0;
        }
        d->h=h; d->is_image=1;
        LARGE_INTEGER sz;
        if(GetFileSizeEx(h,&sz))d->total=(ULONGLONG)sz.QuadPart;
        snprintf(d->title,sizeof d->title,"%s",image);
    } else {
        snprintf(path,sizeof path,"\\\\.\\PhysicalDrive%d",disknum);
        /* 打开方式按“已被证明能落盘的写法”优先，逐级降级：
         *   ① flags=0        普通带缓存 I/O —— 上一版 getfat.cpp 在这块真 U 盘上就是
         *                    这么写成功的：读写都经系统缓存，“写完立刻回读”天然一致。
         *   ② WRITE_THROUGH  带缓存但同步写穿。
         *   ③ NO_BUFFERING   无缓存直写。读回所见即盘上所有，但真机实测：个别 USB 桥/
         *                    驱动会把多扇区写吃掉——WriteFile 报成功、介质上却没落。
         * 实际拿到哪一种记在 d->nobuf（1=无缓存，读写缓冲区必须扇区对齐）。 */
        h=CreateFileA(path,access,FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL,OPEN_EXISTING,0,NULL);
        d->nobuf=0;
        if(h==INVALID_HANDLE_VALUE){
            h=CreateFileA(path,access,FILE_SHARE_READ|FILE_SHARE_WRITE,
                          NULL,OPEN_EXISTING,FILE_FLAG_WRITE_THROUGH,NULL);
            d->nobuf=0;
        }
        if(h==INVALID_HANDLE_VALUE){
            h=CreateFileA(path,access,FILE_SHARE_READ|FILE_SHARE_WRITE,
                          NULL,OPEN_EXISTING,
                          FILE_FLAG_NO_BUFFERING|FILE_FLAG_WRITE_THROUGH,NULL);
            if(h!=INVALID_HANDLE_VALUE)d->nobuf=1;
        }
        if(h==INVALID_HANDLE_VALUE){
            if(!quiet){
                printf("  无法打开 %s (err %lu)",path,(unsigned long)GetLastError());
                if(GetLastError()==ERROR_ACCESS_DENIED)printf("  -- 需要管理员权限");
                printf("\n");
            }
            return 0;
        }
        d->h=h; d->is_image=0; d->disknum=disknum;
        GET_LENGTH_INFORMATION li; DWORD n=0;
        if(DeviceIoControl(h,IOCTL_DISK_GET_LENGTH_INFO,NULL,0,&li,sizeof li,&n,NULL))
            d->total=(ULONGLONG)li.Length.QuadPart;
        DISK_GEOMETRY_EX geo; n=0;
        if(DeviceIoControl(h,IOCTL_DISK_GET_DRIVE_GEOMETRY_EX,NULL,0,&geo,sizeof geo,&n,NULL))
            d->sector=geo.Geometry.BytesPerSector;
        if(d->sector==0)d->sector=512;
        snprintf(d->title,sizeof d->title,"PhysicalDrive%d",disknum);
    }
    return 1;
}

/* 把设备句柄上所有未落盘的写刷到设备。物理盘裸写后、放回卷之前必须调用。 */
static void fat_dev_flush(FatDev*d)
{
    if(d&&d->h&&d->h!=INVALID_HANDLE_VALUE)FlushFileBuffers(d->h);
}

/* —— 取证读：绕过系统缓存、直达设备的“盘上到底有什么” ——
 * 带缓存句柄上的回读只能证明【缓存自洽】：写的没落盘时它也照样读得到刚写的字节。
 * 所以“写完回读对不对”在带缓存模式下不构成落盘证据。
 * 本函数另开一个 FILE_FLAG_NO_BUFFERING 句柄读同一处——该模式绕过缓存管理器直达设备，
 * 读到什么，介质上就真是什么。这是本程序唯一诚实的落盘证据。
 * 要求 absbyte 与 need 都按扇区对齐（调用方给的都是簇首，天然满足）。
 * 返回 1=读成功且 buf 里是设备真实内容；0=打不开/读失败（此时 buf 内容无意义）。 */
static int fat_dev_raw_read(const FatDev*d,unsigned long long absbyte,void*buf,unsigned need)
{
    char path[96]; HANDLE h; LARGE_INTEGER pos; DWORD done=0; void*al; int ok=0;
    if(!d||d->is_image||d->disknum<0)return 0;   /* 只有物理盘才谈得上“绕过缓存直读” */
    if(!d->sector||need==0||need%d->sector||absbyte%d->sector)return 0;
    /* 无缓存读要求缓冲区地址也按扇区对齐：用 VirtualAlloc 拿页对齐内存中转 */
    al=VirtualAlloc(NULL,need,MEM_COMMIT|MEM_RESERVE,PAGE_READWRITE);
    if(!al)return 0;
    snprintf(path,sizeof path,"\\\\.\\PhysicalDrive%d",d->disknum);
    h=CreateFileA(path,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,OPEN_EXISTING,
                  FILE_FLAG_NO_BUFFERING|FILE_FLAG_WRITE_THROUGH,NULL);
    if(h!=INVALID_HANDLE_VALUE){
        pos.QuadPart=(LONGLONG)absbyte;
        if(SetFilePointerEx(h,pos,NULL,FILE_BEGIN)&&
           ReadFile(h,al,(DWORD)need,&done,NULL)&&done==(DWORD)need){
            memcpy(buf,al,need);
            ok=1;
        }
        CloseHandle(h);
    }
    VirtualFree(al,0,MEM_RELEASE);
    return ok;
}

static void fat_dev_close(FatDev*d)
{
    fat_dev_flush(d);
    if(d->vol_h&&d->vol_h!=INVALID_HANDLE_VALUE){DeviceIoControl(d->vol_h,FSCTL_UNLOCK_VOLUME,NULL,0,NULL,0,NULL,NULL);CloseHandle(d->vol_h);}
    if(d->h&&d->h!=INVALID_HANDLE_VALUE)CloseHandle(d->h);
    d->vol_h=NULL;d->h=NULL;
}

/* 指针是否按 align 对齐（无缓存 I/O 要求缓冲区地址扇区对齐） */
static int fat_ptr_aligned(const void*p,size_t align)
{return (((unsigned long long)(const unsigned char*)p)&(unsigned long long)(align-1))==0;}

/* —— 多扇区裸 I/O 能力：实测结论驱动，不写死 ——
 * g_multisec_wr: -1 = 还没测过   0 = 实测连 2 扇区都不落，此后一律逐扇区
 *                 k>0 = 实测一次最多能吃下 k 个扇区（fat_b_init 的阶梯探针 8→4→2→1 定）
 * g_multisec_rd: -1 = 还没测过   0 = 多扇区读结果与逐扇区读不一致/读不出，禁用   1 = 可用
 * 背景：某 U 盘对 4096B 整簇写 WriteFile 报成功、done 也等于 4096，介质上却没落（读回 FF）；
 * 同一 LBA 上 512B 单扇区写立刻生效。且裸盘句柄的 I/O 本就绕开文件系统缓存，那个 FF 是
 * 【介质真实内容】不是旧视图（换成 flags=0 打开结果一样，可排除缓存层次）。
 * 但多数设备并无此毛病，所以不写死成“永远逐扇区”——那会让每簇 1 次写变 8 次，慢得没法用。
 * 由 fat_b_init 的探针实测一次定下结论，之后全程照结论走。 */
static int g_multisec_wr=-1;
static int g_multisec_rd=-1;

/* 只发一次设备 I/O，不做拆分、不做校验。上层按 g_multisec_* 的结论决定要不要拆。 */
static int fat_dev_rd1(FatDev*d,unsigned long long lba,unsigned nsec,void*buf)
{
    unsigned long long start=lba*(unsigned long long)d->sector;
    unsigned long long need=(unsigned long long)nsec*d->sector;
    LARGE_INTEGER pos; DWORD done=0; BOOL ok; int bounce=0;
    FatABuf a={0}; void*use=buf;
    if(d->total&&start+need>d->total){g_rd_failed=1;g_rd_err=0;return 0;}
    if(d->nobuf&&!fat_ptr_aligned(buf,d->sector)){
        if(!fat_abuf_ensure(&a,(size_t)need,d->sector)){g_rd_failed=1;g_rd_err=0;return 0;}
        use=a.buf;bounce=1;
    }
    pos.QuadPart=(LONGLONG)start;
    if(!SetFilePointerEx(d->h,pos,NULL,FILE_BEGIN)){
        g_rd_failed=1;g_rd_err=(unsigned long)GetLastError();fat_abuf_free(&a);return 0;}
    done=0;
    if(!ReadFile(d->h,use,(DWORD)need,&done,NULL)){
        /* 无缓存读要求 偏移/长度/缓冲区地址 全部按扇区对齐；前两者本函数已保证，
         * 缓冲区在 nobuf 模式下用对齐中转。若这里仍失败，错误码就是原因(87=参数/对齐)。 */
        g_rd_failed=1;g_rd_err=(unsigned long)GetLastError();
        ok=0;
    } else if(done!=(DWORD)need){
        g_rd_failed=1;g_rd_err=0;ok=0;
    } else {g_rd_failed=0;ok=1;}
    if(ok&&bounce)memcpy(buf,use,(size_t)need);
    fat_abuf_free(&a);
    return ok?1:0;
}

static int fat_dev_wr1(FatDev*d,unsigned long long lba,unsigned nsec,const void*buf)
{
    unsigned long long start=lba*(unsigned long long)d->sector;
    unsigned long long need=(unsigned long long)nsec*d->sector;
    LARGE_INTEGER pos; DWORD done=0; BOOL ok;
    FatABuf a={0}; void*use=(void*)buf;
    if(d->total&&start+need>d->total){g_wr_failed=1;g_wr_err=0;return 0;}
    if(d->nobuf&&!fat_ptr_aligned(buf,d->sector)){
        if(!fat_abuf_ensure(&a,(size_t)need,d->sector)){g_wr_failed=1;g_wr_err=0;return 0;}
        memcpy(a.buf,buf,(size_t)need);use=a.buf;
    }
    /* 一律经磁盘句柄以绝对偏移写；写挂载卷扇区需宿主先短暂卸卷接管(见 FatDev 注释) */
    pos.QuadPart=(LONGLONG)start;
    if(!SetFilePointerEx(d->h,pos,NULL,FILE_BEGIN)){g_wr_failed=1;g_wr_err=(unsigned long)GetLastError();fat_abuf_free(&a);return 0;}
    ok=WriteFile(d->h,use,(DWORD)need,&done,NULL);
    if(!ok||done!=(DWORD)need){
        g_wr_failed=1;
        g_wr_err=ok?0:(unsigned long)GetLastError();  /* 部分写入时错误码无意义 */
        fat_abuf_free(&a);
        return 0;
    }
    fat_abuf_free(&a);
    g_wr_failed=0;
    return 1;
}

/* 多扇区写“报成功”不等于“落了”——回读【首扇区】和【末扇区】比对。
 * 只验首扇区会漏掉“只落了前几扇区”这一种半落法，所以首尾都要验。
 * 比对一律走单扇区设备读（fat_dev_rd1）——多扇区读本身可能同样不可信。
 * 比对时临时存下读错误码，免得这次内部校验把上层的诊断字段弄脏。 */
static int fat_wr_ends_ok(FatDev*d,unsigned long long lba,unsigned nsec,const void*buf)
{
    FatABuf v={0}; int same=0,keep_f=g_rd_failed; unsigned long keep_e=g_rd_err;
    if(fat_abuf_ensure(&v,d->sector,d->sector)){
        same=fat_dev_rd1(d,lba,1,v.buf)&&memcmp(v.buf,buf,d->sector)==0;
        if(same&&nsec>1)
            same=fat_dev_rd1(d,lba+nsec-1,1,v.buf)
                 &&memcmp(v.buf,(const unsigned char*)buf+(size_t)(nsec-1)*d->sector,d->sector)==0;
        fat_abuf_free(&v);
    }
    g_rd_failed=keep_f;g_rd_err=keep_e;
    return same;
}

static int fat_rd_sec(FatDev*d,unsigned long long lba,unsigned nsec,void*buf)
{
    unsigned i;
    if(d->is_image||nsec<=1)return fat_dev_rd1(d,lba,nsec,buf);
    if(g_multisec_rd!=0&&fat_dev_rd1(d,lba,nsec,buf)){g_multisec_rd=1;return 1;}
    g_multisec_rd=0;                       /* 多扇区读这次没成功，此后逐扇区 */
    for(i=0;i<nsec;i++)
        if(!fat_rd_sec(d,lba+i,1,(unsigned char*)buf+(size_t)i*d->sector))return 0;
    g_rd_failed=0;
    return 1;
}

/* 写 nsec 个连续扇区（镜像/单扇区不进分块逻辑）。
 * 分档由 g_multisec_wr 决定：k = 一次最多几扇区。
 *   k == 0 → 逐扇区下发。这条路径与真机上“已被反复验证能落盘”的老写法完全一致，
 *            所以不做回读校验（单扇区写从没被观察到丢写，每簇再加 8 次读纯属白花钱）。
 *   k >  0 → 按 k 分块下发，整段写完后回读【首扇区 + 末扇区】校验——这台设备被实测过
 *            “WriteFile 报成功、done 也对、介质上没落”，不校验就会把丢写当成成功。
 *            校验不过就把 k 降为 0、整段按单扇区重发（重发覆盖全部扇区，不会留半截）。
 * 中间扇区不在每次写时逐个校验：init 的阶梯探针已经对着同一片区域逐扇区验过一遍。
 * 每个簇都全量回读会把「1 次写」变成「8 次读」，等于白提速；代价是若设备在运行中
 * 变成“只落中间某几扇区”这种异常半落法，首尾校验抓不到——属于设备层面的故障。 */
static int fat_wr_sec(FatDev*d,unsigned long long lba,unsigned nsec,const void*buf)
{
    unsigned i,step;
    if(d->is_image||nsec<=1)return fat_dev_wr1(d,lba,nsec,buf);
    if(g_multisec_wr<0)g_multisec_wr=0;    /* 还没探测过就按最保守走（fat_b_init 会先探测出结论） */
    step=(unsigned)g_multisec_wr;
    if(step>nsec)step=nsec;

    if(step>1){
        for(i=0;i<nsec;i+=step){
            unsigned n=(nsec-i<step)?(nsec-i):step;
            g_wr_fell_back++;              /* 计“设备写调用次数”，衡量降级代价 */
            if(!fat_dev_wr1(d,lba+i,n,(const unsigned char*)buf+(size_t)i*d->sector))break;
        }
        if(i>=nsec&&fat_wr_ends_ok(d,lba,nsec,buf)){g_wr_failed=0;return 1;}
        g_multisec_wr=0;step=1;            /* 这段没落/写失败：降级成逐扇区整段重发 */
    }
    for(i=0;i<nsec;i++){
        g_wr_fell_back++;
        if(!fat_dev_wr1(d,lba+i,1,(const unsigned char*)buf+(size_t)i*d->sector))return 0;
    }
    g_wr_failed=0;
    return 1;
}

/* 读 n 字节（任意字节偏移，可不对齐） */
static int fat_rd_bytes(FatDev*d,unsigned long long absoff,unsigned char*buf,size_t n)
{
    unsigned sec=d->sector;
    unsigned long long s0=absoff/sec;
    size_t off=(size_t)(absoff%sec);
    unsigned long long nsec=((unsigned long long)off+n+sec-1)/sec;
    FatABuf a={0}; int ok=0;
    if(n==0)return 1;
    if(!fat_abuf_ensure(&a,(size_t)nsec*(size_t)sec,sec))return 0;
    if(fat_rd_sec(d,s0,(unsigned)nsec,a.buf)){
        memcpy(buf,(unsigned char*)a.buf+off,n);
        ok=1;
    }
    fat_abuf_free(&a);
    return ok;
}

/* 读-改-写 n 字节（只触碰 [absoff,absoff+n)） */
static int fat_wr_bytes(FatDev*d,unsigned long long absoff,const unsigned char*buf,size_t n)
{
    unsigned sec=d->sector;
    unsigned long long s0=absoff/sec;
    size_t off=(size_t)(absoff%sec);
    unsigned long long nsec=((unsigned long long)off+n+sec-1)/sec;
    FatABuf a={0}; int ok=0;
    if(n==0)return 1;
    if(!fat_abuf_ensure(&a,(size_t)nsec*(size_t)sec,sec))return 0;
    if(!fat_rd_sec(d,s0,(unsigned)nsec,a.buf)){fat_abuf_free(&a);return 0;}
    memcpy((unsigned char*)a.buf+off,buf,n);
    ok=fat_wr_sec(d,s0,(unsigned)nsec,a.buf);
    fat_abuf_free(&a);
    return ok;
}

/* ------------------------------------------------------------------ */
/* 主机文件辅助（路径可为 UTF-8）                                       */
/* ------------------------------------------------------------------ */

static unsigned char*fat_read_file(const char*path,unsigned long*len,unsigned long*err)
{
    HANDLE h; wchar_t w[2048]; unsigned char*buf=NULL;
    LARGE_INTEGER sz; unsigned long total=0;
    unsigned long n=MultiByteToWideChar(CP_UTF8,0,path,-1,w,(int)(sizeof w/sizeof w[0]));
    if(n==0){*err=1;return NULL;}
    h=CreateFileW(w,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
                  NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE){*err=GetLastError();return NULL;}
    if(!GetFileSizeEx(h,&sz)||sz.QuadPart<0||sz.QuadPart>0x100000000LL){
        CloseHandle(h);*err=GetLastError()?GetLastError():2;return NULL;
    }
    *len=(unsigned long)sz.QuadPart;
    if(*len==0){CloseHandle(h);*err=0;return (unsigned char*)calloc(1,1);}
    buf=(unsigned char*)malloc(*len);
    if(!buf){CloseHandle(h);*err=3;return NULL;}
    while(total<*len){
        DWORD d=0;
        if(!ReadFile(h,buf+total,*len-total,&d,NULL)||d==0){
            CloseHandle(h);free(buf);*err=4;return NULL;
        }
        total+=d;
    }
    CloseHandle(h);*err=0;
    return buf;
}

static int fat_write_file(const char*path,const unsigned char*buf,unsigned long len,unsigned long*err)
{
    HANDLE h; wchar_t w[2048]; DWORD total=0;
    unsigned long n=MultiByteToWideChar(CP_UTF8,0,path,-1,w,(int)(sizeof w/sizeof w[0]));
    if(n==0){if(err)*err=1;return 0;}
    h=CreateFileW(w,GENERIC_WRITE,FILE_SHARE_READ|FILE_SHARE_WRITE,
                  NULL,CREATE_ALWAYS,FILE_ATTRIBUTE_NORMAL,NULL);
    if(h==INVALID_HANDLE_VALUE){if(err)*err=GetLastError();return 0;}
    while(total<len){
        DWORD chunk=(len-total>(1u<<20))?(1u<<20):(DWORD)(len-total);
        DWORD done=0;
        if(!WriteFile(h,buf+total,chunk,&done,NULL)||done==0){
            CloseHandle(h);if(err)*err=5;return 0;
        }
        total+=done;
    }
    CloseHandle(h);if(err)*err=0;
    return 1;
}

static int fat_is_directory(const char*path)
{
    wchar_t w[2048]; DWORD a;
    if(!MultiByteToWideChar(CP_UTF8,0,path,-1,w,(int)(sizeof w/sizeof w[0])))return 0;
    a=GetFileAttributesW(w);
    if(a==INVALID_FILE_ATTRIBUTES)return 0;
    return (a&FILE_ATTRIBUTE_DIRECTORY)!=0;
}

/* ------------------------------------------------------------------ */
/* MBR                                                          */
/* ------------------------------------------------------------------ */

typedef struct {
    int       used;
    unsigned  type;
    unsigned long start_lba;
    unsigned long count;
} FatMbrEnt;

static void fat_mbr_decode(const unsigned char*m,size_t cap,FatMbrEnt*e,int n)
{
    int i;
    for(i=0;i<n;i++){
        const unsigned char*p=m+(size_t)(0x1BE + (size_t)16*(size_t)i);
        memset(&e[i],0,sizeof e[i]);
        if((size_t)((p+16)-m)>cap)continue;
        e[i].type=p[4];
        e[i].count=fat_rd32(p+12);
        if(e[i].type==0||e[i].count==0)continue;
        e[i].used=1;
        e[i].start_lba=fat_rd32(p+8);
    }
}

/* ------------------------------------------------------------------ */
/* FAT32 几何 / 打开                                                    */
/* ------------------------------------------------------------------ */

typedef struct {
    FatDev*   dev;
    ULONGLONG part_lba;     /* 分区起始的绝对 LBA */
    ULONGLONG part_secs;    /* 分区扇区数 */
    int       superfloppy;  /* 1 = 无分区表，整个设备就是一个 FAT32 卷 */
    unsigned  bps;          /* 每扇区字节 BPB+11 */
    unsigned  spc;          /* 每簇扇区 BPB+13 */
    ULONGLONG rsvd;         /* 保留扇区数 BPB+14 */
    unsigned  nfat;
    ULONGLONG fatsz;        /* 每 FAT 扇区数 BPB+36 */
    ULONGLONG rootclu;      /* 根目录首簇 BPB+44 */
    ULONGLONG fat0_lba;     /* FAT0 绝对 LBA */
    ULONGLONG datalba;      /* 数据区起始绝对 LBA */
    ULONGLONG maxclu;       /* 合法最大簇号 */
} Fat32;

static ULONGLONG fat_clu_lba(const Fat32*f,ULONGLONG c){return f->datalba+(c-2)*(ULONGLONG)f->spc;}

/* 读 FAT 项（28 位），失败返回 0。条目可能跨扇区，单独处理。 */
static unsigned long fat_get(const Fat32*f,ULONGLONG c)
{
    FatABuf a={0}; unsigned long v;
    ULONGLONG byte=c*4;
    ULONGLONG s=f->fat0_lba+byte/(ULONGLONG)f->bps;
    unsigned off=(unsigned)(byte%(ULONGLONG)f->bps);
    if(!fat_abuf_ensure(&a,f->bps,f->bps))return 0;
    if(!fat_rd_sec(f->dev,s,1,a.buf)){fat_abuf_free(&a);return 0;}
    if(off+4<=f->bps){
        v=fat_rd32((unsigned char*)a.buf+off);
        fat_abuf_free(&a);
        return v&0x0FFFFFFFUL;
    }
    {
        FatABuf nxt={0}; unsigned char tail[4]={0,0,0,0}; unsigned i,first=f->bps-off,remain=4-first;
        if(!fat_abuf_ensure(&nxt,f->bps,f->bps)){fat_abuf_free(&a);return 0;}
        if(!fat_rd_sec(f->dev,s+1,1,nxt.buf)){fat_abuf_free(&a);fat_abuf_free(&nxt);return 0;}
        for(i=0;i<remain;i++)tail[i]=((unsigned char*)nxt.buf)[i];
        v=0;
        for(i=0;i<first;i++)v|=(unsigned long)((unsigned char*)a.buf)[off+i]<<(8*i);
        for(i=0;i<remain;i++)v|=(unsigned long)tail[i]<<(8*(first+i));
        fat_abuf_free(&a);fat_abuf_free(&nxt);
        return v&0x0FFFFFFFUL;
    }
}

/* 写 FAT 项到全部 nfat 份拷贝；保留高 4 位（符合规范） */
static int fat_set(const Fat32*f,ULONGLONG c,unsigned long v28)
{
    unsigned i;
    v28&=0x0FFFFFFFUL;
    for(i=0;i<f->nfat;i++){
        ULONGLONG fatbase=f->fat0_lba+(ULONGLONG)i*f->fatsz;
        ULONGLONG byte=fatbase*(ULONGLONG)f->bps+c*4;
        ULONGLONG s0=byte/(ULONGLONG)f->bps;
        unsigned off=(unsigned)(byte%(ULONGLONG)f->bps);
        if(off+4<=f->bps){
            FatABuf a={0}; unsigned char*b;
            if(!fat_abuf_ensure(&a,f->bps,f->bps))return 0;
            if(!fat_rd_sec(f->dev,s0,1,a.buf)){fat_abuf_free(&a);return 0;}
            b=(unsigned char*)a.buf+off;
            fat_wr32(b,((fat_rd32(b)&0xF0000000UL)|v28));
            if(!fat_wr_sec(f->dev,s0,1,a.buf)){fat_abuf_free(&a);return 0;}
            fat_abuf_free(&a);
        } else {
            FatABuf a={0},b2={0}; unsigned char*p;
            if(!fat_abuf_ensure(&a,f->bps,f->bps))return 0;
            if(!fat_abuf_ensure(&b2,f->bps,f->bps))return 0;
            if(!fat_rd_sec(f->dev,s0,1,a.buf)){fat_abuf_free(&a);fat_abuf_free(&b2);return 0;}
            if(!fat_rd_sec(f->dev,s0+1,1,b2.buf)){fat_abuf_free(&a);fat_abuf_free(&b2);return 0;}
            p=(unsigned char*)a.buf+off; fat_wr32(p,((fat_rd32(p)&0xFFFF0000UL)|(v28&0xFFFFUL)));
            p=(unsigned char*)b2.buf;    fat_wr32(p,((fat_rd32(p)&0xFF000000UL)|((v28>>16)&0xFFUL)));
            if(!fat_wr_sec(f->dev,s0,1,a.buf)){fat_abuf_free(&a);fat_abuf_free(&b2);return 0;}
            if(!fat_wr_sec(f->dev,s0+1,1,b2.buf)){fat_abuf_free(&a);fat_abuf_free(&b2);return 0;}
            fat_abuf_free(&a);fat_abuf_free(&b2);
        }
    }
    return 1;
}

/* 调整 FSInfo 的空闲簇计数（每次新分配 1 簇后调用，保持提示正确） */
static void fat_fsinfo_adjust(const Fat32*f,int delta)
{
    unsigned char boot[512]; unsigned fsi;
    FatABuf a={0}; unsigned char*p;
    if(delta==0)return;
    if(!fat_rd_bytes(f->dev,f->part_lba*(unsigned long long)f->bps,boot,512))return;
    fsi=fat_rd16(boot+0x30);
    if(fsi==0||fsi>=f->rsvd)return;
    if(!fat_abuf_ensure(&a,f->bps,f->bps))return;
    if(!fat_rd_sec(f->dev,f->part_lba+fsi,1,a.buf)){fat_abuf_free(&a);return;}
    p=(unsigned char*)a.buf;
    if(!(fat_rd32(p)==0x41615252UL)){fat_abuf_free(&a);return;}           /* "RRaA" */
    p+=0x1E8;
    if(fat_rd32(p)!=0xFFFFFFFFUL){
        long cnt=(long)fat_rd32(p)+delta;
        if(cnt<0)cnt=0;
        fat_wr32(p,(unsigned long)cnt);
        if(fat_wr_sec(f->dev,f->part_lba+fsi,1,a.buf)){/* ok */}
    }
    fat_abuf_free(&a);
}

#ifdef FAT_ENGINE_SCHEME1
/* 分配一个空闲簇：扫 FAT0 找值为 0 的项，置为 EOF 并返回；失败 0
 * （区分“真没有空闲簇”与“写 FAT 被拒”：后者置 g_alloc_wrfail=1） */
static ULONGLONG fat_alloc_cluster(const Fat32*f)
{
    ULONGLONG c;
    g_alloc_wrfail=0;
    for(c=2;c<=f->maxclu;c++){
        if(fat_get(f,c)==0){
            if(!fat_set(f,c,0x0FFFFFFFUL)){g_alloc_wrfail=1;return 0;}
            fat_fsinfo_adjust(f,-1);
            return c;
        }
    }
    return 0;
}
#endif /* FAT_ENGINE_SCHEME1 */

/* 按一个簇镜像解析 BPB，填 f；成功 1 */
static int fat_boot_parse(FatDev*d,ULONGLONG plba,ULONGLONG psecs,Fat32*f)
{
    unsigned char bs[512];
    if(!fat_rd_bytes(d,plba*(unsigned long long)d->sector,bs,512))return 0;
    if(!(bs[510]==0x55&&bs[511]==0xAA))return 0;
    {
        unsigned bps=fat_rd16(bs+11),spc,rsvd,nfat;
        ULONGLONG fatsz;
        if(bps<512||bps>16384||(bps&(bps-1)))return 0;
        spc=bs[13]; if(!spc||(spc&(spc-1)))return 0;
        rsvd=fat_rd16(bs+14); if(rsvd==0)return 0;
        nfat=bs[16]; if(nfat==0)return 0;
        fatsz=fat_rd32(bs+36); if(fatsz==0)return 0;
        if(memcmp(bs+0x52,"FAT32",5)!=0)return 0;   /* 引导扇区无 FAT32 标志则不认 */
        memset(f,0,sizeof *f);
        f->dev=d; f->part_lba=plba; f->part_secs=psecs;
        f->bps=bps; f->spc=spc; f->rsvd=rsvd; f->nfat=nfat;
        f->fatsz=fatsz; f->rootclu=fat_rd32(bs+44);
        f->fat0_lba=plba+rsvd;
        f->datalba=plba+rsvd+(ULONGLONG)nfat*fatsz;
        if(rsvd+(ULONGLONG)nfat*fatsz < psecs)
            f->maxclu=2+(psecs-(rsvd+(ULONGLONG)nfat*fatsz))/spc;
        else f->maxclu=2;
        return 1;
    }
}

/*
 * 打开设备中的第一个 FAT32 卷：
 *   优先按 MBR 主分区表找 FAT32 分区（0x0B/0x0C/0x1B/0x1C）；
 *   找不到且设备 0 号扇区本身是 FAT32 引导扇区则按“超级软盘”整卷处理。
 */
static int fat32_open(FatDev*d,Fat32*f,char*err,size_t ecap)
{
    unsigned char m[512]; FatMbrEnt e[4];
    int k,fattype=0;
    if(!fat_rd_bytes(d,0,m,512)){snprintf(err,ecap,"读 0 号扇区失败");return 0;}
    if(m[510]==0x55&&m[511]==0xAA)fat_mbr_decode(m,sizeof m,e,4);
    /* 1) MBR 分区表路径 */
    if(m[510]==0x55&&m[511]==0xAA){
        for(k=0;k<4;k++){
            if(!e[k].used)continue;
            switch(e[k].type){case 0x0B:case 0x0C:case 0x1B:case 0x1C:fattype=1;break;}
            if(!fattype)continue;
            if(fat_boot_parse(d,e[k].start_lba,e[k].count,f))return 1;
        }
    }
    /* 2) 超级软盘路径 */
    if(fat_boot_parse(d,0,d->total/(unsigned long long)d->sector,f)){
        f->superfloppy=1;
        f->part_lba=0; f->part_secs=d->total/(unsigned long long)d->sector;
        /* 重新以整卷长度算 maxclu */
        f->maxclu=(f->rsvd+(ULONGLONG)f->nfat*f->fatsz < f->part_secs)
                ? 2+(f->part_secs-(f->rsvd+(ULONGLONG)f->nfat*f->fatsz))/f->spc : 2;
        return 1;
    }
    snprintf(err,ecap,"未找到 FAT32 卷（无标准 MBR 中的 FAT32 分区，且 0 号扇区也不是 FAT32 引导扇区）");
    return 0;
}

#ifdef FAT_ENGINE_SCHEME1
/* ------------------------------------------------------------------ */
/* 目录读取 / 回写（方案一专用：走 FAT32 真实目录链）                     */
/* ------------------------------------------------------------------ */

typedef struct { unsigned char*data; size_t len; } FatDirBuf;

static int fat_dir_read(const Fat32*f,ULONGLONG start,FatDirBuf*db,int quiet)
{
    size_t cap=0,used=0; ULONGLONG c=start; int guard=0;
    db->data=NULL; db->len=0;
    for(;;){
        unsigned char*t;
        if(guard++>200000){if(!quiet)printf("  [警告] 目录簇链过长，中止\n");break;}
        if(c<2||c>f->maxclu)break;
        if(c>=0x0FFFFFF8UL)break;
        if(used+(size_t)f->spc*f->bps>cap){
            cap=used+(size_t)f->spc*f->bps+65536;
            t=(unsigned char*)realloc(db->data,cap);
            if(!t){free(db->data);db->data=NULL;return 0;}
            db->data=t;
        }
        if(!fat_rd_sec(f->dev,fat_clu_lba(f,c),(unsigned)f->spc,db->data+used)){
            if(!quiet)printf("  [警告] 读簇 %llu 失败\n",(unsigned long long)c);
            free(db->data);db->data=NULL;return 0;
        }
        used+=(size_t)f->spc*f->bps;
        c=fat_get(f,c);
        if(c<2)break;
    }
    db->len=used;
    return used>0;
}

/* 把 len 字节目录数据按链从 start 逐簇写回（len 应为整簇倍数） */
static int fat_dir_write_back(const Fat32*f,ULONGLONG start,const unsigned char*data,size_t len)
{
    size_t clusz=(size_t)f->spc*f->bps;
    ULONGLONG c=start; size_t off=0; int guard=0;
    while(off<len){
        if(guard++>200000)return 0;
        if(c<2||c>f->maxclu)return 0;
        if(!fat_wr_sec(f->dev,fat_clu_lba(f,c),(unsigned)f->spc,data+off))return 0;
        off+=clusz;
        if(off>=len)break;
        c=fat_get(f,c);
        if(c<2)return 0;
    }
    return 1;
}

#endif /* FAT_ENGINE_SCHEME1：目录读取/回写 */

/* 8.3 名字格式化 "NAME.EXT"（大写） */
static void fat_name83(const unsigned char*d,char*out,size_t cap)
{
    char a[9]={0},b[4]={0}; int i;
    for(i=0;i<8&&d[i]!=' '&&d[i]!=0;i++)a[i]=(char)d[i];
    a[i]=0;
    for(i=0;i<3&&d[8+i]!=' '&&d[8+i]!=0;i++)b[i]=(char)d[8+i];
    b[i]=0;
    if(b[0])snprintf(out,cap,"%s.%s",a,b);
    else    snprintf(out,cap,"%s",a);
}

static int fat_nameeq(const char*a,const char*b)
{
    if(!a||!b)return 0;
    while(*a&&*b){if(fat_toupper((unsigned char)*a)!=fat_toupper((unsigned char)*b))return 0;a++;b++;}
    return *a==0&&*b==0;
}

/* 目录项字段辅助 */
static unsigned long fat_ent_clu(const unsigned char*dn)
{return ((unsigned long)fat_rd16(dn+0x14)<<16)|fat_rd16(dn+0x1A);}
static void fat_ent_set_clu(unsigned char*dn,unsigned long c)
{fat_wr16(dn+0x14,(unsigned)((c>>16)&0xFFFF));fat_wr16(dn+0x1A,(unsigned)(c&0xFFFF));}
static unsigned long fat_ent_size(const unsigned char*dn){return fat_rd32(dn+0x1C);}

static void fat_dos_now(unsigned short*date,unsigned short*time)
{
    SYSTEMTIME st; unsigned y;
    GetLocalTime(&st);
    y=st.wYear; if(y<1980)y=1980; if(y>2107)y=2107;
    *date=(unsigned short)(((y-1980)<<9)|(st.wMonth<<5)|st.wDay);
    *time=(unsigned short)((st.wHour<<11)|(st.wMinute<<5)|(st.wSecond/2));
}

/* 构造一条 32 字节目录项（文件名已给主名/扩展名字节，大写化保存） */
static void fat_build_entry(unsigned char e[32],const unsigned char mainnm[8],int mlen,
                            const unsigned char ext[3],int xlen,
                            unsigned attr,unsigned long clu,unsigned long size)
{
    int i; unsigned short dt,tm;
    memset(e,0,32);
    for(i=0;i<8;i++)e[i]=(unsigned char)((i<mlen)?fat_toupper(mainnm[i]):' ');
    for(i=0;i<3;i++)e[8+i]=(unsigned char)((i<xlen)?fat_toupper(ext[i]):' ');
    e[11]=(unsigned char)attr;
    fat_dos_now(&dt,&tm);
    e[14]=(unsigned char)(tm&255);e[15]=(unsigned char)((tm>>8)&255);
    e[16]=(unsigned char)(dt&255);e[17]=(unsigned char)((dt>>8)&255);
    e[22]=(unsigned char)(tm&255);e[23]=(unsigned char)((tm>>8)&255);
    e[24]=(unsigned char)(dt&255);e[25]=(unsigned char)((dt>>8)&255);
    fat_ent_set_clu(e,clu);
    fat_wr32(e+0x1C,size);
}

#ifdef FAT_ENGINE_SCHEME1
/* 追加一条 32 字节目录项到目录链末尾的空闲槽；槽满则扩 1 簇。
 * 成功返回 1；*newClu 记录是否/哪个新簇被用于放置。 */
static int fat_dir_append(const Fat32*f,ULONGLONG start,const unsigned char ent[32],ULONGLONG*newClu)
{
    FatDirBuf db={0}; long i; int guard=0;
    if(!fat_dir_read(f,start,&db,1))return 0;
    /* 找空闲槽：首字节 0x00(链尾)或 0xE5(已删) */
    for(i=0;(long)(i+1)*32<=(long)db.len;i++){
        if(db.data[(size_t)i*32]==0x00||db.data[(size_t)i*32]==0xE5){
            memcpy(db.data+(size_t)i*32,ent,32);
            if(!fat_dir_write_back(f,start,db.data,db.len)){free(db.data);return 0;}
            free(db.data);
            if(newClu)*newClu=0;
            return 1;
        }
    }
    /* 槽满：扩一个簇 */
    {
        ULONGLONG c=start,L=0,C; FatABuf z={0};
        for(guard=0;guard<200000;guard++){
            if(c<2||c>f->maxclu)break;
            L=c;
            c=fat_get(f,c);
            if(c<2)break;
        }
        C=fat_alloc_cluster(f);
        if(!C){free(db.data);return 0;}
        if(L>=2){
            if(!fat_set(f,L,(unsigned long)C)){free(db.data);return 0;}
        }
        if(!fat_set(f,C,0x0FFFFFFFUL)){free(db.data);return 0;}
        if(fat_abuf_ensure(&z,(size_t)f->spc*f->bps,f->bps)){
            memset(z.buf,0,(size_t)f->spc*f->bps);
            fat_wr_sec(f->dev,fat_clu_lba(f,C),(unsigned)f->spc,z.buf);
        }
        fat_abuf_free(&z);
        /* 把目录项写到新簇开头 */
        if(!fat_wr_bytes(f->dev,fat_clu_lba(f,C)*(unsigned long long)f->bps,ent,32)){
            free(db.data);return 0;
        }
        free(db.data);
        if(newClu)*newClu=C;
        return 1;
    }
}

/* ------------------------------------------------------------------ */
/* 特殊目录名：FAT / FAT1..FAT4                                         */
/* ------------------------------------------------------------------ */

#define FAT_SPECIAL_N 5
static const char*g_special_names[FAT_SPECIAL_N]={"FAT","FAT1","FAT2","FAT3","FAT4"};

static int fat_special_which(const char*nm)
{
    int i;
    if(!nm||!*nm)return -1;
    for(i=0;i<FAT_SPECIAL_N;i++)if(fat_nameeq(nm,g_special_names[i]))return i;
    return -1;
}

/* 判断“已删除(0xE5)”目录项是否为特殊目录被删后的残留。
 * FAT 删除机制用 0xE5 覆盖名字的首字符，故把候选名首字符换成 0xE5 后比对 11 字节；
 * 同时必须是目录项(attr&0x10)。 */
static int fat_del_special_which(const unsigned char*dn)
{
    int i;
    if(dn[0]!=0xE5)return -1;
    if(!(dn[11]&0x10))return -1;
    for(i=0;i<FAT_SPECIAL_N;i++){
        const char*cn=g_special_names[i];
        unsigned char cmp[11]; int ml=(int)strlen(cn),k;
        if(ml>8)ml=8;
        memset(cmp,' ',11);
        cmp[0]=0xE5;
        for(k=1;k<ml;k++)cmp[k]=(unsigned char)cn[k];
        if(memcmp(dn,cmp,11)==0)return i;
    }
    return -1;
}

/* 根目录扫描结果 */
typedef struct {
    int        live_which;   /* 存活特殊目录（最小候选序） */
    ULONGLONG  live_clu;
    long       live_idx;
    int        live_n;
    int        del_which;    /* 首个已删除(0xE5)的特殊目录项 */
    ULONGLONG  del_clu;
    long       del_idx;
    int        del_n;
    int        used_mask;    /* 名字被“任何存活条目”占用(0..4 位) */
} FatSpScan;

static void fat_sp_scan(const Fat32*f,FatSpScan*s)
{
    FatDirBuf db={0}; size_t i; char nm[16];
    memset(s,0,sizeof *s);
    s->live_which=-1; s->del_which=-1;
    if(!fat_dir_read(f,f->rootclu,&db,1)){free(db.data);return;}
    for(i=0;i+32<=db.len;i+=32){
        const unsigned char*dn=db.data+i;
        int w; unsigned long clu;
        if(dn[0]==0x00)break;
        if(dn[0]==0xE5){
            w=fat_del_special_which(dn);
            clu=(w>=0)?fat_ent_clu(dn):0;
            /* 只在簇号合法且 FAT 链仍被占用(未被系统回收)时算“可恢复的被删特殊目录” */
            if(w>=0&&clu>=2&&clu<=f->maxclu&&fat_get(f,clu)!=0){
                if(s->del_which<0){s->del_which=w;s->del_clu=clu;s->del_idx=(long)(i/32);}
                s->del_n++;
            }
            continue;
        }
        if(dn[11]==0x0F)continue;
        if(dn[11]&0x08)continue;              /* 卷标等 */
        w=fat_special_which((fat_name83(dn,nm,sizeof nm),nm));
        if(w>=0){
            s->used_mask|=1<<w;
            if((dn[11]&0x10)){
                s->live_n++;
                if(s->live_which<0||w<s->live_which){
                    s->live_which=w;s->live_clu=fat_ent_clu(dn);s->live_idx=(long)(i/32);
                }
            }
        }
    }
    free(db.data);
}

#endif /* FAT_ENGINE_SCHEME1：方案一 目录链/特殊名/扫描 */

/* ------------------------------------------------------------------ */
/* 首簇号四处备份（槽1..槽4）—— 两个方案共用                              */
/* ------------------------------------------------------------------ */

/* 每个槽的可用字节位置（绝对设备字节偏移），不可用返回 0 */
static int fat_slot_pos(const Fat32*f,int which,unsigned long long*abs)
{
    FatDev*d=f->dev;
    if(which==0){   /* 槽1：保留扇区末尾 */
        unsigned char boot[512]; unsigned fsi,bk; ULONGLONG tailrel;
        if(f->rsvd<2)return 0;
        if(!fat_rd_bytes(d,f->part_lba*(unsigned long long)f->bps,boot,512))return 0;
        fsi=fat_rd16(boot+0x30); bk=fat_rd16(boot+0x32);
        tailrel=f->rsvd-1;                    /* 最后一个保留扇区(相对分区) */
        if(tailrel==0)return 0;
        if(fsi>=2&&tailrel==fsi)return 0;
        if(bk>=2&&(tailrel==bk||tailrel==bk+1))return 0;
        *abs=(f->part_lba+f->rsvd)*(unsigned long long)f->bps-4;
        return 1;
    }
    if(which==1){   /* 槽2：磁盘真正尾部（需最后一个分区后有 ≥4 字节空闲） */
        unsigned char m[512]; FatMbrEnt e[4]; int k; unsigned long long maxend=0;
        if(f->superfloppy)return 0;
        if(!fat_rd_bytes(d,0,m,512))return 0;
        if(!(m[510]==0x55&&m[511]==0xAA))return 0;
        fat_mbr_decode(m,sizeof m,e,4);
        for(k=0;k<4;k++)if(e[k].used){
            unsigned long long en=((unsigned long long)e[k].start_lba+e[k].count)*d->sector;
            if(en>maxend)maxend=en;
        }
        if(!d->total)return 0;
        if(d->total<=maxend)return 0;
        if(d->total-maxend<4)return 0;
        *abs=d->total-4;
        return 1;
    }
    if(which==2){   /* 槽3：引导扇区 BPB 保留扩展区 +0x3C..0x3F */
        if(f->part_secs<1)return 0;
        *abs=f->part_lba*(unsigned long long)f->bps+0x3C;
        return 1;
    }
    /* 槽4：MBR 最后一个(第4项)分区表项，仅当空闲 */
    {
        unsigned char m[512]; FatMbrEnt e[4];
        if(f->superfloppy)return 0;
        if(!fat_rd_bytes(d,0,m,512))return 0;
        if(!(m[510]==0x55&&m[511]==0xAA))return 0;
        fat_mbr_decode(m,sizeof m,e,4);
        if(e[3].used)return 0;
        *abs=0x1FA;                            /* 0x1BE+48+12 */
        return 1;
    }
}

static const char*fat_slot_label(int which)
{
    static const char*L[4]={"保留扇区末尾","磁盘真正尾部","BPB 保留扩展区","MBR 末分区表项"};
    if(which<0||which>3)return "?";
    return L[which];
}

/* 读某槽（4 字节 LE），不可用置 *ok=0 */
static unsigned long fat_slot_read(const Fat32*f,int which,int*ok)
{
    unsigned long long ab; unsigned char b[4]; unsigned long v;
    *ok=0;
    if(!fat_slot_pos(f,which,&ab))return 0;
    if(!fat_rd_bytes(f->dev,ab,b,4))return 0;
    *ok=1; v=fat_rd32(b);
    return v;
}

static int fat_slot_write(const Fat32*f,int which,unsigned long v)
{
    unsigned long long ab; unsigned char b[4];
    if(!fat_slot_pos(f,which,&ab))return 0;
    fat_wr32(b,v);
    return fat_wr_bytes(f->dev,ab,b,4);
}

/* 写入全部槽，返回成功位掩码 bit(which)。槽1 必须成功。 */
static int fat_stash_write_all(const Fat32*f,unsigned long clu)
{
    int mask=0,w;
    for(w=0;w<4;w++)if(fat_slot_write(f,w,clu))mask|=1<<w;
    return mask;
}

/* 按优先级读取首簇号（槽1→2→3→4），返回 0=都没有 */
static unsigned long fat_stash_read_cluster(const Fat32*f,int*fromSlot)
{
    int w,ok; unsigned long v;
    static const int order[4]={0,1,2,3};
    for(w=0;w<4;w++){
        v=fat_slot_read(f,order[w],&ok);
        if(ok&&v>=2&&v<=f->maxclu){if(fromSlot)*fromSlot=order[w];return v;}
    }
    return 0;
}

/* 检查 4 槽是否有任何一个保存着合法簇（供“当前是否已有备份”判断） */
static int fat_stash_present(const Fat32*f,unsigned long*clu)
{
    int slot;
    *clu=fat_stash_read_cluster(f,&slot);
    return *clu!=0;
}

#ifdef FAT_ENGINE_SCHEME1
/* ------------------------------------------------------------------ */
/* 高层操作：创建 / 隐藏 / 恢复                                          */
/* ------------------------------------------------------------------ */

/* 找出一个未被“任何存活条目”占用的候选名 */
static int fat_pick_free_name(const Fat32*f)
{
    FatSpScan s; int w;
    fat_sp_scan(f,&s);
    for(w=0;w<FAT_SPECIAL_N;w++)if(!(s.used_mask&(1<<w)))return w;
    return -1;
}

/*
 * 创建特殊目录 g_special_names[which]（名字必须空闲）：
 * 分配一个簇作为目录簇，写 "." ".."，再在根目录登记。返回该目录首簇。
 */
static int fat_sp_create(Fat32*f,int which,unsigned long*outclu,char*err,size_t ecap)
{
    FatSpScan s; unsigned char ent[32]; unsigned char z32[32];
    unsigned long C; ULONGLONG newc=0; FatABuf z={0};
    fat_sp_scan(f,&s);
    if(s.used_mask&(1<<which)){
        snprintf(err,ecap,"名字 %s 已被根目录中的条目占用，请换一个（工具会自动找下一个空闲名）",
                 g_special_names[which]);
        return 0;
    }
    C=(unsigned long)fat_alloc_cluster(f);
    if(!C){
        if(g_alloc_wrfail)
            snprintf(err,ecap,"已找到空闲簇，但写 FAT 表被系统拒绝（Windows 错误码 %lu，通常 5=拒绝访问）。"
                     "物理盘上仍有挂载/被占用的卷时 Windows 禁止裸写其扇区：请关闭该 U 盘在资源管理器/终端里的所有窗口后重试，"
                     "仍失败则在“磁盘管理”中先把该卷设为脱机。",g_wr_err);
        else
            snprintf(err,ecap,"扫描完整个 FAT 表均无空闲簇（簇2..簇%llu 全是占用）。卷可能确已占满，"
                     "或 FAT 位置/几何读取有误——选菜单1查看诊断中的 FAT[2..9] 采样。",
                     (unsigned long long)f->maxclu);
        return 0;
    }
    /* 清零目录簇 */
    if(fat_abuf_ensure(&z,(size_t)f->spc*f->bps,f->bps)){
        memset(z.buf,0,(size_t)f->spc*f->bps);
        fat_wr_sec(f->dev,fat_clu_lba(f,C),(unsigned)f->spc,z.buf);
    }
    fat_abuf_free(&z);
    /* "." —— 11 字节名字段必须【全部】用 0x20 空格填充：'.' 后 10 个空格。
     * 只填前 8 字节、把扩展名留成 0x00 是不合规的：fsck.fat 就认不出这是合法 '.' 项，
     * 会报 “Expected a valid '.' entry in this slot”，Windows 也会按就地修正处理。
     * （真机上目录一般是在资源管理器里建的，所以这个坑一直没暴露；镜像上自建才会踩到。） */
    memset(z32,0,sizeof z32);
    memcpy(z32,".          ",11);              /* '.' + 10 个空格 = 11 字节 */
    z32[11]=0x10; fat_ent_set_clu(z32,C);
    if(!fat_wr_bytes(f->dev,fat_clu_lba(f,C)*(unsigned long long)f->bps,z32,32))goto wrfail;
    /* ".."（父为根目录：FAT32 根无簇号用 0）—— 同样 11 字节全空格：'..' + 9 个空格 */
    memset(z32,0,sizeof z32);
    memcpy(z32,"..         ",11);              /* '..' + 9 个空格 = 11 字节 */
    z32[11]=0x10; fat_ent_set_clu(z32,0);
    if(!fat_wr_bytes(f->dev,fat_clu_lba(f,C)*(unsigned long long)f->bps+32,z32,32))goto wrfail;
    /* 自检：立刻回读刚写的目录簇头。物理盘上曾出现“写调用报成功、回读却不是这些字节”，
     * 没有这一步的话，故障要等到很久以后才以“恢复不出来/内容不对”的形式暴露，极难定位。
     * 放在根目录登记【之前】：此时还没有任何东西引用 C，回滚只需把它退回空闲。 */
    {
        unsigned char chk[32]; int okc;
        unsigned long long offc=fat_clu_lba(f,C)*(unsigned long long)f->bps;
        memset(chk,0xCC,sizeof chk);
        okc=fat_rd_bytes(f->dev,offc,chk,32);
        /* 物理盘再补一次无缓存句柄直读作旁证。常规回读本身已是介质内容（裸盘 I/O 不经
         * 文件系统缓存），旁证打得开就互相印证，打不开也不影响判据。 */
        if(!f->dev->is_image){
            unsigned char raw[32];
            int okr;
            memset(raw,0xCC,sizeof raw);
            okr=fat_dev_raw_read(f->dev,offc,raw,32);
            if(okr){
                memcpy(chk,raw,sizeof chk);
                okc=memcmp(raw,".          ",11)==0&&raw[11]==0x10?1:0;
                printf("  [落盘取证] 绕过系统缓存直读设备：%02X %02X %02X %02X %02X %02X %02X %02X (attr %02X)\n",
                       raw[0],raw[1],raw[2],raw[3],raw[4],raw[5],raw[6],raw[7],raw[11]);
            }else{
                printf("  [落盘取证] 无缓存句柄打不开，只能依赖缓存回读(仅证明缓存自洽)。\n");
            }
        }
        /* 比满 11 字节 —— 少比这 3 个扩展名字节，正是上面那个不合规 '.' 项溜过去的原因 */
        if(!okc||memcmp(chk,".          ",11)!=0||chk[11]!=0x10){
            printf("  [自检] 目录簇 %lu @LBA %lu 回读 ok=%d rderr=%lu : ",
                   C,(unsigned long)fat_clu_lba(f,C),okc,g_rd_err);
            for(int k=0;k<32;k++)printf("%02X ",chk[k]);
            printf("\n  [自检] 打开方式 nobuf=%d 设备扇区=%lu 写时 wfail=%d werr=%lu\n",
                   f->dev->nobuf,(unsigned long)f->dev->sector,g_wr_failed,g_wr_err);
            fat_set(f,C,0);                     /* 尚无引用，直接退回空闲 */
            snprintf(err,ecap,"创建自检失败：目录簇没正确落盘（已把该簇退回空闲）。"
                     "请把上面带 ok=/rderr= 的几行贴回来。");
            return 0;
        }
    }
    /* 根目录登记 */
    {
        const char*nm=g_special_names[which];
        unsigned char mainnm[8],ex[3]={0,0,0}; int ml=(int)strlen(nm);
        memset(mainnm,0,8);
        if(ml>8)ml=8;
        memcpy(mainnm,nm,(size_t)ml);
        fat_build_entry(ent,mainnm,ml,ex,0,0x10,C,0);
    }
    if(!fat_dir_append(f,f->rootclu,ent,&newc))goto wrfail;
    *outclu=C;
    return 1;
wrfail:
    snprintf(err,ecap,"写盘失败（创建 %s）",g_special_names[which]);
    return 0;
}

/*
 * 隐藏当前可见的特殊目录（取候选序最小的那个存活目录）：
 *   1) 首簇号写入 4 槽；槽1必须成功；
 *   2) 把根目录对应项首字节改为 0xE5。
 * FAT 表与簇数据一律不动。
 */
static int fat_sp_hide(Fat32*f,int*outWhich,unsigned long*outClu,int*outMask,char*err,size_t ecap)
{
    FatSpScan s; int mask; unsigned long clu; int which; long idx;
    FatDirBuf db={0}; unsigned char c1[32];
    fat_sp_scan(f,&s);
    if(s.live_n==0){
        snprintf(err,ecap,"当前没有可见的特殊目录（FAT/FAT1..FAT4）可隐藏");
        return 0;
    }
    which=s.live_which; clu=(unsigned long)s.live_clu; idx=s.live_idx;
    if(clu<2||clu>f->maxclu){
        snprintf(err,ecap,"特殊目录 %s 的首簇 %lu 越界",g_special_names[which],clu);
        return 0;
    }
    mask=fat_stash_write_all(f,clu);
    if(!(mask&1)){
        snprintf(err,ecap,"槽1(保留扇区末尾)写入失败，隐藏中止（已写入槽位：%s）",
                 mask? "有": "无");
        return 0;
    }
    /* 槽1 回读校验：隐藏后根目录里已没有任何存活的目录项指路，首簇只能靠 4 槽找回来；
     * “写调用报成功、回读却不是它”在物理盘上出现过，这里必须当场确认。 */
    {
        int ok1=0; unsigned long v1=fat_slot_read(f,0,&ok1);
        if(!ok1||v1!=clu){
            snprintf(err,ecap,"槽1回读校验失败（写的是 %lu，读回 ok=%d 值=%lu rderr=%lu）——"
                     "隐藏中止，根目录未被改动。",clu,ok1,v1,g_rd_err);
            return 0;
        }
    }
    /* 修改根目录项首字节 -> 0xE5 */
    if(!fat_dir_read(f,f->rootclu,&db,1)){
        snprintf(err,ecap,"读取根目录失败");return 0;
    }
    if((long)(idx+1)*32<=(long)db.len){
        db.data[(size_t)idx*32]=0xE5;
        if(fat_dir_write_back(f,f->rootclu,db.data,db.len)){
            /* 回读校验一下首字节 */
            {
                int okr=fat_rd_bytes(f->dev,fat_clu_lba(f,f->rootclu)*(unsigned long long)f->bps+
                                     (unsigned long long)idx*32,c1,1);
                if(!okr||c1[0]!=0xE5)
                    printf("  [警告] 根目录项回读校验不一致：ok=%d rderr=%lu 读到 %02X（应为 E5）。"
                           "隐藏标记可能没落盘——但槽1 已有备份，选 3 恢复即可救回；"
                           "请把这一行贴回来。\n",okr,g_rd_err,okr?c1[0]:0);
            }
            free(db.data);
            if(outWhich)*outWhich=which;
            if(outClu)*outClu=clu;
            if(outMask)*outMask=mask;
            return 1;
        }
    }
    free(db.data);
    snprintf(err,ecap,"写根目录失败（隐藏 %s）",g_special_names[which]);
    return 0;
}

/* 恢复被隐藏的特殊目录。优先取消 0xE5；否则按保存的首簇在根目录重建。 */
static int fat_sp_restore(Fat32*f,int*outWhich,unsigned long*outClu,char*err,size_t ecap)
{
    FatSpScan s; unsigned long clu=0; int w; int slot; unsigned char ent[32];
    fat_sp_scan(f,&s);
    if(s.live_n>0){
        snprintf(err,ecap,"已有可见的特殊目录（%s），无需恢复",g_special_names[s.live_which]);
        return 0;
    }
    /* 路径 A：根目录里还有我们的 0xE5 特殊目录项（链仍被 FAT 标记占用）。
     * 为了不误复活“恰好叫 CAT 之类、删除后首字符也是 0xE5”的无关目录，
     * 当 4 槽里有备份时要求该目录首簇 == 槽备份值。 */
    {
        int stslot; unsigned long stclu=fat_stash_read_cluster(f,&stslot);
        (void)stslot;
        if(s.del_which>=0&&s.del_clu>=2&&s.del_clu<=f->maxclu
           &&!(s.used_mask&(1<<s.del_which))&&fat_get(f,s.del_clu)!=0
           &&(stclu==0||stclu==(unsigned long)s.del_clu)){
        FatDirBuf db={0}; char nm[16];
        if(fat_dir_read(f,f->rootclu,&db,1)){
            const unsigned char*dn=db.data+(size_t)s.del_idx*32;
            if((s.del_idx+1)*32<=(long)db.len&&dn[0]==0xE5){
                fat_name83(dn,nm,sizeof nm);
                db.data[(size_t)s.del_idx*32]=(unsigned char)g_special_names[s.del_which][0];
                if(fat_dir_write_back(f,f->rootclu,db.data,db.len)){
                    free(db.data);
                    if(outWhich)*outWhich=s.del_which;
                    if(outClu)*outClu=(unsigned long)s.del_clu;
                    return 1;
                }
            }
            free(db.data);
        }
    }
    } /* end path A block */
    /* 路径 B：目录项槽已被占用 -> 用备份的首簇重建 */
    clu=fat_stash_read_cluster(f,&slot);
    if(!clu){
        snprintf(err,ecap,"未找到可用的首簇备份（4 个槽都没有合法簇），无法恢复");
        return 0;
    }
    w= (s.del_which>=0&&!(s.used_mask&(1<<s.del_which))) ? s.del_which : fat_pick_free_name(f);
    if(w<0){
        snprintf(err,ecap,"候选名 FAT..FAT4 均被占用，无法登记恢复的目录");
        return 0;
    }
    {
        const char*nm=g_special_names[w];
        unsigned char mainnm[8],ex[3]={0,0,0}; int ml=(int)strlen(nm);
        memset(mainnm,0,8); if(ml>8)ml=8; memcpy(mainnm,nm,(size_t)ml);
        fat_build_entry(ent,mainnm,ml,ex,0,0x10,clu,0);
    }
    if(!fat_dir_append(f,f->rootclu,ent,0)){
        snprintf(err,ecap,"在根目录登记 %s 失败",g_special_names[w]);
        return 0;
    }
    if(outWhich)*outWhich=w;
    if(outClu)*outClu=clu;
    return 1;
}

/* 解析当前应操作的“特殊目录簇”：存活则用之，否则用备份首簇（隐藏态）。 */
static int fat_sp_target_cluster(const Fat32*f,int*isHidden,unsigned long*clu,int*which)
{
    FatSpScan s; int slot;
    fat_sp_scan(f,&s);
    if(s.live_n>0){if(isHidden)*isHidden=0;if(which)*which=s.live_which;*clu=(unsigned long)s.live_clu;return 1;}
    *clu=fat_stash_read_cluster(f,&slot);
    if(*clu){if(isHidden)*isHidden=1;if(which)*which=-1;return 1;}
    return 0;
}

/* ------------------------------------------------------------------ */
/* 内容浏览 / 导出 / 注入（对隐藏或可见目录簇同样适用）                   */
/* ------------------------------------------------------------------ */

typedef struct {
    char       name[16];
    int        isdir;
    unsigned long clu;
    unsigned long size;
} FatSpEnt;

/* 列出目录 dirclu 内的文件/子目录 */
static int fat_sp_list_dir(const Fat32*f,unsigned long dirclu,FatSpEnt*out,int max)
{
    FatDirBuf db={0}; size_t i; int n=0; char nm[16];
    if(!fat_dir_read(f,dirclu,&db,1))return -1;
    for(i=0;i+32<=db.len;i+=32){
        const unsigned char*dn=db.data+i;
        if(dn[0]==0x00)break;
        if(dn[0]==0xE5)continue;
        if(dn[11]==0x0F)continue;
        if(dn[11]&0x08)continue;
        if(dn[0]==0x2E&&(dn[1]==0x20||dn[1]==0x00))continue;      /* . / .. */
        if(dn[0]==0x2E&&dn[1]==0x2E)continue;
        fat_name83(dn,nm,sizeof nm);
        if(n<max){
            snprintf(out[n].name,sizeof out[n].name,"%s",nm);
            out[n].isdir=(dn[11]&0x10)?1:0;
            out[n].clu=fat_ent_clu(dn);
            out[n].size=fat_ent_size(dn);
        }
        n++;
    }
    free(db.data);
    return n;
}

/* 在目录 dirclu 里按名找条目 */
static int fat_sp_find_in(const Fat32*f,unsigned long dirclu,const char*name,FatSpEnt*out)
{
    FatDirBuf db={0}; size_t i; char nm[16]; int r=0;
    if(!fat_dir_read(f,dirclu,&db,1))return 0;
    for(i=0;i+32<=db.len;i+=32){
        const unsigned char*dn=db.data+i;
        if(dn[0]==0x00)break;
        if(dn[0]==0xE5)continue;
        if(dn[11]==0x0F)continue;
        if(dn[11]&0x08)continue;
        fat_name83(dn,nm,sizeof nm);
        if(fat_nameeq(nm,name)){
            if(out){snprintf(out->name,sizeof out->name,"%s",nm);
                    out->isdir=(dn[11]&0x10)?1:0; out->clu=fat_ent_clu(dn); out->size=fat_ent_size(dn);}
            r=1; break;
        }
    }
    free(db.data);
    return r;
}

/* 按簇链读取 size 字节文件内容（存到 buf，调用者保证足够） */
static int fat_read_chain(const Fat32*f,unsigned long start,unsigned long size,unsigned char*buf)
{
    size_t clusz=(size_t)f->spc*f->bps;
    unsigned long c=start,left=size,off=0; int guard=0;
    FatABuf a={0};
    if(size==0)return 1;
    if(!fat_abuf_ensure(&a,clusz,f->bps))return 0;
    while(left>0){
        size_t chunk=left<clusz?left:clusz;
        if(guard++>200000)break;
        if(c<2||c>f->maxclu){fat_abuf_free(&a);return 0;}
        if(!fat_rd_sec(f->dev,fat_clu_lba(f,c),(unsigned)f->spc,a.buf)){fat_abuf_free(&a);return 0;}
        memcpy(buf+off,a.buf,chunk);
        off+=chunk; left-=chunk;
        if(left>0){c=fat_get(f,c);if(c<2){fat_abuf_free(&a);return 0;}}
    }
    fat_abuf_free(&a);
    return 1;
}

/* 导出 dirclu 内名为 name 的文件到宿主路径 host（子目录不支持） */
static int fat_sp_export(const Fat32*f,unsigned long dirclu,const char*name,
                         const char*host,char*err,size_t ecap)
{
    FatSpEnt e; unsigned char*buf=NULL; unsigned long werr=0;
    if(!fat_sp_find_in(f,dirclu,name,&e)){snprintf(err,ecap,"目录里找不到 %s",name);return 0;}
    if(e.isdir){snprintf(err,ecap,"%s 是子目录，请导出具体文件",name);return 0;}
    if(e.size>0xFFFFFFF0UL){snprintf(err,ecap,"%s 太大(>4GB)，不支持",name);return 0;}
    if(e.size==0){
        if(!fat_write_file(host,(const unsigned char*)"",0,&werr)){snprintf(err,ecap,"写文件失败 err %lu",werr);return 0;}
        return 1;
    }
    buf=(unsigned char*)malloc(e.size);
    if(!buf){snprintf(err,ecap,"内存不足");return 0;}
    if(!fat_read_chain(f,e.clu,e.size,buf)){free(buf);snprintf(err,ecap,"读取文件簇链失败");return 0;}
    if(!fat_write_file(host,buf,e.size,&werr)){free(buf);snprintf(err,ecap,"写文件失败 err %lu",werr);return 0;}
    free(buf);
    return 1;
}

/* 把宿主文件 host 注入目录 dirclu（可见/隐藏态均可）。返回文件首簇。 */
static int fat_sp_inject(Fat32*f,unsigned long dirclu,const char*host,
                         unsigned long*outclu,char*err,size_t ecap)
{
    unsigned char*file=NULL; unsigned long flen=0,ferr=0;
    const char*s,*dot=NULL; size_t stem,el; unsigned char nm[8]={0,0,0,0,0,0,0,0},ex[3]={0,0,0};
    unsigned char ent[32]; FatSpEnt fe;
    size_t clusz=(size_t)f->spc*f->bps;
    unsigned long nclu,start=0; int j;

    file=fat_read_file(host,&flen,&ferr);
    if(!file){snprintf(err,ecap,"读取宿主文件失败 err %lu",ferr);return 0;}
    if(flen==0){snprintf(err,ecap,"空文件不支持注入");free(file);return 0;}
    if(flen>0xFFFFFFF0UL){snprintf(err,ecap,"文件超过 4GB");free(file);return 0;}

    /* 拆 8.3 名：取最后一个 '/' 或 '\' 之后的部分，再按最后一个 '.' 分主名/扩展名 */
    s=host;
    {const char*p;for(p=host;*p;p++)if(*p=='/'||*p=='\\')s=p+1;}
    dot=NULL;
    {const char*p;for(p=s;*p;p++)if(*p=='.')dot=p;}
    stem=dot?(size_t)(dot-s):strlen(s);
    el=dot?(size_t)(strlen(dot+1)):0;
    if(stem==0){snprintf(err,ecap,"文件没有主名");free(file);return 0;}
    if(stem>8){snprintf(err,ecap,"主名超过 8 字节，不能以 8.3 短名登记");free(file);return 0;}
    if(el>3){snprintf(err,ecap,"扩展名超过 3 字节，不能以 8.3 短名登记");free(file);return 0;}
    memcpy(nm,s,stem); if(dot)memcpy(ex,dot+1,el);

    /* 重名检查 */
    {
        char shown[16];
        memset(shown,0,sizeof shown);
        {int i;for(i=0;i<(int)stem;i++)shown[i]=(char)nm[i];
         if(el){shown[stem]='.';for(i=0;i<(int)el;i++)shown[stem+1+i]=(char)ex[i];}}
        if(fat_sp_find_in(f,dirclu,shown,&fe)){
            snprintf(err,ecap,"目录里已有同名 %s，请改名后再注入",shown);
            free(file);return 0;
        }
    }

    nclu=(unsigned long)((flen+clusz-1)/clusz);
    {
        unsigned long*chain=(unsigned long*)calloc(nclu,sizeof(unsigned long));
        FatABuf z={0};
        if(!chain){free(file);snprintf(err,ecap,"内存不足");return 0;}
        if(!fat_abuf_ensure(&z,clusz,f->bps)){free(chain);free(file);snprintf(err,ecap,"内存不足");return 0;}
        /* 逐个分配 */
        for(j=0;j<(int)nclu;j++){
            chain[j]=(unsigned long)fat_alloc_cluster(f);
            if(!chain[j]){
                free(chain);free(file);fat_abuf_free(&z);
                snprintf(err,ecap,"空闲簇不足，无法容纳 %lu 字节的文件",flen);return 0;
            }
        }
        /* 链接 + 写数据 */
        for(j=0;j<(int)nclu;j++){
            unsigned long next=(j+1<(int)nclu)?chain[j+1]:0x0FFFFFFFUL;
            if(!fat_set(f,chain[j],next)){free(chain);free(file);fat_abuf_free(&z);snprintf(err,ecap,"写 FAT 失败");return 0;}
            memset(z.buf,0,clusz);
            {
                size_t chunk=(size_t)flen-(size_t)j*clusz; if(chunk>clusz)chunk=clusz;
                memcpy(z.buf,file+(size_t)j*clusz,chunk);
            }
            if(!fat_wr_sec(f->dev,fat_clu_lba(f,chain[j]),(unsigned)f->spc,z.buf)){
                free(chain);free(file);fat_abuf_free(&z);snprintf(err,ecap,"写数据簇失败");return 0;
            }
        }
        fat_abuf_free(&z);
        start=chain[0];
        free(chain);
    }

    /* 目录项 */
    fat_build_entry(ent,nm,(int)stem,ex,(int)el,0x20,start,flen);
    if(!fat_dir_append(f,dirclu,ent,0)){
        free(file);snprintf(err,ecap,"在目标目录登记 %s 失败",host);return 0;
    }
    free(file);
    if(outclu)*outclu=start;
    return 1;
}

/* ------------------------------------------------------------------ */
/* 便捷：打印当前状态（供菜单/复用）                                     */
/* ------------------------------------------------------------------ */

static void fat_sp_print_status(const Fat32*f)
{
    FatSpScan s; unsigned long stash=0; int i;
    char c1[32];
    fat_sp_scan(f,&s);
    fat_stash_present(f,&stash);

    printf("\n  == 特殊目录状态 ==\n");
    printf("  可见的特殊目录(FAT/FAT1..FAT4)：");
    if(s.live_n==0)printf("无\n");
    else printf("共 %d 个；最小序 %s，首簇 %lu（根目录项索引 %ld）\n",
                s.live_n,g_special_names[s.live_which],
                (unsigned long)s.live_clu,(long)s.live_idx);
    printf("  已删除(0xE5)的特殊目录项：");
    if(s.del_n==0)printf("无\n");
    else printf("共 %d 个；首个 %s，内嵌首簇 %lu\n",
                s.del_n,s.del_which>=0?g_special_names[s.del_which]:"?",
                (unsigned long)s.del_clu);
    printf("  4 个首簇备份槽：\n");
    for(i=0;i<4;i++){
        unsigned long long ab; unsigned long v; int ok;
        v=fat_slot_read(f,i,&ok);
        if(fat_slot_pos(f,i,&ab)){
            snprintf(c1,sizeof c1,"LBA 偏移 %llu",ab);
            printf("    槽%d %-14s @ %s : ",i+1,fat_slot_label(i),c1);
            if(ok){
                if(v>=2&&v<=f->maxclu)printf("保存首簇 %lu\n",v);
                else printf("数值 %lu（非合法簇）\n",v);
            } else printf("读取失败\n");
        } else printf("    槽%d %-14s : 不适用（自动跳过）\n",i+1,fat_slot_label(i));
    }
    if(s.live_n==0){
        if(stash)printf("  -> 判定：目录已被隐藏（备份首簇 %lu）。可浏览/导出/注入，或“恢复”。\n",stash);
        else if(s.del_n>0)printf("  -> 判定：根目录有已删除的特殊项（可能是用户删掉的，其簇可能已释放，谨慎处理）。\n");
        else printf("  -> 判定：当前没有特殊目录。可先“创建”。\n");
    } else {
        printf("  -> 判定：目录可见，可往其中放文件后“隐藏”。\n");
    }
}

#endif /* FAT_ENGINE_SCHEME1：方案一 高层操作 */

/* 卷几何与分配诊断（用于排障：报“数据区已满”时看这里）——两方案共用 */
static void fat_diag_geometry(const Fat32*f)
{
    unsigned char boot[512]; unsigned fsi; int i;
    unsigned long long c,end; int found=0;
    printf("\n  == 卷几何诊断（排障用）==\n");
    printf("    bps=%u spc=%u rsvd=%llu nfat=%u fatsz=%llu rootclu=%llu\n",
           f->bps,f->spc,(unsigned long long)f->rsvd,f->nfat,
           (unsigned long long)f->fatsz,(unsigned long long)f->rootclu);
    printf("    分区起始LBA=%llu 分区扇区=%llu\n    fat0_lba=%llu datalba=%llu maxclu=%llu 设备扇区=%luB\n",
           (unsigned long long)f->part_lba,(unsigned long long)f->part_secs,
           (unsigned long long)f->fat0_lba,(unsigned long long)f->datalba,
           (unsigned long long)f->maxclu,(unsigned long)f->dev->sector);
    printf("    FAT[2..9]（期望簇2≈0x0FFFFFFF，其后若空闲应为0）：");
    for(i=2;i<=9;i++)printf(" %lu",fat_get(f,(ULONGLONG)i));
    printf("\n");
    if(!fat_rd_bytes(f->dev,f->part_lba*(unsigned long long)f->bps,boot,512)){
        printf("    (读引导扇区失败)\n");return;
    }
    fsi=fat_rd16(boot+0x30);
    printf("    FSInfo扇区(相对分区)=%u",fsi);
    if(fsi>=1&&fsi<f->rsvd){
        FatABuf a={0};
        if(fat_abuf_ensure(&a,f->bps,f->bps)&&fat_rd_sec(f->dev,f->part_lba+fsi,1,a.buf)){
            unsigned char*p=(unsigned char*)a.buf;
            if(fat_rd32(p)==0x41615252UL)
                printf("   空闲簇数=%lu   下一个空闲簇=%lu",
                       fat_rd32(p+0x1E8),fat_rd32(p+0x1E4));
            else printf("   (签名不符)");
        } else printf("   (读失败)");
        fat_abuf_free(&a);
    }
    printf("\n");
    /* 快速前扫：最多 2000 簇，找前几个空闲簇 */
    end=f->maxclu; if(end>2000)end=2000;
    printf("    从簇2扫到簇%llu，空闲簇有：",(unsigned long long)end);
    for(c=2;c<=end;c++){
        if(fat_get(f,c)==0){printf(" %llu",(unsigned long long)c);if(++found>=8)break;}
    }
    if(found==0)printf(" 无");
    printf("\n    -> 若上面 FAT[2..9] 里出现非预期值，或这里一个空闲簇都找不到，说明 FAT 位置/几何读取不对或卷确实写保护/占满。\n");
}

/* ==================================================================== */
/* 方案二：坏簇私有文件系统引擎（fat_b_*）——依附于 FAT32、自建自用        */
/* ==================================================================== */
/*
 * 与方案一的本质区别：方案二不靠“删目录项+保 FAT 链”，而是把要保密的簇在
 * FAT 表里直接标记为 0x0FFFFFF7“坏簇”。chkdsk 等“孤儿簇回收”工具不会把
 * 坏簇当孤儿/空闲簇处理，因此比方案一更抗 chkdsk（这正是用户所述方案二动机）。
 *
 * 私有文件系统布局（全部宿主在“被标坏的真实簇”里）：
 *   数据簇   —— 保存文件字节的若干真实簇，真实 FAT 项 = 0x0FFFFFF7。
 *   链簇     —— 每个文件一条“私有链簇链”，按顺序存该文件各数据簇的真实簇号
 *              （每 4 字节一个），簇末 4 字节 = NEXT 下一链簇真实簇号（0=尾）。
 *              链簇可无限续接，故单文件大小不再受“一个簇装多少表项”限制。
 *   注册表簇 —— F2FT，一张共享、可长大的表：行[S] = 文件 S 的“私有链头簇”真实
 *              簇号（0=空闲）。每簇 (簇字节-16)/4 行；行满可再偷一簇，头 +12
 *              存 NEXT 串起来（本几何下目录容量 ≤ 注册表行数，通常一簇足够）。
 *   目录簇   —— F2DR，一条记录 32 字节（复用 FAT 8.3 名字/属性/大小字段），
 *              “簇号”字段存【全局槽号 G】而不是簇号。目录簇本身也可串链，
 *              与注册表簇对称；槽号是全局的，跨簇连续编号。
 *   长文件名 —— 一条记录前可跟若干 attr=0x0F 的 LFN 项（13 个 UTF-16 码元/项，
 *              倒序、最高序带 0x40、字节 13 存 8.3 校验和），与 FAT32 规范一致。
 *
 * 找回链：4 槽(槽1..槽4)→自定义目录簇号 → 目录簇头 +8 →注册表头簇 →
 *         行[G] → 私有链头簇 → 逐链簇读出数据簇真实簇号 → 读到文件字节。
 *         只持久化两个簇号(目录簇、注册表头簇)，其余全靠链自描述。
 * 文件长度存在目录记录 +0x1C（u32），块数 nb=ceil(长度/簇字节)，链上只数 nb 项，
 * 不用结束符；删除/清除时按结构（链簇 NEXT 到 0）把数据簇与链簇全部还回 FAT32。
 *
 * 目录簇头(16B)：+0 "F2DR"  +4 版本  +8 注册表头簇真实簇号(仅头簇)  +12 NEXT 目录簇(0=尾)
 * 注册表头(16B)：+0 "F2FT"  +4 版本  +8 保留(0)  +12 NEXT 注册表簇真实簇号(0=尾)
 * 链簇(无头)   ：+0 起每 4B 一数据簇真实簇号；末 4B = NEXT 链簇真实簇号(0=尾)
 *
 * 【全局槽号 G】目录链第 k 个簇里的第 i 条记录，槽号 G = k*ndir + i（ndir=每簇记录数）。
 * 记录里的“簇号”字段与注册表行号都用 G：有了 LFN 后一个文件占多个连续槽，
 * 只有按“槽”编号才能让“文件 ↔ 注册表行”一一对应（行 G 属于短名项所在的那个槽）。
 * 注册表每簇行数 rpc ≈ 8×ndir，所以注册表链比目录链长得慢；目录链要长到第 k 簇时，
 * 若注册表还没有第 (k*ndir+i)/rpc 行，fat_b_reg_ensure() 会自动把注册表链补够。
 *
 * 【短名 vs 长名】名字能塞进 8.3（≤8.3、纯 ASCII、每段大小写一致）时**只写短名项**，
 * 不写 LFN——这样 a.txt/b.bin 这类旧用例的盘上格式与老版本逐字节相同。大小写不一
 * 致的段靠目录项字节 12 的 NT 大小写标志(0x08=主名小写/0x10=扩展名小写)还原显示。
 * 只有真长名/非 ASCII/大小写混杂才写 LFN 链，并同时生成一个 `XXXXXX~N.EXT` 短名别名
 * （别名要保证在私有目录里唯一；名字本身与别名的重名检查都做）。
 *
 * 引擎函数仅供方案二宿主调用（fat1.cpp 在 include 前 #define FAT_ENGINE_SCHEME2）。
 */
#ifdef FAT_ENGINE_SCHEME2

#define FATB_MAGIC_DIR    "F2DR"      /* 自定义目录簇头魔数 */
#define FATB_MAGIC_REG    "F2FT"      /* 注册表簇头魔数     */
#define FATB_VERSION      2u          /* 2 = 目录簇可串链 + 全局槽号 + LFN（1 的盘仍可读） */
#define FATB_HDR          16u         /* 两种元数据簇头字节数 */
#define FATB_BAD          0x0FFFFFF7UL/* 真实 FAT 里“坏簇”值（不被chkdsk回收） */
static int fat_tolower(int c){return (c>='A'&&c<='Z')?c+32:c;}

#define FATB_ATTR_LFN     0x0Fu       /* 长文件名目录项属性 */
#define FATB_LFN_MAX      255         /* FAT 规范：长名最多 255 个 UTF-16 码元 */
#define FATB_LFN_PER      13          /* 每个 LFN 项装 13 个码元 */
#define FATB_LFN_ENTS     ((FATB_LFN_MAX+FATB_LFN_PER-1)/FATB_LFN_PER)  /* =20 */

typedef struct {
    char          name[128];    /* 显示名(UTF-8)：有 LFN 用长名，否则是 8.3 短名 */
    char          alias[16];    /* 有 LFN 时同时给出自动生成的 8.3 短名别名，否则空串 */
    unsigned long first;        /* 目录记录“簇号”字段里存的【全局槽号 G】(注册表行号) */
    unsigned long size;         /* 文件字节长度 */
    unsigned long chunks;       /* 数据块个数 nb = ceil(size/簇字节) */
    unsigned long firstreal;    /* 首数据块的【真实簇号】（已标坏） */
} FatBEnt;

/* 每簇行数 / 每链簇条目数（簇字节数给定） */
static unsigned long fat_b_rpc(size_t clusz){return (unsigned long)((clusz-FATB_HDR)/4);}
static unsigned long fat_b_epc(size_t clusz){return (unsigned long)((clusz-4)/4);}

/* 整簇读/写（按真实簇号定位到其 LBA） */
static int fat_b_cluster_read(const Fat32*f,unsigned long real,void*buf)
{return fat_rd_sec(f->dev,fat_clu_lba(f,real),(unsigned)f->spc,buf);}
static int fat_b_cluster_write(const Fat32*f,unsigned long real,const void*buf)
{return fat_wr_sec(f->dev,fat_clu_lba(f,real),(unsigned)f->spc,buf);}

/* 偷簇用游标：记住上次扫到哪，避免每次从簇 2 重扫（大卷上会非常慢）。 */
static unsigned long g_b_scan_from=2;

/* —— 批量偷簇用的一扇区 FAT 缓存 ——
 * 扫描/置位的最小单位本来就是「一个 FAT 扇区」（bps 字节里装 bps/4 个入口），
 * 逐簇调用等于把同一个扇区反复读改写：真机导入 61MB(14973 数据簇) 时，
 * 光是记账就 ~8 次设备操作/簇 ≈ 12 万次，是导入慢的主因。
 * 这里让同一扇区在一次批处理里只读一次/写一次。 */
typedef struct {
    const Fat32  *f;
    FatABuf       buf;     /* bps 字节的扇区缓冲 */
    unsigned long copy;    /* 已装载的是第几份 FAT 拷贝 */
    ULONGLONG     s;       /* 已装载的扇区号（该拷贝内相对扇区号） */
    int           dirty;   /* 缓冲被改过、尚未写回 */
} FatBCache;

/* 装载 (copy,s)；(ULONGLONG)-1 表示“空”。上一扇区脏则先写回。 */
static int fat_b_cache_load(FatBCache*c,unsigned long copy,ULONGLONG s)
{
    const Fat32*f=c->f;
    if(c->buf.buf&&c->s==s&&c->copy==copy)return 1;
    if(c->dirty){
        if(!fat_wr_sec(f->dev,f->fat0_lba+(ULONGLONG)c->copy*f->fatsz+c->s,1,c->buf.buf))return 0;
        c->dirty=0;
    }
    if(!fat_abuf_ensure(&c->buf,f->bps,f->bps))return 0;
    if(!fat_rd_sec(f->dev,f->fat0_lba+(ULONGLONG)copy*f->fatsz+s,1,c->buf.buf))return 0;
    c->copy=copy;c->s=s;
    return 1;
}

/* 写回脏扇区 */
static int fat_b_cache_flush(FatBCache*c)
{
    const Fat32*f=c->f;
    if(!c->dirty)return 1;
    if(!fat_wr_sec(f->dev,f->fat0_lba+(ULONGLONG)c->copy*f->fatsz+c->s,1,c->buf.buf))return 0;
    c->dirty=0;
    return 1;
}

/* 一次偷 n 个空闲真实簇（性能路径；语义与原先的逐簇偷取完全一致）：
 *   每个簇在【全部】FAT 拷贝里置 0x0FFFFFF7“坏簇”（非 EOF，chkdsk 不会当孤儿/空闲簇回收），
 *   FSInfo 空闲计数 -= 实际偷到的个数。
 * 只是把记账从「每簇一次 FAT 扇区读改写 + 每簇一次 FSInfo 读改写」改成
 * 「每个受影响的 FAT 扇区一次读改写 + 每批一次 FSInfo」。
 * out[] 需能放 n 项；返回实际偷到的个数，<n 表示空闲簇不够（调用方照常登记/回滚）。 */
static unsigned long fat_b_steal_n(const Fat32*f,unsigned long*out,unsigned long n)
{
    unsigned long got=0,end,i,copy;
    int pass,fail=0,marked=0;
    FatBCache sc={0},mc={0};

    if(!f||!out||!n)return 0;
    end=f->maxclu;
    if(f->bps<4||f->nfat==0||end<2)return 0;
    sc.f=f; sc.s=(ULONGLONG)-1;
    mc.f=f; mc.s=(ULONGLONG)-1;

    /* 1) 收集 n 个空闲簇：读 FAT 拷贝 0，每扇区只读一次。两趟与逐簇版同序：
     *    先扫游标之后，不够再折回簇 2 扫到游标之前（最坏一次全扫，保证不漏）。 */
    for(pass=0;pass<2&&got<n;pass++){
        ULONGLONG lo=(pass==0)?(ULONGLONG)g_b_scan_from:2;
        ULONGLONG hi=(pass==0)?(ULONGLONG)end
                              :((g_b_scan_from>2)?(ULONGLONG)g_b_scan_from-1:1);
        ULONGLONG c;
        for(c=lo;c<=hi&&got<n;c++){
            ULONGLONG byte=c*4;
            ULONGLONG s=byte/(ULONGLONG)f->bps;
            unsigned off=(unsigned)(byte%(ULONGLONG)f->bps);
            if(off+4>f->bps)continue;      /* 入口跨扇区：不批量，跳过（本簇由后续批次处理） */
            if(!fat_b_cache_load(&sc,0,s)){fail=1;break;}
            if((fat_rd32((unsigned char*)sc.buf.buf+off)&0x0FFFFFFFUL)==0)
                out[got++]=(unsigned long)c;
        }
    }

    /* 2) 在【每一份】FAT 拷贝里把这些入口置 BAD：每扇区 1 读 + 1 写（拷贝在外层，
     *    这样同一拷贝的簇号由小到大跑，缓存不抖动）。 */
    if(!fail&&got){
        marked=1;
        for(copy=0;copy<f->nfat&&!fail;copy++){
            for(i=0;i<got;i++){
                ULONGLONG byte=(ULONGLONG)out[i]*4;
                ULONGLONG s=byte/(ULONGLONG)f->bps;
                unsigned off=(unsigned)(byte%(ULONGLONG)f->bps);
                unsigned char*p;
                if(!fat_b_cache_load(&mc,copy,s)){fail=1;break;}
                p=(unsigned char*)mc.buf.buf+off;
                fat_wr32(p,(fat_rd32(p)&0xF0000000UL)|FATB_BAD);
                mc.dirty=1;
            }
        }
        if(!fail&&!fat_b_cache_flush(&mc))fail=1;
    }

    if(!fail&&got){
        /* FSInfo 每批只调一次（每次 = 读引导扇区 + 读 FSInfo + 写 FSInfo） */
        unsigned long left=got;
        while(left){
            int d=(left>1000000UL)?1000000:(int)left;
            fat_fsinfo_adjust(f,-d);
            left-=(unsigned long)d;
        }
        g_b_scan_from=(out[got-1]<end)?(unsigned long)(out[got-1]+1):2;
        fat_abuf_free(&sc.buf);fat_abuf_free(&mc.buf);
        return got;
    }

    /* 失败：这批簇原本都是【空闲 = FAT 项 0】，把已经写下去的一律改回 0 即可还原；
     * FSInfo 尚未调整，所以不用补回。（若连改回 0 也写不下去——设备已在丢写——
     * 那这些簇会残留为坏簇，属于设备层面的故障，非本函数能兜住。） */
    if(marked){
        for(i=0;i<got;i++)fat_set(f,out[i],0);
    }
    fat_abuf_free(&sc.buf);fat_abuf_free(&mc.buf);
    return 0;
}

/* 偷一个空闲真实簇：走批量路径的 n=1，保证批量代码始终被覆盖到。 */
static unsigned long fat_b_steal(const Fat32*f)
{
    unsigned long c=0;
    if(fat_b_steal_n(f,&c,1)!=1)return 0;
    return c;
}

/* 批量释放：把 out[0..n) 里合法的簇号一次性还回空闲
 * （FAT 项置 0、保留高 4 位；FSInfo 空闲数 += 实际释放数）。
 * 语义与逐簇释放完全一致，只是记账合并成「每个受影响的 FAT 扇区一次读改写 + 每批一次
 * FSInfo」——删除/清除大文件时与偷簇是同一个量级的开销，同样必须批量化。
 * 每个 FAT 拷贝各持一个扇区缓存；同一拷贝里簇号由小到大跑时缓存不抖动。
 * 返回实际释放的簇数。 */
static unsigned long fat_b_release_n(const Fat32*f,const unsigned long*out,unsigned long n)
{
    unsigned long i,done=0,copy,left;
    FatBCache *mc;

    if(!f||!out||!n)return 0;
    if(f->bps<4||f->nfat==0)return 0;
    mc=(FatBCache*)calloc(f->nfat,sizeof(FatBCache));
    if(!mc)return 0;
    for(copy=0;copy<f->nfat;copy++){mc[copy].f=f;mc[copy].s=(ULONGLONG)-1;}

    for(i=0;i<n;i++){
        unsigned long c=out[i]; ULONGLONG byte,s; unsigned off; int ok=1;
        if(c<2||c>f->maxclu)continue;          /* 非法簇号：与逐簇版一样跳过 */
        byte=(ULONGLONG)c*4;
        s=byte/(ULONGLONG)f->bps;
        off=(unsigned)(byte%(ULONGLONG)f->bps);
        if(off+4>f->bps)continue;              /* 入口跨扇区：BPB 损坏才可能（bps 必被 4 整除） */
        for(copy=0;copy<f->nfat;copy++){
            unsigned char*p;
            if(!fat_b_cache_load(&mc[copy],copy,s)){ok=0;break;}
            p=(unsigned char*)mc[copy].buf.buf+off;
            fat_wr32(p,fat_rd32(p)&0xF0000000UL);   /* 置 0，保留高 4 位（同 fat_set） */
            mc[copy].dirty=1;
        }
        if(!ok)break;
        done++;
    }
    /* 写回脏扇区。写失败无法在这里回滚——但这些簇本来就是空闲簇，最坏只是“没释放成功”，
     * 不会把已占用的簇改错；FSInfo 是提示值，chkdsk 会重算，不为此再叠一层补偿逻辑。 */
    for(copy=0;copy<f->nfat;copy++)fat_b_cache_flush(&mc[copy]);
    for(copy=0;copy<f->nfat;copy++)fat_abuf_free(&mc[copy].buf);
    free(mc);

    if(done){
        left=done;
        while(left){int d=(left>1000000UL)?1000000:(int)left;fat_fsinfo_adjust(f,d);left-=(unsigned long)d;}
        g_b_scan_from=2;    /* 有簇被释放，回到簇 2 重扫以便立刻再复用它们 */
    }
    return done;
}

/* 把一个被标坏的真实簇还回空闲：走批量路径的 n=1，保证批量代码始终被覆盖到。 */
static void fat_b_release(const Fat32*f,unsigned long real)
{
    fat_b_release_n(f,&real,1);
}

/* 探测私有文件系统是否“在位”：4 槽里取到合法簇号 -> 目录簇头魔数 F2DR ->
 * 目录簇头 +8 得注册表头簇号 -> 其头魔数 F2FT 校验。全部通过才算在位。 */
static int fat_b_probe(const Fat32*f,unsigned long*dirclu,unsigned long*regclu,int*fromslot)
{
    unsigned char hd[16]; unsigned long clu,rclu; int slot;
    size_t clusz;
    if(!f||f->maxclu<2)return 0;
    clusz=(size_t)f->spc*f->bps;
    if(clusz<64)return 0;
    clu=fat_stash_read_cluster(f,&slot);
    if(clu<2||clu>f->maxclu)return 0;
    if(!fat_rd_bytes(f->dev,fat_clu_lba(f,clu)*(unsigned long long)f->bps,hd,16))return 0;
    if(memcmp(hd,FATB_MAGIC_DIR,4)!=0)return 0;
    if(fat_rd32(hd+4)<1||fat_rd32(hd+4)>FATB_VERSION)return 0;   /* 版本 1(单簇) 与 2(串链+LFN) 都收 */
    rclu=fat_rd32(hd+8);
    if(rclu<2||rclu>f->maxclu)return 0;
    if(!fat_rd_bytes(f->dev,fat_clu_lba(f,rclu)*(unsigned long long)f->bps,hd,16))return 0;
    if(memcmp(hd,FATB_MAGIC_REG,4)!=0)return 0;
    if(dirclu)*dirclu=clu;
    if(regclu)*regclu=rclu;
    if(fromslot)*fromslot=slot;
    return 1;
}

/* 打开元数据：读出整目录簇到对齐缓冲 d，返回目录簇号/注册表头簇号/簇字节
 * 大小/目录记录数 ndir。err 可为 NULL。 */
static int fat_b_open_meta(const Fat32*f,unsigned long*dirclu,unsigned long*regclu,
                           FatABuf*d,size_t*cluszp,int*ndirp,char*err,size_t ecap)
{
    unsigned long dclu,rclu; size_t clusz=(size_t)f->spc*f->bps;
    if(!fat_b_probe(f,&dclu,&rclu,0)){
        if(err)snprintf(err,ecap,"当前没有私有文件系统（4 槽里没有可用的自定义目录簇备份）。请先执行“初始化”。");
        return 0;
    }
    if(clusz<=FATB_HDR){
        if(err)snprintf(err,ecap,"簇太小(%lu 字节)，放不下元数据头",(unsigned long)clusz);
        return 0;
    }
    if(d){
        if(!fat_abuf_ensure(d,clusz,f->bps)){
            if(err)snprintf(err,ecap,"内存不足");
            return 0;
        }
        if(!fat_b_cluster_read(f,dclu,d->buf)){
            if(err)snprintf(err,ecap,"读自定义目录簇失败");
            return 0;
        }
    }
    if(dirclu)*dirclu=dclu;
    if(regclu)*regclu=rclu;
    if(cluszp)*cluszp=clusz;
    if(ndirp)*ndirp=(int)((clusz-FATB_HDR)/32);
    return 1;
}

/* ====================================================================
 * 目录链层：目录簇也是“可串链”的，槽号是全局的 G = k*ndir + i
 * ==================================================================== */

/* 目录链第 k 个簇的真实簇号（k=0 即头簇）；失败返回 0。只读每簇 16 字节头。 */
static unsigned long fat_b_dir_cluster(const Fat32*f,unsigned long head,unsigned long long k)
{
    unsigned long cur=head; unsigned long long j; unsigned char hd[16];
    if(head<2||head>f->maxclu)return 0;
    for(j=0;j<k;j++){
        unsigned long nx;
        if(!fat_rd_bytes(f->dev,fat_clu_lba(f,cur)*(unsigned long long)f->bps,hd,16))return 0;
        nx=fat_rd32(hd+12);
        if(nx<2||nx>f->maxclu)return 0;
        cur=nx;
    }
    return cur;
}

/* 目录链长（簇数，含头簇） */
static unsigned long long fat_b_dir_count(const Fat32*f,unsigned long head)
{
    unsigned long cur=head; unsigned long long n=0; unsigned char hd[16];
    while(cur>=2&&cur<=f->maxclu&&n<1000000ULL){
        n++;
        if(!fat_rd_bytes(f->dev,fat_clu_lba(f,cur)*(unsigned long long)f->bps,hd,16))break;
        cur=fat_rd32(hd+12);
    }
    return n?n:1;
}

/* 目录链尾追加一簇（偷簇→格式化→串接→写回）。成功返回新簇号；失败写 *why 返回 0。 */
static unsigned long fat_b_dir_append(const Fat32*f,unsigned long head,size_t clusz,
                                      const char**why)
{
    unsigned long cur=head,tail=head,newc; unsigned long long n=0; unsigned char hd[16];
    FatABuf t={0};
    if(why)*why="";
    while(cur>=2&&cur<=f->maxclu&&n<1000000ULL){
        tail=cur; n++;
        if(!fat_rd_bytes(f->dev,fat_clu_lba(f,cur)*(unsigned long long)f->bps,hd,16)){
            if(why)*why="读目录簇头失败";
            return 0;}
        cur=fat_rd32(hd+12);
    }
    newc=fat_b_steal(f);
    if(!newc){if(why)*why="卷上无空闲真实簇可给目录扩容";return 0;}
    if(!fat_abuf_ensure(&t,clusz,f->bps)){
        fat_b_release(f,newc);if(why)*why="内存不足";return 0;}
    memset(t.buf,0,clusz);
    memcpy(t.buf,FATB_MAGIC_DIR,4);
    fat_wr32((unsigned char*)t.buf+4,FATB_VERSION);
    fat_wr32((unsigned char*)t.buf+8,0);            /* 扩展簇不记注册表头 */
    fat_wr32((unsigned char*)t.buf+12,0);           /* 自己暂时是尾 */
    if(!fat_b_cluster_write(f,newc,t.buf)){
        fat_b_release(f,newc);fat_abuf_free(&t);
        if(why)*why="写新目录簇失败";
        return 0;}
    if(!fat_b_cluster_read(f,tail,t.buf)){          /* 尾簇的 +12 指向新簇 */
        fat_b_release(f,newc);fat_abuf_free(&t);
        if(why)*why="读目录尾簇失败";
        return 0;}
    fat_wr32((unsigned char*)t.buf+12,newc);
    if(!fat_b_cluster_write(f,tail,t.buf)){
        fat_b_release(f,newc);fat_abuf_free(&t);
        if(why)*why="串接新目录簇失败";
        return 0;}
    fat_abuf_free(&t);
    return newc;
}

/* 目录槽访问上下文：一次只驻留一个目录簇，按全局槽号 G 定位。
 * 注意：fat_b_slot() 可能把别的簇换进来，返回的指针随即失效——
 * 调用方若要跨多次取槽，必须先把 32 字节 memcpy 到自己的缓冲里。 */
typedef struct {
    const Fat32       *f;
    unsigned long      head;
    size_t             clusz;
    int                ndir;
    unsigned long long nclu;
    unsigned long long curk;
    int                dirty;
    FatABuf            buf;
} FatBDir;

static int fat_b_dir_flush(FatBDir*b)
{
    unsigned long c;
    if(!b||!b->dirty)return 1;
    c=fat_b_dir_cluster(b->f,b->head,b->curk);
    if(!c)return 0;
    if(!fat_b_cluster_write(b->f,c,b->buf.buf))return 0;
    b->dirty=0;
    return 1;
}

static int fat_b_dir_open(FatBDir*b,const Fat32*f,unsigned long head,size_t clusz,int ndir)
{
    if(!b)return 0;
    memset(b,0,sizeof *b);
    b->f=f; b->head=head; b->clusz=clusz; b->ndir=ndir;
    b->curk=(unsigned long long)-1;
    if(ndir<=0||clusz<=FATB_HDR)return 0;
    if(!fat_abuf_ensure(&b->buf,clusz,f->bps))return 0;
    b->nclu=fat_b_dir_count(f,head);
    return 1;
}

static void fat_b_dir_close(FatBDir*b)
{
    if(!b)return;
    fat_b_dir_flush(b);
    fat_abuf_free(&b->buf);
    b->curk=(unsigned long long)-1;
}

static int fat_b_dir_loadk(FatBDir*b,unsigned long long k)
{
    unsigned long c;
    if(b->curk==k)return 1;
    if(!fat_b_dir_flush(b))return 0;
    c=fat_b_dir_cluster(b->f,b->head,k);
    if(!c)return 0;
    if(!fat_b_cluster_read(b->f,c,b->buf.buf))return 0;
    b->curk=k;
    b->dirty=0;
    return 1;
}

/* 取全局槽 G 的 32 字节指针；失败 NULL */
static unsigned char*fat_b_slot(FatBDir*b,unsigned long long G)
{
    unsigned long long k; unsigned i;
    if(!b||b->ndir<=0)return 0;
    k=G/(unsigned long long)b->ndir;
    i=(unsigned)(G%(unsigned long long)b->ndir);
    if(k>=b->nclu)return 0;
    if(!fat_b_dir_loadk(b,k))return 0;
    return (unsigned char*)b->buf.buf+FATB_HDR+(size_t)32*i;
}

/* 同上，但标记脏（内容改完后由 flush/close 落盘） */
static unsigned char*fat_b_slot_w(FatBDir*b,unsigned long long G)
{
    unsigned char*p=fat_b_slot(b,G);
    if(p)b->dirty=1;
    return p;
}

/* 找一个文件的 nslots 个【连续】空闲槽（必须落在同一簇内，长名链才不会跨簇断掉）；
 * 整条目录链都找不到就给目录链尾追加一簇（新簇全空，必然够）。
 * 只找不写——真正的目录项等文件数据都落盘后才由调用方一次性写入。 */
static int fat_b_slot_alloc_run(FatBDir*bd,int nslots,unsigned long long*outG,
                                char*err,size_t ecap)
{
    unsigned long long k; int i,t;
    if(nslots<1||nslots>bd->ndir){
        if(err)snprintf(err,ecap,"名字太长：要占 %d 个连续目录槽，超过每簇 %d 槽",
                        nslots,bd->ndir);
        return 0;
    }
    for(k=0;k<bd->nclu;k++){
        for(i=0;i+nslots<=bd->ndir;i++){
            int freeall=1;
            for(t=0;t<nslots;t++){
                const unsigned char*p=
                    fat_b_slot(bd,k*(unsigned long long)bd->ndir+(unsigned long long)(i+t));
                if(!p||(p[0]!=0x00&&p[0]!=0xE5)){freeall=0;break;}
            }
            if(freeall){
                *outG=k*(unsigned long long)bd->ndir+(unsigned long long)(i+nslots-1);
                return 1;
            }
        }
    }
    {   /* 整条链都没有连续空位 → 追加一簇 */
        const char*why="";
        unsigned long nc=fat_b_dir_append(bd->f,bd->head,bd->clusz,&why);
        if(!nc){if(err)snprintf(err,ecap,"目录记录已满，且%s",why);return 0;}
        bd->nclu++;
        *outG=(bd->nclu-1)*(unsigned long long)bd->ndir+(unsigned long long)(nslots-1);
        return 1;
    }
}

/* ====================================================================
 * 名字层：UTF-8 <-> UTF-16、LFN 项读写、8.3 别名生成
 * ==================================================================== */

static int fat_utf8_to_w(const char*s,wchar_t*out,int cap)
{
    int n;
    if(!s||!out||cap<=0)return -1;
    n=MultiByteToWideChar(CP_UTF8,0,s,-1,out,cap);
    if(n<=0)return -1;
    return n-1;
}
static int fat_w_to_utf8(const wchar_t*w,int wlen,char*out,int cap)
{
    int n;
    if(!w||!out||cap<=0)return -1;
    n=WideCharToMultiByte(CP_UTF8,0,w,wlen,out,cap,NULL,NULL);
    if(n<=0){out[0]=0;return -1;}
    if(n>=cap)out[cap-1]=0; else out[n]=0;
    return n;
}

/* 8.3 短名的 11 字节校验和（FAT 规范；LFN 项字节 13 存它） */
static unsigned char fat_lfn_ck(const unsigned char*nm11)
{
    unsigned char s=0; int i;
    for(i=0;i<11;i++)
        s=(unsigned char)((((s&1)?0x80:0x00)+(s>>1)+nm11[i])&0xFF);
    return s;
}

/* LFN 项里第 i 个(0..12)码元的字节偏移 */
static int fat_lfn_off(int i){return (i<5)?(1+2*i):((i<11)?(14+2*(i-5)):(28+2*(i-11)));}

/* 造一条 LFN 项：ord 从 1 起，last=最高序(带 0x40)；不足处 0x0000 结束 + 0xFFFF 填充 */
static void fat_lfn_entry(unsigned char e[32],const wchar_t*lfn,int llen,
                          int ord,int last,unsigned char ck)
{
    int base=(ord-1)*FATB_LFN_PER, i;
    memset(e,0,32);
    e[0]=(unsigned char)(ord|(last?0x40:0));
    e[11]=FATB_ATTR_LFN;
    e[13]=ck;
    for(i=0;i<FATB_LFN_PER;i++){
        int p=base+i, off=fat_lfn_off(i);
        unsigned short v;
        if(p<llen)v=(unsigned short)lfn[p];
        else if(p==llen)v=0x0000;
        else v=0xFFFF;
        e[off]=(unsigned char)(v&0xFF);
        e[off+1]=(unsigned char)((v>>8)&0xFF);
    }
}

/* 槽 Gshort 前面【连续、合法、属于该短名项】的 LFN 项数（0 = 没有 LFN）。
 * 判据：属性 0x0F + 字节13 校验和相符 + 序号从 1 起逐项加一 + 有一项带 0x40 收尾。 */
static int fat_b_lfn_span(FatBDir*bd,unsigned long long Gshort,const unsigned char*shortrec)
{
    unsigned char ck; int step;
    if(!bd||!shortrec)return 0;
    ck=fat_lfn_ck(shortrec);
    for(step=1;step<=FATB_LFN_ENTS;step++){
        const unsigned char*p;
        if(Gshort<(unsigned long long)step)return 0;
        p=fat_b_slot(bd,Gshort-(unsigned long long)step);
        if(!p)return 0;
        if(p[11]!=FATB_ATTR_LFN)return 0;
        if(p[13]!=ck)return 0;
        if((int)(p[0]&0x3F)!=step)return 0;
        if(p[0]&0x40)return step;
    }
    return 0;
}

/* 拼长名到 out（UTF-16）；返回码元数(>0)或 0(没有 LFN) */
static int fat_b_lfn_read(FatBDir*bd,unsigned long long Gshort,
                          const unsigned char*shortrec,wchar_t*out,int outcap)
{
    wchar_t tmp[FATB_LFN_ENTS*FATB_LFN_PER];
    int n=0,step,i,need;
    if(!out||outcap<=0)return 0;
    n=fat_b_lfn_span(bd,Gshort,shortrec);
    if(n<=0){out[0]=0;return 0;}
    for(step=1;step<=n;step++){
        const unsigned char*p=fat_b_slot(bd,Gshort-(unsigned long long)step);
        if(!p)return 0;
        for(i=0;i<FATB_LFN_PER;i++){
            int off=fat_lfn_off(i);
            tmp[(step-1)*FATB_LFN_PER+i]=(wchar_t)(unsigned)(p[off]|(p[off+1]<<8));
        }
    }
    need=n*FATB_LFN_PER;
    for(i=0;i<need;i++){
        if(tmp[i]==0x0000)break;
        if(i>=outcap-1)break;
        out[i]=tmp[i];
    }
    out[i]=0;
    return i;
}

/* 8.3 短名的显示形式：按目录项字节 12 的 NT 大小写标志还原大小写
 * （0x08=主名小写、0x10=扩展名小写；有 LFN 的别名项该字节为 0，一律大写） */
static void fat_b_short_disp(const unsigned char*rec,char*out,size_t cap)
{
    char a[9]={0},b[4]={0}; int i; unsigned fl=rec[12];
    for(i=0;i<8&&rec[i]!=' '&&rec[i]!=0;i++)
        a[i]=(char)((fl&0x08)?fat_tolower(rec[i]):rec[i]);
    a[i]=0;
    for(i=0;i<3&&rec[8+i]!=' '&&rec[8+i]!=0;i++)
        b[i]=(char)((fl&0x10)?fat_tolower(rec[8+i]):rec[8+i]);
    b[i]=0;
    if(b[0])snprintf(out,cap,"%s.%s",a,b);
    else    snprintf(out,cap,"%s",a);
}

/* 某条短名项的有效显示名(UTF-8)：有 LFN 用长名，否则用 8.3 */
static int fat_b_rec_disp(FatBDir*bd,unsigned long long G,const unsigned char*rec,
                          char*out,size_t cap)
{
    wchar_t w[FATB_LFN_MAX+1];
    int n=fat_b_lfn_read(bd,G,rec,w,FATB_LFN_MAX+1);
    if(n>0){
        if(fat_w_to_utf8(w,n,out,(int)cap)<0)return 0;
        return 1;
    }
    fat_b_short_disp(rec,out,cap);
    return 1;
}

/* 用户输入的名字是否指向槽 G 的这个文件：先比 8.3 短名（也接受用户直接敲别名），
 * 再看有没有 LFN 并按 Unicode 简单大小写折叠比长名。 */
static int fat_b_name_match(FatBDir*bd,unsigned long long G,const unsigned char*rec,
                            const char*input,const wchar_t*win,int wlen)
{
    char disp[16],raw[16];
    wchar_t w[FATB_LFN_MAX+1];
    int n,i;
    fat_b_short_disp(rec,disp,sizeof disp);
    fat_name83(rec,raw,sizeof raw);
    if(input&&(fat_nameeq(disp,input)||fat_nameeq(raw,input)))return 1;
    n=fat_b_lfn_read(bd,G,rec,w,FATB_LFN_MAX+1);
    if(n<=0||wlen<0||n!=wlen)return 0;
    for(i=0;i<n;i++)if(towupper(w[i])!=towupper(win[i]))return 0;
    return 1;
}

/* 8.3 项里能出现的字符：可见 ASCII，去掉 FAT 明令禁止的 " * + , / : ; < = > ? [ \ ] | */
static int fat_83_ok(unsigned c)
{
    if(c<0x20||c>=0x7F)return 0;
    if(strchr("\"*+,/:;<=>?[\\]|",(int)c))return 0;
    return 1;
}

typedef struct {
    wchar_t       lfn[FATB_LFN_MAX+1]; /* 长名码元；llen==0 表示不写 LFN，只用 8.3 */
    int           llen;
    unsigned char nm[8],ex[3];         /* 8.3 主名/扩展名（大写；不足部分由构造项补空格） */
    int           mlen,xlen;
    unsigned char casefl;              /* 目录项字节 12 的 NT 大小写标志 */
    int           nslots;              /* 占用槽数 = (llen? ceil(llen/13):0) + 1 */
} FatBName;

/* 由宿主路径得出名字结构。返回 0 并写 err 表示名字不可用。 */
static int fat_b_name_from_host(const char*host,FatBName*N,char*err,size_t ecap)
{
    const char*s=host; int i,wlen;
    wchar_t w[FATB_LFN_MAX+4];
    memset(N,0,sizeof *N);
    {const char*p;for(p=host;*p;p++)if(*p=='/'||*p=='\\')s=p+1;}
    if(!*s){if(err)snprintf(err,ecap,"路径里没有文件名");return 0;}
    if(strlen(s)>4*(size_t)FATB_LFN_MAX){if(err)snprintf(err,ecap,"文件名过长");return 0;}
    wlen=fat_utf8_to_w(s,w,FATB_LFN_MAX+4);
    if(wlen<=0){if(err)snprintf(err,ecap,"文件名不是合法的 UTF-8 文本");return 0;}
    if(wlen>FATB_LFN_MAX){
        if(err)snprintf(err,ecap,"文件名 %d 个字符，超过 FAT 长名上限 %d",wlen,FATB_LFN_MAX);
        return 0;
    }
    /* 先看能不能只写 8.3：全 ASCII 合法字符、主名 1..8、扩展名 0..3、每段大小写不混 */
    {
        int ok=1,dot=-1,stemlow=0,stemup=0,extlow=0,extup=0,stem,el;
        for(i=0;i<wlen;i++){
            if(w[i]=='.'){dot=i;continue;}
            if(w[i]>=0x80||!fat_83_ok((unsigned)w[i])){ok=0;break;}
        }
        if(ok&&w[0]=='.')ok=0;
        stem=(dot<0)?wlen:dot; el=(dot<0)?0:wlen-dot-1;
        if(ok&&(stem<1||stem>8||el>3))ok=0;
        if(ok&&dot>=0){for(i=0;i<stem;i++)if(w[i]=='.'){ok=0;break;}}
        if(ok){
            for(i=0;i<stem;i++){
                if(w[i]>='a'&&w[i]<='z')stemlow=1;
                else if(w[i]>='A'&&w[i]<='Z')stemup=1;
            }
            for(i=stem+1;i<wlen;i++){
                if(w[i]>='a'&&w[i]<='z')extlow=1;
                else if(w[i]>='A'&&w[i]<='Z')extup=1;
            }
            if(stemlow&&stemup)ok=0;        /* 大小写混杂的段 8.3 表达不了 → 用 LFN */
            if(extlow&&extup)ok=0;
        }
        if(ok){
            memset(N->nm,0,8);memset(N->ex,0,3);
            for(i=0;i<stem;i++)N->nm[i]=(unsigned char)fat_toupper((unsigned char)w[i]);
            for(i=0;i<el;i++)N->ex[i]=(unsigned char)fat_toupper((unsigned char)w[dot+1+i]);
            N->mlen=stem; N->xlen=el;
            N->casefl=(unsigned char)((stemlow?0x08:0)|(extlow?0x10:0));
            N->llen=0; N->nslots=1;
            return 1;
        }
    }
    /* 需要 LFN：长名原样存，另按长名生成 8.3 别名基（~N 序号留给 fat_b_alias_final 定） */
    memcpy(N->lfn,w,sizeof(wchar_t)*((size_t)wlen+1));
    N->llen=wlen;
    N->nslots=(wlen+FATB_LFN_PER-1)/FATB_LFN_PER+1;
    {
        int dot=-1,stem,el,o=0;
        for(i=0;i<wlen;i++)if(w[i]=='.')dot=i;
        stem=(dot<0)?wlen:dot; el=(dot<0)?0:wlen-dot-1;
        memset(N->nm,0,8);memset(N->ex,0,3);
        for(i=0;i<stem;i++){
            unsigned char u=(unsigned char)w[i];
            if(w[i]>=0x80||!fat_83_ok(u)||u=='.'||u==' ')continue;
            if(o>=8)break;
            N->nm[o++]=(unsigned char)fat_toupper(u);
        }
        if(o==0)N->nm[o++]='_';
        N->mlen=o;
        o=0;
        for(i=0;i<el&&o<3;i++){
            unsigned char u=(unsigned char)w[dot+1+i];
            if(w[dot+1+i]>=0x80||!fat_83_ok(u)||u=='.'||u==' ')continue;
            N->ex[o++]=(unsigned char)fat_toupper(u);
        }
        N->xlen=o;
        N->casefl=0;
    }
    return 1;
}

/* 私有目录里这条 11 字节短名是否已被占用（只看存活项） */
static int fat_b_short_used(FatBDir*bd,const unsigned char nm11[11])
{
    unsigned long long G,tot=bd->nclu*(unsigned long long)bd->ndir;
    for(G=0;G<tot;G++){
        const unsigned char*p=fat_b_slot(bd,G);
        if(!p)return 0;
        /* 空槽(0x00)不是“目录结束”：私有目录按空位分配，空槽会夹在已用槽中间 */
        if(p[0]==0x00)continue;
        if(p[0]==0xE5)continue;
        if(p[11]==FATB_ATTR_LFN||(p[11]&0x08))continue;
        if(memcmp(p,nm11,11)==0)return 1;
    }
    return 0;
}

/* 给带 LFN 的名字定一个目录里还空着的 8.3 别名 `主名~N.扩展名`。
 * 序号 N 从 1 起试；主名按位数截短，保证 8+3 装得下。 */
static int fat_b_alias_final(FatBDir*bd,FatBName*N,char*err,size_t ecap)
{
    int n,i,digits,t,keep,cm;
    unsigned char cand[8],cande[3];
    char suf[16];
    for(n=1;n<=999999;n++){
        for(digits=0,t=n;t>0;t/=10)digits++;
        keep=8-1-digits;
        if(keep<1)break;
        snprintf(suf,sizeof suf,"~%d",n);
        memset(cand,' ',8);memset(cande,' ',3);
        cm=(keep<N->mlen)?keep:N->mlen;
        for(i=0;i<cm;i++)cand[i]=N->nm[i];
        for(i=0;i<=digits;i++)cand[cm+i]=(unsigned char)suf[i];   /* suf = "~N"，连波浪号一起抄 */
        for(i=0;i<3&&i<N->xlen;i++)cande[i]=N->ex[i];
        {
            unsigned char nm11[11];
            memcpy(nm11,cand,8);memcpy(nm11+8,cande,3);
            if(!fat_b_short_used(bd,nm11)){
                memcpy(N->nm,cand,8);memcpy(N->ex,cande,3);
                N->mlen=cm+digits+1;
                N->xlen=N->xlen>3?3:N->xlen;
                N->casefl=0;
                return 1;
            }
        }
    }
    if(err)snprintf(err,ecap,"目录里同名/同别名的条目太多，无法为该长名生成唯一的 8.3 别名");
    return 0;
}

/* ---- 注册表访问（F2FT）---- */

/* 定位注册表第 k 个簇（k=0 即头簇）的真实簇号；失败返回 0。只读每簇 16 字节头。 */
static unsigned long fat_b_reg_cluster(const Fat32*f,unsigned long head,unsigned long long k)
{
    unsigned long cur=head; unsigned long long j; unsigned char hd[16];
    if(head<2||head>f->maxclu)return 0;
    for(j=0;j<k;j++){
        unsigned long nx;
        if(!fat_rd_bytes(f->dev,fat_clu_lba(f,cur)*(unsigned long long)f->bps,hd,16))return 0;
        nx=fat_rd32(hd+12);
        if(nx<2||nx>f->maxclu)return 0;
        cur=nx;
    }
    return cur;
}

/* 读注册表行 S 的值到 *out；成功返回 1 */
static int fat_b_reg_get(const Fat32*f,unsigned long head,size_t clusz,
                         unsigned long S,unsigned long*out)
{
    unsigned long rpc=fat_b_rpc(clusz);
    unsigned long long k; unsigned long r,creal;
    unsigned long long ab; unsigned char b[4];
    if(rpc==0)return 0;
    k=(unsigned long long)S/rpc; r=(unsigned long)(S%rpc);
    creal=fat_b_reg_cluster(f,head,k);
    if(!creal)return 0;
    ab=fat_clu_lba(f,creal)*(unsigned long long)f->bps+FATB_HDR+(unsigned long long)4*r;
    if(!fat_rd_bytes(f->dev,ab,b,4))return 0;
    *out=fat_rd32(b);
    return 1;
}

/* 写注册表行 S = v；成功返回 1 */
static int fat_b_reg_set(const Fat32*f,unsigned long head,size_t clusz,
                         unsigned long S,unsigned long v)
{
    unsigned long rpc=fat_b_rpc(clusz);
    unsigned long long k; unsigned long r,creal; unsigned char b[4];
    unsigned long long ab;
    if(rpc==0)return 0;
    k=(unsigned long long)S/rpc; r=(unsigned long)(S%rpc);
    creal=fat_b_reg_cluster(f,head,k);
    if(!creal)return 0;
    ab=fat_clu_lba(f,creal)*(unsigned long long)f->bps+FATB_HDR+(unsigned long long)4*r;
    fat_wr32(b,v);
    return fat_wr_bytes(f->dev,ab,b,4);
}

/* 保证注册表链里存在第 S 行，且该行当前是空闲的(值 0)。
 * 行号和目录槽号是同一个数 G（见文件头“全局槽号”），所以行是“点名要”的，
 * 不再像老版本那样“找第一个空行”；链不够长就在链尾偷一个真实簇接上。
 * 失败返回 0 并写 err。 */
static int fat_b_reg_ensure(const Fat32*f,unsigned long head,size_t clusz,
                            unsigned long S,char*err,size_t ecap)
{
    unsigned long rpc=fat_b_rpc(clusz);
    unsigned long cur=head; unsigned long long k=0,want;
    FatABuf t={0};
    if(!head||head<2||head>f->maxclu){if(err)snprintf(err,ecap,"注册表头簇非法");return 0;}
    if(rpc==0){if(err)snprintf(err,ecap,"簇太小，注册表放不下任何行");return 0;}
    want=(unsigned long long)S/rpc;
    if(!fat_abuf_ensure(&t,clusz,f->bps)){if(err)snprintf(err,ecap,"内存不足");return 0;}
    while(k<want){
        unsigned long nx;
        if(!fat_b_cluster_read(f,cur,t.buf)){
            fat_abuf_free(&t);if(err)snprintf(err,ecap,"读注册表簇 %lu 失败",cur);return 0;}
        nx=fat_rd32((unsigned char*)t.buf+12);
        if(nx<2||nx>f->maxclu){
            /* 已到链尾：偷一个新注册表簇串上去 */
            unsigned long newc=fat_b_steal(f);
            if(!newc){
                fat_abuf_free(&t);
                if(err)snprintf(err,ecap,"注册表需要第 %llu 个簇，链已到尾且卷上无空闲真实簇可扩容",want+1);
                return 0;}
            memset(t.buf,0,clusz);
            memcpy(t.buf,FATB_MAGIC_REG,4);
            fat_wr32((unsigned char*)t.buf+4,FATB_VERSION);
            if(!fat_b_cluster_write(f,newc,t.buf)){
                fat_b_release(f,newc);fat_abuf_free(&t);
                if(err)snprintf(err,ecap,"写新注册表簇失败(错误码 %lu)",g_wr_err);
                return 0;}
            if(!fat_b_cluster_read(f,cur,t.buf)){
                fat_b_release(f,newc);fat_abuf_free(&t);
                if(err)snprintf(err,ecap,"读注册表尾簇 %lu 失败",cur);
                return 0;}
            fat_wr32((unsigned char*)t.buf+12,newc);
            if(!fat_b_cluster_write(f,cur,t.buf)){
                fat_b_release(f,newc);fat_abuf_free(&t);
                if(err)snprintf(err,ecap,"串接新注册表簇失败(错误码 %lu)",g_wr_err);
                return 0;}
            cur=newc; k++;
            continue;
        }
        cur=nx; k++;
    }
    if(!fat_b_cluster_read(f,cur,t.buf)){
        fat_abuf_free(&t);if(err)snprintf(err,ecap,"读注册表簇 %lu 失败",cur);return 0;}
    if(fat_rd32((unsigned char*)t.buf+FATB_HDR+(size_t)4*(S%rpc))!=0){
        fat_abuf_free(&t);
        if(err)snprintf(err,ecap,"注册表第 %lu 行已被占用（目录槽与注册表行不一致）",S);
        return 0;}
    fat_abuf_free(&t);
    return 1;
}

/* 释放某文件的整条私有链（结构法）：顺链簇 NEXT 走到 0，逐项释放数据簇，
 * 并释放链簇自身。返回释放的链簇数；链头非法返回 -1。
 * 每个链簇里的数据簇号 + 链簇自身攒成一批交给 fat_b_release_n（记账按 FAT 扇区合并）。 */
static int fat_b_free_chain(const Fat32*f,size_t clusz,unsigned long head)
{
    unsigned long epc=fat_b_epc(clusz);
    unsigned long cur=head; int guard=0,freed=0;
    FatABuf c={0};
    unsigned long *batch=NULL; unsigned long nbatch;
    if(epc==0)return -1;
    if(head<2||head>f->maxclu)return -1;
    if(!fat_abuf_ensure(&c,clusz,f->bps))return -1;
    batch=(unsigned long*)malloc(((size_t)epc+1)*sizeof(unsigned long));
    if(!batch){fat_abuf_free(&c);return -1;}
    while(cur>=2&&cur<=f->maxclu){
        unsigned long e,nx;
        if(guard++>1000000){fat_abuf_free(&c);free(batch);return -1;}
        if(!fat_b_cluster_read(f,cur,c.buf)){fat_abuf_free(&c);free(batch);return -1;}
        nbatch=0;
        for(e=0;e<epc;e++){
            unsigned long real=fat_rd32((unsigned char*)c.buf+(size_t)4*e);
            if(real>=2&&real<=f->maxclu)batch[nbatch++]=real;
        }
        nx=fat_rd32((unsigned char*)c.buf+clusz-4);
        batch[nbatch++]=cur;
        fat_b_release_n(f,batch,nbatch);
        freed++;
        if(nx<2||nx>f->maxclu)break;
        cur=nx;
    }
    fat_abuf_free(&c);free(batch);
    return freed;
}

/* 统计真实 FAT 的空闲簇数（数据区 2..maxclu，FAT0 逐扇区解，避免逐簇整扇读） */
static unsigned long fat_b_free_count(const Fat32*f)
{
    FatABuf a={0}; unsigned long long s; unsigned long free=0; unsigned per, i;
    if(!fat_abuf_ensure(&a,f->bps,f->bps))return 0;
    per=f->bps/4;
    for(s=0;s<f->fatsz;s++){
        const unsigned char*b;
        if(!fat_rd_sec(f->dev,f->fat0_lba+s,1,a.buf))break;
        b=(const unsigned char*)a.buf;
        for(i=0;i<per;i++){
            unsigned long long clu=(unsigned long long)s*per+i;
            if(clu<2||clu>(unsigned long long)f->maxclu)continue;
            if(fat_rd32(b+4*(size_t)i)==0)free++;
        }
    }
    fat_abuf_free(&a);
    return free;
}

/* 列出私有文件（需先有私有FS）。返回记录条数；无私有FS返回 -1。
 * 目录簇可能串成多簇，槽号 G 全局连续，所以这里沿整条链扫。 */
static int fat_b_list(const Fat32*f,FatBEnt*out,int max)
{
    size_t clusz; int ndir,n=0; char err[128];
    unsigned long dclu=0,regclu=0; unsigned long long G,tot;
    FatBDir bd;
    if(!fat_b_open_meta(f,&dclu,&regclu,0,&clusz,&ndir,err,sizeof err))return -1;
    if(!fat_b_dir_open(&bd,f,dclu,clusz,ndir))return -1;
    tot=bd.nclu*(unsigned long long)ndir;
    for(G=0;G<tot;G++){
        const unsigned char*rec=fat_b_slot(&bd,G);
        unsigned char r0[32];
        unsigned long S,size,nb=0,head=0,firstreal=0;
        char shown[128],al[16];
        if(!rec)break;
        /* 空槽(0x00)不是“目录结束”：私有目录按空位分配，空槽会夹在已用槽中间，
         * 必须把整条目录链扫完，否则会漏掉后面簇里的文件。 */
        if(rec[0]==0x00)continue;
        if(rec[0]==0xE5)continue;
        if(rec[11]==FATB_ATTR_LFN||(rec[11]&0x08))continue;
        memcpy(r0,rec,32);          /* 下面取长名可能要装载别的簇，先留副本 */
        if(!fat_b_rec_disp(&bd,G,r0,shown,sizeof shown))continue;
        al[0]=0;    /* 有 LFN 时顺带给出自动生成的 8.3 别名（用户也可以按别名导出/删除） */
        if(fat_b_lfn_span(&bd,G,r0)>0)fat_b_short_disp(r0,al,sizeof al);
        S=fat_ent_clu(r0);
        size=fat_ent_size(r0);
        nb=(unsigned long)(((unsigned long long)size+clusz-1)/clusz);
        if(fat_b_reg_get(f,regclu,clusz,S,&head)&&head>=2&&head<=f->maxclu){
            FatABuf c={0};
            if(fat_abuf_ensure(&c,clusz,f->bps)&&fat_b_cluster_read(f,head,c.buf))
                firstreal=fat_rd32((unsigned char*)c.buf);
            fat_abuf_free(&c);
        }
        if(n<max){
            snprintf(out[n].name,sizeof out[n].name,"%s",shown);
            snprintf(out[n].alias,sizeof out[n].alias,"%s",al);
            out[n].first=S;
            out[n].size=size;
            out[n].chunks=nb;
            out[n].firstreal=firstreal;
        }
        n++;
    }
    fat_b_dir_close(&bd);
    return n;
}

/* 阶梯探针：这台设备【一次最多能吃下几扇区】的裸写？
 * 8 → 4 → 2 → 1 逐级下降，取第一个“写下去、且逐扇区回读全部一致”的档位，返回该扇区数。
 * 判据必须是回读比对，不能信 WriteFile 的返回值——本机实测过“报成功、done 也对、介质没落”。
 * 回读刻意走单扇区（fat_dev_rd1），免得把多扇区读的问题混进来。
 * 一次下发 k 扇区若只落了前几扇区，逐扇区回读就能发现（只验首扇区会漏掉这种半落法）。 */
static unsigned fat_probe_wr_max(FatDev*d,unsigned long long lba,unsigned spc,
                                 unsigned bps,const void*buf)
{
    unsigned k;
    FatABuf v={0};
    if(!d||!buf||!spc||!bps)return 0;
    if(!fat_abuf_ensure(&v,d->sector,d->sector))return 0;
    for(k=spc;k>=1;k>>=1){
        unsigned i; int ok=1;
        if(fat_dev_wr1(d,lba,k,buf)){
            fat_dev_flush(d);
            for(i=0;i<k;i++){
                if(!fat_dev_rd1(d,lba+i,1,v.buf)
                   ||memcmp(v.buf,(const unsigned char*)buf+(size_t)i*bps,bps)!=0){ok=0;break;}
            }
        }else ok=0;
        if(ok){fat_abuf_free(&v);return k;}
    }
    fat_abuf_free(&v);
    return 0;
}

/* 初始化：偷 2 个空闲簇建注册表头簇与自定义目录簇（都标坏），格式化两簇，
 * 目录簇号按 4 槽机制保存（槽1必须成功）。 */
static int fat_b_init(const Fat32*f,unsigned long*outdir,char*err,size_t ecap)
{
    size_t clusz=(size_t)f->spc*f->bps;
    FatABuf z={0}; unsigned long realR=0,realD=0; int mask;
    if(fat_b_probe(f,0,0,0)){
        snprintf(err,ecap,"私有文件系统已存在（4 槽已指向一个目录簇）。要重建请先“清除”。");
        return 0;
    }
    if(clusz<=FATB_HDR||fat_b_rpc(clusz)==0||fat_b_epc(clusz)==0){
        snprintf(err,ecap,"簇太小(%lu 字节)，不适合做私有文件系统",(unsigned long)clusz);return 0;}
    if(!fat_abuf_ensure(&z,clusz,f->bps)){snprintf(err,ecap,"内存不足");return 0;}
    realR=fat_b_steal(f);                       /* 注册表头簇 */
    if(!realR){fat_abuf_free(&z);
        snprintf(err,ecap,"偷簇失败：扫完 FAT 没有空闲簇，或写 FAT 被系统拒绝"
                 "(物理盘卷被挂载/占用时 Windows 禁止裸写，需先解锁/卸卷)");return 0;}
    realD=fat_b_steal(f);                       /* 自定义目录簇 */
    if(!realD){fat_b_release(f,realR);fat_abuf_free(&z);
        snprintf(err,ecap,"只偷到注册表簇，第 2 个(目录簇)失败——已把第 1 个回滚。");return 0;}
    /* —— 能力探针：一次把「这台设备一次能吃下几扇区写 / 多扇区读可不可信」都测出来 ——
     * 结论存进 g_multisec_wr / g_multisec_rd，之后全程照结论走，不再每簇去试。
     * 这是性能的关键：写能吃 8 扇区时每簇 1 次设备写；只吃 1 扇区时每簇要 8 次。
     * 写法判定 = 阶梯探针 fat_probe_wr_max（8→4→2→1，逐扇区回读校验）。
     * 读法判定 = 「整簇一次读」与「逐扇区读」两份缓冲比对——与写无关：
     *            不管刚才那笔写有没有落，两种读法读到的应该是同一份内容。
     * 探测内容随后被元数据覆盖，无副作用。 */
    {
        unsigned long long lbaR=(unsigned long long)fat_clu_lba(f,realR);
        unsigned wmax; int rd_cmp=-1;
        g_multisec_wr=-1;g_multisec_rd=-1;        /* 每台设备重测 */
        g_wr_fell_back=0;
        memset(z.buf,0xA5,clusz);
        if(f->dev->is_image){
            wmax=(unsigned)f->spc;g_multisec_wr=(int)wmax;g_multisec_rd=1;
        }else{
            wmax=fat_probe_wr_max(f->dev,lbaR,(unsigned)f->spc,(unsigned)f->bps,z.buf);
            g_multisec_wr=(int)wmax;
            /* 读法判定：两种读法各读一遍整簇，比对内容 */
            FatABuf m={0},s={0};
            if(fat_abuf_ensure(&m,clusz,f->bps)&&fat_abuf_ensure(&s,clusz,f->bps)){
                unsigned i; int ok_m,ok_s=1;
                ok_m=fat_dev_rd1(f->dev,lbaR,(unsigned)f->spc,m.buf);
                for(i=0;i<f->spc;i++)
                    if(!fat_dev_rd1(f->dev,lbaR+i,1,(unsigned char*)s.buf+(size_t)i*f->bps)){ok_s=0;break;}
                if(ok_m&&ok_s)rd_cmp=memcmp(m.buf,s.buf,clusz)==0?1:0;
                fat_abuf_free(&m);fat_abuf_free(&s);
            }
            if(rd_cmp>=0)g_multisec_rd=rd_cmp;
            else g_multisec_rd=0;                 /* 读不出来就保守走逐扇区 */
        }
        {char wdesc[96];
         if(f->dev->is_image) snprintf(wdesc,sizeof wdesc,"镜像不适用");
         else if(wmax>=(unsigned)f->spc) snprintf(wdesc,sizeof wdesc,"一次性整簇下发，逐扇区回读全对");
         else if(wmax) snprintf(wdesc,sizeof wdesc,"整簇一次下发【不落】，实测最大可用 %u 扇区/次(每簇 %lu 次设备写)",
                                wmax,(unsigned long)((f->spc+wmax-1)/wmax));
         else snprintf(wdesc,sizeof wdesc,"多扇区一律不落，只能逐扇区(每簇 %lu 次设备写)",(unsigned long)f->spc);
         printf("  [探测] 打开方式=%s 整簇 %lu 字节/%lu 扇区：裸写 %s | 整簇读 %s\n",
                f->dev->is_image?"镜像":(f->dev->nobuf?"无缓存直写":"带缓存"),
                (unsigned long)clusz,(unsigned long)f->spc,wdesc,
                f->dev->is_image?"不适用":
                (g_multisec_rd==1?"与逐扇区读结果一致，可用":
                (rd_cmp==0?"与逐扇区读结果【不一致】——多扇区读不可信，已禁用":"读失败，已禁用")));}
        if(!f->dev->is_image&&wmax<(unsigned)f->spc)
            printf("  [探测] 判词：这台设备吃不下 %s裸写（WriteFile 报成功但介质不落），"
                   "实测最佳档位是 %s。本次已自动按该档位分块下发：功能完全正确，"
                   "只是每簇要多下发几次设备写，速度会打相应折扣。\n",
                   wmax?"整簇一次":"多扇区",
                   wmax?(wmax>=4?"每簇 4 扇区，折损有限":"每簇一次 "):"");
    }
    memset(z.buf,0,clusz);
    memcpy(z.buf,FATB_MAGIC_REG,4);
    fat_wr32((unsigned char*)z.buf+4,FATB_VERSION);
    {int fb0=g_wr_fell_back;
    if(!fat_b_cluster_write(f,realR,z.buf)){    /* 头 +12 NEXT 保持 0（单簇） */
        fat_b_release(f,realR);fat_b_release(f,realD);fat_abuf_free(&z);
        snprintf(err,ecap,"写注册表簇 %lu 失败(错误码 %lu，该簇共下发 %d 次设备写)，已回滚。"
                 "错误码 0 = 不是 Windows 报错，是某次写没落盘(回读校验没过)。",
                 realR,g_wr_err,g_wr_fell_back-fb0);return 0;}
    }
    memset(z.buf,0,clusz);
    memcpy(z.buf,FATB_MAGIC_DIR,4);
    fat_wr32((unsigned char*)z.buf+4,FATB_VERSION);
    fat_wr32((unsigned char*)z.buf+8,realR);    /* 目录簇头 +8 记下注册表头簇号 */
    if(!fat_b_cluster_write(f,realD,z.buf)){
        fat_b_release(f,realR);fat_b_release(f,realD);fat_abuf_free(&z);
        snprintf(err,ecap,"写自定义目录簇失败(错误码 %lu)，已回滚",g_wr_err);return 0;}
    fat_abuf_free(&z);
    /* 自检：当场回读两个元数据簇的簇头魔数，确认真的落到了设备上。
     * 真机曾出现“写调用返回成功、但内容随后被系统缓存/卷驱动覆盖”——这里立刻就能发现，
     * 免得后面每个操作都报“没有私有文件系统”却查不出原因。 */
    fat_dev_flush(f->dev);
    {
        /* 取证式自检：不仅要判成败，还要把“失败发生在哪一层”钉死。
         * 缓冲先填 0xCC 而不是留未初始化——否则读失败时打印的是栈垃圾，
         * 会被误读成“盘上就是这些字节”（真机踩过一次：满屏 FF 其实是没读成）。 */
        unsigned char cd[16],cr[16],cb[16],rd[16],rr[16];
        int okd,okr,okb,k; unsigned long rderr;
        int raw_a=0,raw_b=0,verdict_ok;
        unsigned long long offD=fat_clu_lba(f,realD)*(unsigned long long)f->bps;
        unsigned long long offR=fat_clu_lba(f,realR)*(unsigned long long)f->bps;
        int wfail=g_wr_failed; unsigned long werr=g_wr_err;   /* 最后一次簇写的成败/错误码 */
        memset(cd,0xCC,sizeof cd);memset(cr,0xCC,sizeof cr);memset(cb,0xCC,sizeof cb);
        memset(rd,0xCC,sizeof rd);memset(rr,0xCC,sizeof rr);
        okd=fat_rd_bytes(f->dev,offD,cd,16); rderr=g_rd_err;
        okr=fat_rd_bytes(f->dev,offR,cr,16);
        okb=fat_rd_bytes(f->dev,f->part_lba*(unsigned long long)f->bps,cb,16);
        /* 判据就是常规回读：裸盘句柄的 I/O 绕过文件系统缓存，读到的即介质真实内容
         * （已用 flags=0 与 NO_BUFFERING 两种打开方式对照，回读结果一致，排除缓存层次）。
         * 无缓存句柄直读只作【旁证】：打得开就多报一行互相印证，打不开也不影响判据成立
         * ——真机这块盘的驱动就不支持无缓存打开，不能因此就说“验不了”。 */
        verdict_ok = okd&&memcmp(cd,FATB_MAGIC_DIR,4)==0&&okr&&memcmp(cr,FATB_MAGIC_REG,4)==0;
        if(!f->dev->is_image){
            raw_a=fat_dev_raw_read(f->dev,offD,rd,16);
            raw_b=fat_dev_raw_read(f->dev,offR,rr,16);
            if(raw_a&&raw_b){
                int same=memcmp(cd,rd,16)==0&&memcmp(cr,rr,16)==0;
                printf("  [旁证] 无缓存句柄直读设备：目录簇 %02X %02X %02X %02X | 注册表簇 %02X %02X %02X %02X —— 与常规回读%s\n",
                       rd[0],rd[1],rd[2],rd[3],rr[0],rr[1],rr[2],rr[3],same?"一致":"不一致(需警惕)");
            }else{
                printf("  [旁证] 该驱动不支持无缓存打开，跳过旁证（不影响上面的判据）。\n");
            }
        }
        if(!verdict_ok){
            printf("  [自检] 打开方式 nobuf=%d(1=无缓存) 设备扇区=%lu 设备总字节=%llu\n",
                   f->dev->nobuf,(unsigned long)f->dev->sector,f->dev->total);
            printf("  [自检] 写这两簇时 wfail=%d werr=%lu (0/0 = 写调用本身报成功)\n",wfail,werr);
            printf("  [自检] 目录簇 %lu @LBA %llu 回读 ok=%d rderr=%lu : ",
                   realD,fat_clu_lba(f,realD),okd,rderr);
            for(k=0;k<16;k++)printf("%02X ",cd[k]);
            printf("\n");
            printf("  [自检] 注册表簇 %lu @LBA %llu 回读 ok=%d rderr=%lu : ",
                   realR,fat_clu_lba(f,realR),okr,g_rd_err);
            for(k=0;k<16;k++)printf("%02X ",cr[k]);
            printf("\n");
            printf("  [自检] 对照读 引导扇区 @LBA %lu 回读 ok=%d : ",(unsigned long)f->part_lba,okb);
            for(k=0;k<16;k++)printf("%02X ",cb[k]);
            printf("  (正常应含 4D 53 44 4F 53 35 2E 30 = \"MSDOS5.0\")\n");
            /* 重写同一处魔数并立刻回读：区分“写从未落盘”与“读拿到旧视图/顺序问题” */
            {unsigned char m[4];int w2,r2;
             memcpy(m,FATB_MAGIC_REG,4);memset(cr,0xCC,sizeof cr);
             w2=fat_wr_bytes(f->dev,offR,m,4);
             r2=w2?fat_rd_bytes(f->dev,offR,cr,4):0;
             printf("  [自检] 重写魔数到注册表簇头 w=%d(werr=%lu) 再回读 r=%d : %02X %02X %02X %02X",
                    w2,g_wr_err,r2,cr[0],cr[1],cr[2],cr[3]);
             if(r2&&memcmp(cr,FATB_MAGIC_REG,4)==0)
                 printf("  <- 单扇区写能落、整簇写不落：坐实“多扇区裸写被这台设备吃掉”\n");
             else printf("  <- 连单扇区写也落不下：该区域被卷/驱动拦截，与扇区数无关\n");}
            /* 判词：把“问题出在哪一层”直接说出来，省得回头猜。 */
            if(f->dev->is_image)
                printf("  [自检] 判词：镜像文件回读不对 —— 写入路径或偏移算错了，与设备无关。\n");
            else
                printf("  [自检] 判词：单扇区写也没在介质上生效。此时不应再怀疑“多扇区被吃掉”，"
                       "而要看该区域是否被卷/驱动拦截（卸卷是否真的成功）。\n");
            fat_b_release(f,realR);fat_b_release(f,realD);
            for(int i=0;i<4;i++)fat_slot_write(f,i,0);
            snprintf(err,ecap,"写入自检失败：元数据簇没落盘——已回滚并清空 4 槽。请把上面"
                     "带“取证”“判词”“ok=/rderr=”的几行贴回来，即可定位是读失败、写被丢弃还是被别处覆盖。");
            return 0;
        }
    }
    mask=fat_stash_write_all(f,realD);
    if(!(mask&1)){
        fat_b_release(f,realR);fat_b_release(f,realD);
        snprintf(err,ecap,"保存自定义目录簇号到槽1(保留扇区末尾)失败(其余槽:%s)——已回滚。"
                 "物理盘卷被挂载/占用时 Windows 禁止裸写该扇区，请先解锁/卸卷。",mask?"部分成功":"无");
        return 0;
    }
    if(outdir)*outdir=realD;
    return 1;
}

/* 导入宿主文件到私有文件系统：偷 nb 个数据簇存字节 + 若干链簇串成私有链 +
 * 注册表登记 [S]=链头 + 目录记录(名字/序号S/长度)。 */
static int fat_b_import(const Fat32*f,const char*host,char*err,size_t ecap)
{
    unsigned char*file=NULL; unsigned long flen=0,ferr=0;
    unsigned long dclu=0,regclu=0; size_t clusz; int ndir;
    FatBDir bd; FatBName N;
    FatABuf wb={0}; unsigned long epc;
    unsigned long nb=0,ncc=0,j; unsigned long long nbll;
    unsigned long*reals=NULL; unsigned long*chainc=NULL;
    unsigned long S=0; unsigned long long G=0;
    int row_written=0,failed=0,dir_open=0;
    char ebuf[300],inname[1024];
    wchar_t win[FATB_LFN_MAX+2]; int wlen=0;
    ebuf[0]=0;

    file=fat_read_file(host,&flen,&ferr);
    if(!file){snprintf(err,ecap,"读取宿主文件失败 err %lu",ferr);return 0;}
    if(flen==0){snprintf(err,ecap,"空文件不能导入（私有文件系统按整簇存储文件字节）");free(file);return 0;}
    if(!fat_b_name_from_host(host,&N,err,ecap)){free(file);return 0;}
    if(!fat_b_open_meta(f,&dclu,&regclu,0,&clusz,&ndir,err,ecap)){free(file);return 0;}
    epc=fat_b_epc(clusz);
    if(epc==0||fat_b_rpc(clusz)==0||ndir<=0){
        snprintf(err,ecap,"簇太小，放不下私有链");free(file);return 0;}
    if(!fat_b_dir_open(&bd,f,dclu,clusz,ndir)){snprintf(err,ecap,"内存不足");free(file);return 0;}
    dir_open=1;

    /* 该文件在私有目录里将使用的“有效名字”（有 LFN 即长名，否则是 8.3 的显示形式） */
    {
        int i,o=0;
        if(N.llen>0){
            memcpy(win,N.lfn,sizeof(wchar_t)*((size_t)N.llen+1));
            wlen=N.llen;
        }else{
            for(i=0;i<N.mlen;i++)
                win[o++]=(wchar_t)((N.casefl&0x08)?fat_tolower(N.nm[i]):N.nm[i]);
            if(N.xlen){
                win[o++]='.';
                for(i=0;i<N.xlen;i++)
                    win[o++]=(wchar_t)((N.casefl&0x10)?fat_tolower(N.ex[i]):N.ex[i]);
            }
            win[o]=0; wlen=o;
        }
        if(fat_w_to_utf8(win,wlen,inname,sizeof inname)<0){
            snprintf(err,ecap,"名字转 UTF-8 失败");free(file);fat_b_dir_close(&bd);return 0;}
    }

    /* 重名检查（长名/短名都算）+ 长名要定唯一 8.3 别名 */
    {
        unsigned long long GG,tot=bd.nclu*(unsigned long long)ndir;
        for(GG=0;GG<tot;GG++){
            const unsigned char*p=fat_b_slot(&bd,GG);
            unsigned char r0[32];
            if(!p)break;
            if(p[0]==0x00)continue;      /* 空槽≠目录结束，见 fat_b_list 处说明 */
            if(p[0]==0xE5)continue;
            if(p[11]==FATB_ATTR_LFN||(p[11]&0x08))continue;
            memcpy(r0,p,32);
            if(fat_b_name_match(&bd,GG,r0,inname,win,wlen)){
                snprintf(err,ecap,"私有文件系统里已有同名 %s，请改名后再导入",inname);
                free(file);fat_b_dir_close(&bd);return 0;
            }
        }
        if(N.llen>0&&!fat_b_alias_final(&bd,&N,err,ecap)){
            free(file);fat_b_dir_close(&bd);return 0;
        }
    }

    /* 块数 nb 与链簇数 ncc */
    nbll=((unsigned long long)flen+clusz-1)/clusz;
    if(nbll==0)nbll=1;
    if(nbll>(unsigned long long)0xFFFFFFFFUL){
        snprintf(err,ecap,"文件过大（数据块数超出 32 位）");free(file);fat_b_dir_close(&bd);return 0;}
    nb=(unsigned long)nbll;
    ncc=(unsigned long)(((unsigned long long)nb+epc-1)/epc);

    /* 找 nslots 个连续空闲槽（目录不够长就自动扩容），G = 短名项所在槽 */
    if(!fat_b_slot_alloc_run(&bd,N.nslots,&G,err,ecap)){
        free(file);fat_b_dir_close(&bd);return 0;}

    /* 注册表必须存在第 G 行（必要时自动扩注册表链） */
    if(!fat_b_reg_ensure(f,regclu,clusz,(unsigned long)G,err,ecap)){
        free(file);fat_b_dir_close(&bd);return 0;}
    S=(unsigned long)G;

    if(!fat_abuf_ensure(&wb,clusz,f->bps)){snprintf(err,ecap,"内存不足");failed=1;goto cleanup;}
    reals=(unsigned long*)calloc((size_t)nb,sizeof(unsigned long));
    chainc=(unsigned long*)calloc((size_t)ncc,sizeof(unsigned long));
    if(!reals||!chainc){snprintf(ebuf,sizeof ebuf,"内存不足");failed=1;goto cleanup;}

    /* 先批量偷齐 nb 个数据簇（一次扫出、每 FAT 扇区只读改写一次），再逐块写数据。
     * reals[] 是 calloc 出来的，没偷到的项恒为 0，cleanup 里按 0 跳过，回滚语义不变。 */
    if(nb>4)
        printf("    导入 %lu 字节，需偷 %lu 个数据簇 + %lu 个链簇（批量标坏 + 实时进度）…\n",
               (unsigned long)flen,(unsigned long)nb,(unsigned long)ncc),fflush(stdout);
    {unsigned long got=fat_b_steal_n(f,reals,nb);
     if(got<nb){
        snprintf(ebuf,sizeof ebuf,"空闲真实簇不足：偷到第 %lu/%lu 个数据块时失败(已回滚已偷的)。"
                 "卷的数据区可能已被占满。",got,(unsigned long)nb);
        failed=1;goto cleanup;
     }}
    {unsigned long step=nb>400?(unsigned long)(nb/20+1):1;
     for(j=0;j<nb;j++){
        unsigned long rc=reals[j];
        size_t chunk;
        if(j==0||j%step==0)
            printf("      已偷并写入 %lu/%lu 数据簇…\n",(unsigned long)(j+1),(unsigned long)nb),
            fflush(stdout);
        chunk=(size_t)flen-(size_t)j*clusz; if(chunk>clusz)chunk=clusz;
        memset(wb.buf,0,clusz);
        memcpy(wb.buf,file+(size_t)j*clusz,chunk);
        if(!fat_b_cluster_write(f,rc,wb.buf)){
            snprintf(ebuf,sizeof ebuf,"写数据簇 %lu 失败(错误码 %lu)——已回滚。",rc,g_wr_err);
            failed=1;goto cleanup;
        }
    }}

    /* 偷链簇（先备齐簇号，才能填 NEXT）——同样批量 */
    if(ncc){
        unsigned long gotc=fat_b_steal_n(f,chainc,ncc);
        if(gotc<ncc){
            snprintf(ebuf,sizeof ebuf,"空闲真实簇不足：偷链簇 %lu/%lu 失败(已回滚)。",
                     gotc,(unsigned long)ncc);
            failed=1;goto cleanup;
        }
    }
    /* 填并写链簇：条目=数据簇真实簇号，末 4B=下一链簇号(0=尾) */
    for(j=0;j<ncc;j++){
        unsigned long e; unsigned long base=j*epc;
        memset(wb.buf,0,clusz);
        for(e=0;e<epc;e++){
            unsigned long idx=base+e;
            if(idx<nb)fat_wr32((unsigned char*)wb.buf+(size_t)4*e,reals[idx]);
        }
        fat_wr32((unsigned char*)wb.buf+clusz-4,(j+1<ncc)?chainc[j+1]:0);
        if(!fat_b_cluster_write(f,chainc[j],wb.buf)){
            snprintf(ebuf,sizeof ebuf,"写私有链簇 %lu 失败(错误码 %lu)——已回滚。",chainc[j],g_wr_err);
            failed=1;goto cleanup;
        }
    }

    /* 注册表行 [G] = 链头簇 */
    if(!fat_b_reg_set(f,regclu,clusz,S,chainc[0])){
        snprintf(ebuf,sizeof ebuf,"写注册表行失败");failed=1;goto cleanup;
    }
    row_written=1;

    /* 目录项：LFN 链（倒序，最高序带 0x40）+ 短名项，最后整体落盘。
     * 短名项先拼好以算 8.3 校验和，保证 LFN 项的校验和与真正落盘的 11 字节一致。 */
    {
        unsigned char se[32];
        fat_build_entry(se,N.nm,N.mlen,N.ex,N.xlen,0x20,S,flen);
        se[12]=N.casefl;
        if(N.llen>0){
            unsigned char ck=fat_lfn_ck(se);
            int ent;
            for(ent=N.nslots-1;ent>=1;ent--){
                unsigned char*p=fat_b_slot_w(&bd,G-(unsigned long long)ent);
                if(!p){snprintf(ebuf,sizeof ebuf,"取目录槽失败");failed=1;goto cleanup;}
                fat_lfn_entry(p,N.lfn,N.llen,ent,(ent==N.nslots-1),ck);
            }
        }
        {
            unsigned char*p=fat_b_slot_w(&bd,G);
            if(!p){snprintf(ebuf,sizeof ebuf,"取目录槽失败");failed=1;goto cleanup;}
            memcpy(p,se,32);
        }
        if(!fat_b_dir_flush(&bd)){
            snprintf(ebuf,sizeof ebuf,"写自定义目录簇失败(错误码 %lu)。",g_wr_err);
            failed=1;goto cleanup;
        }
    }

cleanup:
    if(dir_open)fat_b_dir_close(&bd);
    if(failed){
        if(row_written)fat_b_reg_set(f,regclu,clusz,S,0);
        if(chainc)for(j=0;j<ncc;j++)if(chainc[j])fat_b_release(f,chainc[j]);
        if(reals) for(j=0;j<nb; j++)if(reals[j]) fat_b_release(f,reals[j]);
        snprintf(err,ecap,"%s",ebuf[0]?ebuf:"导入失败");
    }
    free(file);free(reals);free(chainc);
    fat_abuf_free(&wb);
    return failed?0:1;
}

/* 导出私有文件到宿主路径：按长度算 nb，读私有链簇拿数据簇号逐块读出。 */
static int fat_b_export(const Fat32*f,const char*name,const char*host,char*err,size_t ecap)
{
    FatABuf d={0},cb={0},rb={0}; size_t clusz; int ndir,found=-1;
    unsigned long dclu=0,regclu=0,S,size=0,nb,epc,head,cur; unsigned char*out=NULL;
    unsigned long left,off=0; unsigned long werr=0; unsigned long j;
    unsigned long long G,tot;
    wchar_t win[FATB_LFN_MAX+2]; int wlen;
    if(!fat_b_open_meta(f,&dclu,&regclu,&d,&clusz,&ndir,err,ecap))return 0;
    wlen=fat_utf8_to_w(name,win,FATB_LFN_MAX+2);   /* 输入非法就退化成 -1，只按短名比 */
    {
        FatBDir bd;
        if(!fat_b_dir_open(&bd,f,dclu,clusz,ndir)){
            snprintf(err,ecap,"内存不足");fat_abuf_free(&d);return 0;}
        tot=bd.nclu*(unsigned long long)ndir;
        for(G=0;G<tot;G++){
            const unsigned char*p=fat_b_slot(&bd,G);
            unsigned char r0[32];
            if(!p)break;
            if(p[0]==0x00)continue;      /* 空槽≠目录结束，见 fat_b_list 处说明 */
            if(p[0]==0xE5)continue;
            if(p[11]==FATB_ATTR_LFN||(p[11]&0x08))continue;
            memcpy(r0,p,32);
            if(fat_b_name_match(&bd,G,r0,name,win,wlen)){
                found=1;S=fat_ent_clu(r0);size=fat_ent_size(r0);break;}
        }
        fat_b_dir_close(&bd);
    }
    if(found<0){snprintf(err,ecap,"私有文件系统里没有 %s",name);
        fat_abuf_free(&d);return 0;}
    nb=(unsigned long)(((unsigned long long)size+clusz-1)/clusz);
    if(size==0){
        if(!fat_write_file(host,(const unsigned char*)"",0,&werr)){
            snprintf(err,ecap,"写文件失败 err %lu",werr);fat_abuf_free(&d);return 0;}
        fat_abuf_free(&d);return 1;
    }
    if(!fat_b_reg_get(f,regclu,clusz,S,&head)||head<2||head>f->maxclu){
        snprintf(err,ecap,"注册表行 %lu 损坏：私有链头簇非法",S);fat_abuf_free(&d);return 0;}
    epc=fat_b_epc(clusz);
    if(epc==0){snprintf(err,ecap,"簇太小");fat_abuf_free(&d);return 0;}
    if(!fat_abuf_ensure(&cb,clusz,f->bps)||!fat_abuf_ensure(&rb,clusz,f->bps)){
        snprintf(err,ecap,"内存不足");fat_abuf_free(&d);return 0;}
    out=(unsigned char*)malloc(size);
    if(!out){snprintf(err,ecap,"内存不足");fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);return 0;}
    left=size; cur=head;
    for(j=0;j<nb;j++){
        unsigned long e=j%epc; unsigned long real; size_t chunk;
        if(e==0){
            if(j>0){
                cur=fat_rd32((unsigned char*)cb.buf+clusz-4);
                if(cur<2||cur>f->maxclu){
                    snprintf(err,ecap,"私有链损坏：链簇 NEXT 非法(%lu)",cur);
                    free(out);fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);return 0;}
            }
            if(!fat_b_cluster_read(f,cur,cb.buf)){
                snprintf(err,ecap,"读私有链簇 %lu 失败",cur);
                free(out);fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);return 0;}
        }
        real=fat_rd32((unsigned char*)cb.buf+(size_t)4*e);
        if(real<2||real>f->maxclu){
            snprintf(err,ecap,"私有链损坏：块 %lu 对应真实簇 %lu 非法",j,real);
            free(out);fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);return 0;}
        chunk=left<clusz?left:clusz;
        if(!fat_b_cluster_read(f,real,rb.buf)){
            snprintf(err,ecap,"读数据簇 %lu 失败",real);
            free(out);fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);return 0;}
        memcpy(out+off,rb.buf,chunk);
        off+=chunk; left-=chunk;
    }
    if(!fat_write_file(host,out,size,&werr)){
        snprintf(err,ecap,"写宿主文件失败 err %lu",werr);
        free(out);fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);return 0;}
    free(out);fat_abuf_free(&d);fat_abuf_free(&cb);fat_abuf_free(&rb);
    return 1;
}

/* 删除私有文件：清注册表行 + 释放整条私有链 + 目录记录置 0xE5 */
static int fat_b_delete(const Fat32*f,const char*name,char*err,size_t ecap)
{
    size_t clusz; int ndir,found=-1; int rc=-1,nlfn=0;
    unsigned long dclu=0,regclu=0,S=0,head=0;
    unsigned long long G=0,tot;
    wchar_t win[FATB_LFN_MAX+2]; int wlen;
    FatBDir bd;
    if(!fat_b_open_meta(f,&dclu,&regclu,0,&clusz,&ndir,err,ecap))return 0;
    if(!fat_b_dir_open(&bd,f,dclu,clusz,ndir)){snprintf(err,ecap,"内存不足");return 0;}
    wlen=fat_utf8_to_w(name,win,FATB_LFN_MAX+2);
    tot=bd.nclu*(unsigned long long)ndir;
    for(G=0;G<tot;G++){
        const unsigned char*p=fat_b_slot(&bd,G);
        unsigned char r0[32];
        if(!p)break;
        if(p[0]==0x00)continue;      /* 空槽≠目录结束，见 fat_b_list 处说明 */
        if(p[0]==0xE5)continue;
        if(p[11]==FATB_ATTR_LFN||(p[11]&0x08))continue;
        memcpy(r0,p,32);
        if(fat_b_name_match(&bd,G,r0,name,win,wlen)){
            found=1;S=fat_ent_clu(r0);
            nlfn=fat_b_lfn_span(&bd,G,r0);      /* 它的 LFN 项也要一起标删 */
            break;
        }
    }
    if(found<0){snprintf(err,ecap,"私有文件系统里没有 %s",name);
        fat_b_dir_close(&bd);return 0;}
    if(!fat_b_reg_get(f,regclu,clusz,S,&head)){
        snprintf(err,ecap,"注册表行 %lu 读取失败，中止删除",S);fat_b_dir_close(&bd);return 0;}
    if(head>=2&&head<=f->maxclu){
        rc=fat_b_free_chain(f,clusz,head);
        if(rc<0){
            snprintf(err,ecap,"私有链损坏，中止删除（建议先检查）；数据未释放。");
            fat_b_dir_close(&bd);return 0;
        }
    }
    if(!fat_b_reg_set(f,regclu,clusz,S,0)){
        snprintf(err,ecap,"写注册表失败(错误码 %lu)",g_wr_err);fat_b_dir_close(&bd);return 0;}
    /* 短名项 + 它的 LFN 项一起标 0xE5，这几个槽才整体变回可分配 */
    {int t;for(t=0;t<=nlfn;t++){
        unsigned char*p=fat_b_slot_w(&bd,G-(unsigned long long)t);
        if(!p)break;
        p[0]=0xE5;
    }}
    if(!fat_b_dir_flush(&bd)){
        snprintf(err,ecap,"写自定义目录簇失败(错误码 %lu)",g_wr_err);fat_b_dir_close(&bd);return 0;}
    fat_b_dir_close(&bd);
    return 1;
}

/* 彻底清除私有文件系统：释放全部私有链(经注册表)+全部注册表簇+目录簇，并清空 4 槽 */
static int fat_b_wipe(const Fat32*f,char*err,size_t ecap)
{
    unsigned long dclu=0,regclu=0; size_t clusz; unsigned long rpc,cur; int i,guard=0;
    FatABuf t={0};
    if(!fat_b_probe(f,&dclu,&regclu,0)){
        snprintf(err,ecap,"当前没有私有文件系统，无需清除");
        return 0;
    }
    clusz=(size_t)f->spc*f->bps;
    rpc=fat_b_rpc(clusz);
    if(!fat_abuf_ensure(&t,clusz,f->bps)){snprintf(err,ecap,"内存不足");return 0;}
    /* 顺着注册表链：先按其行释放所有文件的私有链，再释放注册表簇自身 */
    cur=regclu;
    while(cur>=2&&cur<=f->maxclu&&guard++<1000000){
        unsigned long r,nx;
        if(!fat_b_cluster_read(f,cur,t.buf)){
            fat_abuf_free(&t);snprintf(err,ecap,"读注册表簇 %lu 失败",cur);return 0;}
        for(r=0;r<rpc;r++){
            unsigned long head=fat_rd32((unsigned char*)t.buf+FATB_HDR+(size_t)4*r);
            if(head>=2&&head<=f->maxclu)fat_b_free_chain(f,clusz,head);
        }
        nx=fat_rd32((unsigned char*)t.buf+12);
        fat_b_release(f,cur);           /* 注册表簇的“坏”标记一并还回空闲 */
        if(nx<2||nx>f->maxclu)break;
        cur=nx;
    }
    fat_abuf_free(&t);
    /* 释放整条目录链（目录簇可能不止一簇） */
    {
        unsigned long cur=dclu; int g2=0;
        while(cur>=2&&cur<=f->maxclu&&g2++<1000000){
            unsigned long nx=0; unsigned char hd[16];
            if(fat_rd_bytes(f->dev,fat_clu_lba(f,cur)*(unsigned long long)f->bps,hd,16))
                nx=fat_rd32(hd+12);
            fat_b_release(f,cur);
            if(nx<2||nx>f->maxclu)break;
            cur=nx;
        }
    }
    for(i=0;i<4;i++)fat_slot_write(f,i,0);   /* 清 4 槽备份（不可用的槽自动跳过） */
    return 1;
}

/* 打印方案二状态（供 fat1.cpp 菜单） */
static void fat_b_print_status(const Fat32*f)
{
    unsigned long dclu=0,regclu=0; int slot=0,i; char c1[32];
    printf("\n  == 方案二：坏簇私有文件系统状态 ==\n");
    if(!fat_b_probe(f,&dclu,&regclu,&slot)){
        printf("  当前【未初始化】。4 槽(首簇号备份，同方案一位置)当前各存：\n");
        for(i=0;i<4;i++){
            unsigned long long ab; unsigned long v; int ok;
            v=fat_slot_read(f,i,&ok);
            if(fat_slot_pos(f,i,&ab)){
                printf("    槽%d %-14s @字节%llu : ",i+1,fat_slot_label(i),ab);
                if(ok)printf("值 %lu%s\n",v,(v>=2&&v<=f->maxclu)?"  (是个合法簇号，但魔数不符)":"");
                else printf("读取失败\n");
            } else printf("    槽%d %-14s : 不适用(自动跳过)\n",i+1,fat_slot_label(i));
        }
        {
            unsigned long st=0; int hv=fat_stash_present(f,&st);
            if(hv){
                unsigned char hd[16];
                printf("  4 槽里已有合法簇号 %lu，但目录簇头魔数不符。该簇前 16 字节 = ",st);
                if(fat_rd_bytes(f->dev,fat_clu_lba(f,st)*(unsigned long long)f->bps,hd,16)){
                    int k;
                    for(k=0;k<16;k++)printf("%02X ",hd[k]);
                    printf(" |");
                    for(k=0;k<16;k++)putchar((hd[k]>=32&&hd[k]<127)?(char)hd[k]:'.');
                    printf("|\n");
                    printf("      -> 全 00 说明簇头内容丢失(写入被系统缓存/卷驱动吞掉)；"
                           "若是别的内容则该簇后来被别人写过。可先“初始化”覆盖重来。\n");
                } else printf("读取失败\n");
            }
        }
        printf("  提示：执行“初始化”会偷 2 个空闲真实簇（都标 0x0FFFFFF7 坏）"
               "分别作注册表头簇/自定义目录簇。\n");
        fat_diag_geometry(f);
        return;
    }
    printf("  在 位：是（4槽保存的目录簇号 + 簇头魔数 F2DR/F2FT 校验通过）\n");
    printf("  自定义目录簇(真实簇号)=%lu   —— 冗余写入 4 槽(本次读自槽%d)\n",dclu,slot+1);
    printf("  注册表(F2FT)头簇(真实簇号)=%lu —— 记录在目录簇头 +8 字节\n",regclu);
    printf("  私有数据簇与私有链簇的真实 FAT 项均为 0x0FFFFFF7“坏簇”，"
           "chkdsk 不会把它们当孤儿簇回收。\n");
    fat_human((unsigned long long)f->spc*(unsigned long long)f->bps,c1,sizeof c1);
    printf("  簇大小 %s（%u 扇区×%uB）\n",c1,(unsigned)f->spc,f->bps);
    {
        size_t clusz=(size_t)f->spc*f->bps; int ndir; char err[128];
        unsigned long reg2=0,dclu2=0;
        if(fat_b_open_meta(f,&dclu2,&reg2,0,&clusz,&ndir,err,sizeof err)){
            int usedRec=0,usedSlot=0; unsigned long epc=fat_b_epc(clusz),rpc=fat_b_rpc(clusz);
            unsigned long long usedData=0,usedChain=0; unsigned long usedRows=0;
            unsigned long long nc=0;
            FatBDir bd;
            if(fat_b_dir_open(&bd,f,dclu2,clusz,ndir)){
                unsigned long long GG,tot2=bd.nclu*(unsigned long long)ndir;
                nc=bd.nclu;
                for(GG=0;GG<tot2;GG++){
                    const unsigned char*p=fat_b_slot(&bd,GG);
                    unsigned char r0[32];
                    unsigned long size,nb;
                    if(!p)break;
                    if(p[0]==0x00)continue;  /* 空槽≠目录结束，见 fat_b_list 处说明 */
                    if(p[0]==0xE5)continue;
                    usedSlot++;
                    if(p[11]==FATB_ATTR_LFN||(p[11]&0x08))continue;
                    memcpy(r0,p,32);
                    usedRec++;
                    size=fat_ent_size(r0);
                    nb=(unsigned long)(((unsigned long long)size+clusz-1)/clusz);
                    usedData+=nb;
                    if(epc)usedChain+=(nb+epc-1)/epc;
                }
                fat_b_dir_close(&bd);
            }
            {   /* 注册表已用行数：沿链统计非 0 行 */
                FatABuf t={0}; unsigned long cur=reg2; int guard2=0;
                if(fat_abuf_ensure(&t,clusz,f->bps)){
                    while(cur>=2&&cur<=f->maxclu&&guard2++<1000000){
                        unsigned long r,nx;
                        if(!fat_b_cluster_read(f,cur,t.buf))break;
                        for(r=0;r<rpc;r++)
                            if(fat_rd32((unsigned char*)t.buf+FATB_HDR+(size_t)4*r))usedRows++;
                        nx=fat_rd32((unsigned char*)t.buf+12);
                        if(nx<2||nx>f->maxclu)break;
                        cur=nx;
                    }
                    fat_abuf_free(&t);
                }
            }
            printf("  目录链 %llu 簇（每簇 %d 槽）；槽使用 %d/%llu，其中文件记录 %d 条"
                   "（其余是 LFN 长名项）。\n",
                   nc,ndir,usedSlot,nc*(unsigned long long)ndir,usedRec);
            printf("  注册表行使用 %lu（每簇 %lu 行）；私有文件合计数据块 %llu、链簇 %llu。\n",
                   usedRows,rpc,usedData,usedChain);
            printf("  卷上空闲真实簇 %lu 个（可继续被偷）。\n",fat_b_free_count(f));
        }
    }
    fat_diag_geometry(f);
}

#endif /* FAT_ENGINE_SCHEME2 */


#endif /* FAT_HIDELIB_H */
