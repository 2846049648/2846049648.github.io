/*
 * fat.cpp -- FAT32 “目录项隐藏”交互工具（完整独立程序）
 *
 * 功能：在所选 FAT32 卷【根目录】创建特殊子目录（FAT / FAT1..FAT4），往内放文件后
 *       “隐藏”：把根目录里该项标记为删除(0xE5)，FAT/簇数据不动，并把首簇号冗余写
 *       入 4 处；可“恢复”、可在隐藏状态下直接浏览/导出/注入内容。
 *
 * 核心引擎在 fat.h（单头文件，其它代码也可 #include "fat.h" 复用）。
 *
 * 构建：
 *   x86_64-w64-mingw32-g++ -O2 -Wall -o fat.exe fat.cpp
 * 用法：
 *   fat               交互：先选物理盘
 *   fat N             直接对 PhysicalDriveN
 *   fat image.img     对 raw 磁盘镜像交互（安全，无需管理员）
 *
 * 物理盘需要管理员权限；写操作会再次要求确认，默认拒绝写 0 号系统盘。
 */
#include "fat.h"

#include <wchar.h>

/* ------------------------------------------------------------------ */
/* 控制台 / 交互辅助                                                    */
/* ------------------------------------------------------------------ */

static void my_flush(void){fflush(stdout);}

/* 列出物理盘 */
static void list_disks(int*out_count)
{
    long n; int absent_run=0,cnt=0;
    for(n=0;n<64;n++){
        char path[32]; FatDev d; DWORD err;
        snprintf(path,sizeof path,"\\\\.\\PhysicalDrive%ld",n);
        if(fat_dev_open(&d,(int)n,NULL,0,1)){
            char sz[32];
            fat_human(d.total,sz,sizeof sz);
            unsigned char m[512]; const char*tag="?";
            if(fat_rd_bytes(&d,0,m,512))tag=(m[510]==0x55&&m[511]==0xAA)?"MBR/GPT":"无分区表";
            printf("  [%ld] %-10s %-10s %s\n",n,sz,tag,d.title);
            cnt++;absent_run=0;fat_dev_close(&d);continue;
        }
        err=GetLastError();
        if(err==ERROR_ACCESS_DENIED){printf("  [%ld] 存在（无管理员权限无法访问）\n",n);absent_run=0;continue;}
        if(++absent_run>=2)break;
    }
    if(out_count)*out_count=cnt;
}

static int running_elevated(void)
{
    HANDLE h=CreateFileA("\\\\.\\PhysicalDrive0",GENERIC_READ,
                         FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
                         OPEN_EXISTING,0,NULL);
    if(h!=INVALID_HANDLE_VALUE){CloseHandle(h);return 1;}
    return GetLastError()!=ERROR_ACCESS_DENIED;
}

static void add_arg(char*d,size_t cap,size_t*off,const char*s)
{while(*s&&*off+1<cap)d[(*off)++]=*s++;d[*off]=0;}

static int relaunch_elevated(int argc,char**argv)
{
    typedef HINSTANCE(WINAPI*ShellA)(HWND,LPCSTR,LPCSTR,LPCSTR,LPCSTR,INT);
    HMODULE sh=LoadLibraryA("shell32.dll");
    ShellA runas=NULL; char exe[MAX_PATH],dir[MAX_PATH],args[1024],params[2048];
    size_t off=0; int i; HINSTANCE r;
    if(!sh)return 0;
    runas=(ShellA)(void*)GetProcAddress(sh,"ShellExecuteA");
    if(!runas){FreeLibrary(sh);return 0;}
    GetModuleFileNameA(NULL,exe,sizeof exe);
    GetCurrentDirectoryA(sizeof dir,dir);
    args[0]=0;
    for(i=1;i<argc;i++){if(i>1)add_arg(args,sizeof args,&off," ");add_arg(args,sizeof args,&off,argv[i]);}
    snprintf(params,sizeof params,"/k \"\"%s\" %s\"",exe,args);
    r=runas(NULL,"runas","cmd.exe",params,dir,SW_SHOWNORMAL);
    FreeLibrary(sh);
    return ((INT_PTR)r>32)?1:0;
}

/* 分区卷“拿控制权”（真实物理盘裸写前的自动短暂卸卷接管）
 * Windows 7+ 禁止经 PhysicalDrive 句柄裸写“挂载中”卷的扇区(WriteFile -> 5 拒绝访问)。
 * 不能带 GENERIC_WRITE 去打开“挂载中”的卷。正确姿势(微软 FSCTL_LOCK_VOLUME 官方样例、Win10/11
 * 实测)：按【盘符 \\.\X:】以 GENERIC_READ + FILE_SHARE_READ|FILE_SHARE_WRITE 打开该卷 ->
 * FSCTL_LOCK_VOLUME(防写期间被重挂) -> FSCTL_DISMOUNT_VOLUME(真正卸下挂载；此后经 d->h 绝对
 * 偏移裸写该卷扇区即被放行) -> 写毕 UNLOCK+Close，Windows 下次访问盘符时自动重新挂载。
 * 注意：必须用盘符 \\.\X: 枚举/打开——本机实测用 FindFirstVolumeW 得到的 \\?\Volume{...}\ 路径
 * 再 CreateFile 一律报 3(路径不存在)，而盘符句柄可正常打开并做 IOCTL。
 * 返回：1=已卸卷接管(成功)；2=目标字节不在任何已挂载卷内(无需接管，可直写)；0=接管失败。 */
static int seize_volume(int disknum,ULONGLONG part_byte,HANDLE*vh)
{
    DWORD mask=GetLogicalDrives();
    int let; int ntry=0,ndisk=0,noopen=0; unsigned long firstopenerr=0;
    *vh=INVALID_HANDLE_VALUE;
    for(let=0;let<26;let++){
        wchar_t p[12]; HANDLE h; VOLUME_DISK_EXTENTS vde; DWORD ret=0; int i;
        ULONGLONG vb=0,vl=0; int ondisk=0,covers=0;
        if(!(mask&(1u<<let)))continue;
        ntry++;
        p[0]=L'\\';p[1]=L'\\';p[2]=L'.';p[3]=L'\\';
        p[4]=(wchar_t)(L'A'+let);p[5]=L':';p[6]=0;
        h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL,OPEN_EXISTING,0,NULL);
        if(h==INVALID_HANDLE_VALUE){ if(!firstopenerr)firstopenerr=(unsigned long)GetLastError(); noopen++; continue; }
        if(!(DeviceIoControl(h,IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,NULL,0,
                             &vde,sizeof vde,&ret,NULL)&&ret>=sizeof vde)){
            CloseHandle(h);continue;
        }
        for(i=0;i<(int)vde.NumberOfDiskExtents;i++){
            vb=(ULONGLONG)vde.Extents[i].StartingOffset.QuadPart;
            vl=(ULONGLONG)vde.Extents[i].ExtentLength.QuadPart;
            if((int)vde.Extents[i].DiskNumber==disknum){
                ondisk=1;
                if(part_byte>=vb&&part_byte<vb+vl)covers=1;
            }
        }
        if(!ondisk){CloseHandle(h);continue;}
        ndisk++;
        printf("  [接管] 盘符 %lc: 位于磁盘%d，物理区间 %llu..%llu%s\n",
               (wchar_t)(L'A'+let),disknum,vb,vb+vl,covers?"(覆盖目标)":"");
        if(!covers){CloseHandle(h);continue;}
        FlushFileBuffers(h);                  /* 先落盘 OS 挂起的脏写，防卸后丢失 */
        if(!DeviceIoControl(h,FSCTL_LOCK_VOLUME,NULL,0,NULL,0,&ret,NULL))
            printf("  [接管] LOCK 失败(err %lu，卷上可能开着文件/窗口)：仍尝试 DISMOUNT。\n",
                   (unsigned long)GetLastError());
        if(!DeviceIoControl(h,FSCTL_DISMOUNT_VOLUME,NULL,0,NULL,0,&ret,NULL)){
            printf("  [接管] DISMOUNT 失败(err %lu)——没拿到该卷裸写权。\n"
                   "         请关掉停在 U 盘里的窗口/文件后重试，或改用镜像模式测试。\n",
                   (unsigned long)GetLastError());
            DeviceIoControl(h,FSCTL_UNLOCK_VOLUME,NULL,0,NULL,0,&ret,NULL);
            CloseHandle(h);
            return 0;
        }
        *vh=h;
        return 1;
    }
    if(ntry==0)
        printf("  [接管] 系统没有任何盘符。\n");
    else if(noopen==ntry)
        printf("  [接管] %d 个盘符全部打不开(首次 err %lu)。\n",ntry,firstopenerr);
    else if(ndisk==0)
        printf("  [接管] 试了 %d 个盘符，没有落在磁盘%d 上的已挂载卷。\n",ntry,disknum);
    else
        printf("  [接管] 磁盘%d 有 %d 个已挂载盘符，但目标字节 %llu 不在其中——无需接管，可直接裸写。\n",
               disknum,ndisk,part_byte);
    return 2;
}

/* ---- 写盘确认策略（会话级，避免每次重复输盘号） ---- */
static int g_isphys=0, g_disk=0, g_armed=0;

/*
 * 物理盘：首次写操作要求输入盘号确认一次；确认后本会话不再询问。
 * 系统盘(0号)保守起见每次都要确认。镜像模式：菜单本身就是选择，直接放行。
 */
static int confirm_write(const char*what,int num)
{
    char buf[64];
    (void)num;
    if(!g_isphys)return 1;                 /* 镜像：直接放行 */
    if(g_armed&&g_disk!=0)return 1;        /* 本会话已确认过，且不是系统盘 */
    printf("  [写盘] %s。请输盘号 %d 确认%s：",what,g_disk,
           g_disk==0?"（系统盘，每次都要输）":"（此后本会话不再询问）");
    if(!fgets(buf,sizeof buf,stdin))return 0;
    buf[strcspn(buf,"\r\n")]=0;
    if(atoi(buf)==g_disk){ if(g_disk!=0)g_armed=1; return 1;}
    printf("  已取消。\n");
    return 0;
}

static char*g_line(char*buf,size_t cap)
{
    if(!fgets(buf,(int)cap,stdin))return NULL;
    buf[strcspn(buf,"\r\n")]=0;
    return buf;
}

static void usage(void)
{
    printf(
      "fat —— FAT32 目录项隐藏工具（中文输出）\n\n"
      "用法:\n"
      "  fat                 交互：先选物理盘再操作\n"
      "  fat N               直接对 PhysicalDriveN\n"
      "  fat 镜像.img         对 raw 磁盘镜像操作（安全，无需管理员）\n\n"
      "机制: 根目录建特殊子目录 FAT(重名则 FAT1..FAT4) -> 放文件 -> “隐藏”(目录项置0xE5,\n"
      "      FAT/簇不动) -> 首簇号冗余存 4 处(保留扇区尾/盘真正尾部/BPB保留区/MBR末分区项)\n"
      "      -> 可“恢复”; 隐藏期间仍可按簇浏览/导出/注入。\n"
      "物理盘需管理员；写操作前会再次确认，默认拒绝写 0 号盘。\n");
}

/* ------------------------------------------------------------------ */
/* 单次命令的实现（菜单调用）                                           */
/* ------------------------------------------------------------------ */

/* 找 PhysicalDrive disknum 上、覆盖 part_byte 的已挂载卷的一个盘符根路径
 * （形如 "E:\\"）。仅在卷当前已挂载且带盘符时返回 1。按盘符枚举(与 seize_volume 同理，
 * 本机用 \\?\Volume{...}\ 路径 CreateFile 一律报 3，而盘符句柄可正常读 extents)。 */
static int fat_mounted_root(int disknum,ULONGLONG part_byte,char*out,size_t cap)
{
    DWORD mask=GetLogicalDrives();
    int let;
    for(let=0;let<26;let++){
        wchar_t p[12]; HANDLE h; VOLUME_DISK_EXTENTS vde; DWORD ret=0; int i;
        if(!(mask&(1u<<let)))continue;
        p[0]=L'\\';p[1]=L'\\';p[2]=L'.';p[3]=L'\\';
        p[4]=(wchar_t)(L'A'+let);p[5]=L':';p[6]=0;
        h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL,OPEN_EXISTING,0,NULL);
        if(h==INVALID_HANDLE_VALUE)continue;
        if(DeviceIoControl(h,IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,NULL,0,
                           &vde,sizeof vde,&ret,NULL)&&ret>=sizeof vde){
            for(i=0;i<(int)vde.NumberOfDiskExtents;i++)
                if((int)vde.Extents[i].DiskNumber==disknum
                   &&part_byte>=(ULONGLONG)vde.Extents[i].StartingOffset.QuadPart
                   &&part_byte<(ULONGLONG)vde.Extents[i].StartingOffset.QuadPart
                                +(ULONGLONG)vde.Extents[i].ExtentLength.QuadPart){
                    snprintf(out,cap,"%c:\\",'A'+let);
                    CloseHandle(h);
                    return 1;
                }
        }
        CloseHandle(h);
    }
    return 0;
}

/* 用 Windows API 在已挂载卷的根路径下创建 FAT/FAT1..FAT4（自动选第一个空闲名）
 * 返回 1=已建(createname 给出名字)；0=候选名全被占；-1=API 失败 */
static int os_create_special(const char*root,const char**createname)
{
    int i; wchar_t wpath[520];
    for(i=0;i<FAT_SPECIAL_N;i++){
        char full[600];
        snprintf(full,sizeof full,"%s%s",root,g_special_names[i]);
        MultiByteToWideChar(CP_UTF8,0,full,-1,wpath,(int)(sizeof wpath/sizeof wpath[0]));
        if(CreateDirectoryW(wpath,NULL)){
            *createname=g_special_names[i]; return 1;
        }
        {
            DWORD er=GetLastError();
            if(er!=ERROR_ALREADY_EXISTS&&er!=ERROR_FILE_EXISTS){
                printf("  Windows 建目录失败 %s（错误码 %lu）。可在资源管理器里手动建。\n",
                       full,(unsigned long)er);
                return -1;
            }
        }
    }
    return 0;
}

static void cmd_status(const Fat32*f)
{
    fat_sp_print_status(f);
    fat_diag_geometry(f);
}

/* with_lock 定义在文件后部（菜单附近），先声明 */
static int with_lock(int phys,int disknum,void(*fn)(Fat32*,int),Fat32*f);

/* 裸写创建（镜像/未挂载卷/找不到盘符时用；由 with_lock 负责锁卷） */
static void cmd_create_raw(Fat32*f,int disknum)
{
    char err[256]; int which; unsigned long clu=0;
    which=fat_pick_free_name(f);
    if(which<0){printf("  候选名 FAT..FAT4 均被占用，无法创建。\n");return;}
    printf("  将创建特殊目录 %s（自动选择空闲名字）。\n",g_special_names[which]);
    if(!confirm_write("创建目录（会分配一个簇并写根目录）",disknum)){
        printf("  已取消。\n");return;
    }
    if(!fat_sp_create(f,which,&clu,err,sizeof err)){
        printf("  %s\n",err);
        fat_diag_geometry(f);   /* 失败时直接给出几何/分配诊断 */
        return;
    }
    printf("  已创建特殊目录 %s：目录簇 %lu。\n",g_special_names[which],clu);
    printf("  -> 现在可把要藏的文件放进去（真实 U 盘可在资源管理器里拷）；拷完选“隐藏”。\n");
}

/* “创建”调度：真实物理盘且该卷当前已挂载(带盘符)时，走 Windows API 建目录
 * （不卸卷、不裸写，避免为一件 OS 能做的事而断开卷）；否则退回裸写创建
 * （镜像、卷未挂载/脱机、或找不到盘符时）。 */
static void cmd_create(Fat32*f,int disknum)
{
    char root[300]; int phys=!f->dev->is_image;
    if(phys&&fat_mounted_root(disknum,(ULONGLONG)f->part_lba*(ULONGLONG)f->bps,
                              root,sizeof root)){
        const char*nm=NULL; int rc;
        printf("  将创建特殊目录 FAT..FAT4（自动选空闲名，经 Windows API，不卸卷）。\n");
        if(!confirm_write("在U盘上创建目录（Windows API 创建）",disknum)){
            printf("  已取消。\n");return;
        }
        rc=os_create_special(root,&nm);
        if(rc==1){
            printf("  已通过 Windows 创建特殊目录 %s（位于 %s）。\n",nm,root);
            printf("  -> 现在可在资源管理器里把要藏的文件拷进 %s 文件夹；拷完选“隐藏”。\n",nm);
        } else if(rc==0){
            printf("  候选名 FAT..FAT4 均已被占用。\n");
        }
        return;
    }
    /* 镜像或卷未挂载：裸写创建（物理时 with_lock 会自动锁/卸卷） */
    with_lock(phys?1:0,disknum,cmd_create_raw,f);
}

static void cmd_hide(Fat32*f,int disknum)
{
    char err[256]; int which=-1; unsigned long clu=0; int mask=0;
    FatSpScan s;
    fat_sp_scan(f,&s);
    if(s.live_n==0){printf("  当前没有可见的特殊目录可隐藏。先用“创建”或在资源管理器建 FAT 目录。\n");return;}
    if(s.live_n>1)
        printf("  [提示] 可见的特殊目录有 %d 个，本次隐藏最小序的那个：%s\n",
               s.live_n,g_special_names[s.live_which]);
    printf("  将隐藏目录 %s（首簇 %lu）。隐藏后其在根目录中消失，FAT 与簇数据保留。\n",
           g_special_names[s.live_which],(unsigned long)s.live_clu);
    if(!confirm_write("隐藏该目录（之后可“恢复”）",disknum))return;
    if(!fat_sp_hide(f,&which,&clu,&mask,err,sizeof err)){
        printf("  %s\n",err);return;
    }
    printf("  已隐藏 %s：目录簇 %lu 已存入备份槽：",g_special_names[which],clu);
    if(mask&1)printf("槽1(保留扇区尾)");
    if(mask&2)printf("槽2(盘尾部)");
    if(mask&4)printf("槽3(BPB)");
    if(mask&8)printf("槽4(MBR)");
    if(mask==1)printf("（仅槽1成功——该槽已足够恢复；其余槽本次不适用/失败）");
    printf("\n");
    printf("  -> 现在资源管理器里看不到该目录了；其簇仍被 FAT 标记为占用，不会覆盖。\n");
    printf("  -> 警告：隐藏后请勿对卷执行 chkdsk/碎片整理，否则可能回收这些簇。\n");
}

static void cmd_restore(Fat32*f,int disknum)
{
    char err[256]; int which=-1; unsigned long clu=0;
    FatSpScan s;
    fat_sp_scan(f,&s);
    if(s.live_n>0){printf("  目录现在本来就是可见的（%s），无需恢复。\n",g_special_names[s.live_which]);return;}
    if(s.del_n==0&&!fat_stash_present(f,&clu)){
        printf("  没有找到被隐藏的目录（既无 0xE5 特殊项也无簇号备份）。\n");return;
    }
    printf("  检测到被隐藏的特殊目录。恢复后其内容会在根目录重新出现。\n");
    if(!confirm_write("恢复该目录",disknum))return;
    if(!fat_sp_restore(f,&which,&clu,err,sizeof err)){
        printf("  %s\n",err);return;
    }
    printf("  已恢复 %s（首簇 %lu）。\n",g_special_names[which],clu);
    printf("  -> 簇号备份槽仍保留（下次隐藏会覆盖）。\n");
}

/* 解析当前特殊目录簇（可见=用之；否则=隐藏备份），供浏览/导出/注入 */
static int resolve_dir(Fat32*f,unsigned long*clu,int*hidden,char*err,size_t ecap)
{
    if(!fat_sp_target_cluster(f,hidden,clu,0)){
        snprintf(err,ecap,"当前没有特殊目录（既无可见 FAT 目录，也无隐藏备份）。先“创建”。");
        return 0;
    }
    return 1;
}

static void cmd_list(Fat32*f)
{
    unsigned long dirclu=0; int hidden=0; char err[256];
    FatSpEnt e[512]; int n,i;
    if(!resolve_dir(f,&dirclu,&hidden,err,sizeof err)){printf("  %s\n",err);return;}
    n=fat_sp_list_dir(f,dirclu,e,512);
    if(n<0){printf("  读取目录簇链失败。\n");return;}
    printf("  == %s内容（目录簇 %lu）==\n",hidden?"隐藏的":"可见的",dirclu);
    if(hidden)printf("  [隐藏态] 以下条目操作系统当前不可见，但可经此工具访问。\n");
    if(n==0){printf("  （空目录）\n");return;}
    printf("  序号  名称           类型       大小         首簇\n");
    for(i=0;i<n&&i<512;i++){
        char sz[24];
        if(e[i].isdir)snprintf(sz,sizeof sz,"<目录>");
        else fat_human(e[i].size,sz,sizeof sz);
        printf("  %-4d  %-14s %-6s %-12s %lu\n",i+1,e[i].name,
               e[i].isdir?"目录":"文件",sz,e[i].clu);
    }
    printf("  共 %d 项。%s\n",n,hidden?"":"若把此目录隐藏，以上内容将一起隐藏。");
}

static void cmd_export(Fat32*f)
{
    unsigned long dirclu=0; int hidden=0; char err[256];
    FatSpEnt e[512]; int n,ix; char buf[1024],full[2048]; char sz[32];
    char nm2[16];
    if(!resolve_dir(f,&dirclu,&hidden,err,sizeof err)){printf("  %s\n",err);return;}
    n=fat_sp_list_dir(f,dirclu,e,512);
    if(n<=0){printf("  目录为空或读取失败，没有可导出的文件。\n");return;}
    printf("  == 选择要导出的文件 ==\n");
    cmd_list(f);
    printf("  输入序号 [1..%d]（0 取消）：",n);
    if(!g_line(buf,sizeof buf))return;
    ix=atoi(buf); if(ix<=0||ix>n){printf("  已取消。\n");return;}
    if(e[ix-1].isdir){printf("  %s 是子目录，暂不支持整目录导出，请导出具体文件。\n",e[ix-1].name);return;}
    snprintf(nm2,sizeof nm2,"%s",e[ix-1].name);
    printf("  导出到哪个目录（文件夹需已存在；回车取消）：");
    if(!g_line(buf,sizeof buf))return;
    if(!buf[0])return;
    if(!fat_is_directory(buf)){printf("  目录不存在：%s\n",buf);return;}
    {
        size_t dl=strlen(buf);
        if(dl>0&&buf[dl-1]!='\\'&&buf[dl-1]!='/')
            snprintf(full,sizeof full,"%s\\%s",buf,nm2);
        else
            snprintf(full,sizeof full,"%s%s",buf,nm2);
    }
    fat_human(e[ix-1].size,sz,sizeof sz);
    printf("  导出 %s（%s）-> %s\n",nm2,sz,full);
    if(!fat_sp_export(f,dirclu,nm2,full,err,sizeof err)){
        printf("  导出失败：%s\n",err);return;
    }
    printf("  导出成功。原内容仍保留在目录里。\n");
}

static void cmd_inject(Fat32*f,int disknum)
{
    unsigned long dirclu=0; int hidden=0; char err[256];
    unsigned long clu=0; char buf[1024];
    if(!resolve_dir(f,&dirclu,&hidden,err,sizeof err)){printf("  %s\n",err);return;}
    printf("  要注入的宿主文件完整路径（回车取消）：");
    if(!g_line(buf,sizeof buf))return;
    if(!buf[0])return;
    {
        wchar_t w[2048]; DWORD a;
        /* 路径来自 UTF-8 控制台，必须转 W 再查，否则含中文的路径被按 ANSI(GBK) 解释而“找不到” */
        if(!MultiByteToWideChar(CP_UTF8,0,buf,-1,w,(int)(sizeof w/sizeof w[0])))
            {printf("  路径转宽字符失败。\n");return;}
        a=GetFileAttributesW(w);
        if(a==INVALID_FILE_ATTRIBUTES){printf("  找不到文件：%s\n",buf);return;}
        if(a&FILE_ATTRIBUTE_DIRECTORY){printf("  这是一个目录，请给文件路径。\n");return;}
    }
    printf("  %s状态写入（会分配若干数据簇）。目录簇=%lu\n",
           hidden?"隐藏":"可见",dirclu);
    if(!confirm_write("注入文件",disknum)){printf("  已取消。\n");return;}
    if(!fat_sp_inject(f,dirclu,buf,&clu,err,sizeof err)){
        printf("  注入失败：%s\n",err);
        fat_diag_geometry(f);
        return;
    }
    printf("  注入成功：文件首簇 %lu，已登记到目录（%s态）。\n",clu,hidden?"隐藏":"可见");
    printf("  -> 若为隐藏态，恢复目录后该文件也会一并出现。\n");
}

/* ------------------------------------------------------------------ */
/* 主菜单                                                              */
/* ------------------------------------------------------------------ */

/* 写类操作统一：物理盘时先短暂卸卷接管该分区卷(见 seize_volume)，写毕解锁放回。
 * 接管后引擎的写入一律经 d->h(PhysicalDrive) 以绝对偏移裸写。 */
static int with_lock(int phys,int disknum,void(*fn)(Fat32*,int),Fat32*f)
{
    FatDev*d=f->dev;
    if(phys&&!d->is_image){
        ULONGLONG part_byte=(ULONGLONG)f->part_lba*(ULONGLONG)f->bps;
        int rc;
        d->vol_h=NULL;
        rc=seize_volume(disknum,part_byte,&d->vol_h);
        if(rc==1)
            printf("  [接管] 已锁定并短暂卸下该分区卷，取得其扇区裸写权；写后自动放回重挂。\n");
        else if(rc==0)
            printf("  [提示] 分区卷未能重新卸下接管(可能已处于卸卷态，或卷上开着文件)。\n"
                   "         仍继续尝试裸写：若下方操作成功可忽略本行；若报 Windows 拒绝访问\n"
                   "         (错误码 5)，请关掉停在 U 盘里的窗口/文件后重试，或改用镜像模式。\n");
        /* rc==2：目标字节不在任何挂载卷内，物理句柄直写即可，无需接管 */
    }
    fn(f,phys?disknum:0);
    /* 放回卷之前先把裸写刷到设备：否则内容可能还留在系统缓存，卷驱动重挂时用旧视图覆盖。 */
    fat_dev_flush(d);
    if(phys&&d->vol_h&&d->vol_h!=INVALID_HANDLE_VALUE){
        DWORD lr=0;
        DeviceIoControl(d->vol_h,FSCTL_UNLOCK_VOLUME,NULL,0,NULL,0,&lr,NULL);
        CloseHandle(d->vol_h);
        d->vol_h=NULL;
        printf("  [放回] 已解锁放回；Windows 在下次访问盘符时自动重新挂载(没刷新就按 F5)。\n");
    }
    return 1;
}

static void show_menu(Fat32*f,int disknum,int image)
{
    int loop=1,phys=!image;
    char b[32]; int v;
    while(loop){
        char c1[32];
        fat_human((unsigned long long)(f->part_secs)*f->bps,c1,sizeof c1);
        printf("\n==========================================================\n");
        printf("  当前 FAT32 卷%s：起始 LBA %llu，%s；每扇区 %uB，每簇 %u 扇区，"
               "保留 %llu，FAT×%u，根簇 %llu\n",
               f->superfloppy?"(整卷,无分区表)":"分区",
               (unsigned long long)f->part_lba,c1,
               f->bps,f->spc,(unsigned long long)f->rsvd,f->nfat,(unsigned long long)f->rootclu);
        printf("----------------------------------------------------------\n");
        printf("  1) 状态/槽位查看\n");
        printf("  2) 创建特殊目录 FAT(重名自动 FAT1..FAT4)\n");
        printf("  3) 隐藏 特殊目录\n");
        printf("  4) 恢复 被隐藏目录\n");
        printf("  5) 浏览 特殊目录内容（隐藏/可见都可）\n");
        printf("  6) 导出 其中文件到本机\n");
        printf("  7) 注入 宿主文件进特殊目录\n");
        printf("  0) 退出\n");
        printf("  请选择："); my_flush();
        if(!fgets(b,sizeof b,stdin))break;
        v=atoi(b);
        switch(v){
        case 1: cmd_status(f); break;
        case 2: cmd_create(f,disknum); break;   /* 内部自行决定 API 建 or 裸写+锁卷 */
        case 3: with_lock(phys,disknum,cmd_hide,f); break;
        case 4: with_lock(phys,disknum,cmd_restore,f); break;
        case 5: cmd_list(f); break;
        case 6: cmd_export(f); break;
        case 7: with_lock(phys,disknum,cmd_inject,f); break;
        case 0: loop=0; break;
        default: printf("  无效选项。\n"); break;
        }
    }
}

int main(int argc,char**argv)
{
    int disknum=-1; const char*image=NULL;
    FatDev d; Fat32 f={0}; char err[256];
    int is_write=1;

    SetConsoleOutputCP(CP_UTF8);
    setvbuf(stdout,NULL,_IONBF,0);
    setvbuf(stderr,NULL,_IONBF,0);
    SetConsoleCP(CP_UTF8);

    printf("fat —— FAT32 目录项隐藏工具\n");
    if(argc>1){
        if(_stricmp(argv[1],"-h")==0||_stricmp(argv[1],"--help")==0){usage();return 0;}
        if(isdigit((unsigned char)argv[1][0])&&strspn(argv[1],"0123456789")==strlen(argv[1]))
            disknum=atoi(argv[1]);
        else image=argv[1];
    }

    if(!image&&disknum<0){
        int count=0;
        printf("\n  可用物理磁盘：\n");
        list_disks(&count);
        if(count==0&&!running_elevated()){
            printf("\n  未以管理员运行且打不开磁盘。尝试提权……\n");
            if(relaunch_elevated(argc,argv)){
                printf("  UAC 提权窗口已弹出，请在弹窗中选“是”。\n");
                return 0;
            }
            printf("\n  请手动“右键→以管理员身份运行”。\n");
            return 1;
        }
        printf("  输入要操作的磁盘号：");
        {
            char bb[32];
            if(!g_line(bb,sizeof bb))return 0;
            disknum=atoi(bb);
        }
    }
    if(!image&&disknum<0){usage();return 0;}

    if(image){
        if(!fat_dev_open(&d,0,image,is_write,0))return 1;
        printf("  已打开镜像: %s (无需管理员)\n",image);
    } else {
        if(!fat_dev_open(&d,disknum,NULL,is_write,0)){
            if(!running_elevated()){
                printf("\n  未以管理员运行。尝试提权……\n");
                if(relaunch_elevated(argc,argv)){
                    printf("  UAC 提权窗口已弹出，请在弹窗中选“是”。\n");
                    return 0;
                }
            }
            printf("\n  若因权限失败，请右键以管理员身份运行。\n");
            return 1;
        }
    }
    if(d.total==0){printf("  设备长度未知。\n");fat_dev_close(&d);return 1;}

    if(!fat32_open(&d,&f,err,sizeof err)){
        printf("  %s\n",err);
        fat_dev_close(&d);
        return 1;
    }
    {
        char sz[32];
        fat_human(d.total,sz,sizeof sz);
        printf("  设备: %s   容量 %s   扇区 %lu 字节\n",d.title,sz,(unsigned long)d.sector);
    }
    if(!image){
        printf("  [提示] 每个写操作会自动短暂卸卷接管该分区卷，写完立即放回重挂(盘符保留)。\n");
    }
    g_isphys=image?0:1; g_disk=disknum; g_armed=0;

    show_menu(&f,disknum,image?1:0);

    fat_dev_close(&d);   /* 若有遗留的卷锁随句柄关闭一并释放 */
    printf("\n  再见。\n");
    return 0;
}
