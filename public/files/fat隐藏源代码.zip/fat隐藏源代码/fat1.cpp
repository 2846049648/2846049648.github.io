/*
 * fat1.cpp -- FAT32 “坏簇私有文件系统”交互工具（方案二，完整独立程序）
 *
 * 与方案一(fat.exe，0xE5 删除标记隐藏子目录)不同：本程序在所选 FAT32 卷里
 * 自己“创造一个依附于 FAT32 的私有文件系统”，机制是【偷簇】：
 *   - 把装私有数据的簇、以及自建的注册表簇/自定义目录簇，在真实 FAT 表里
 *     都标为 0x0FFFFFF7 “坏簇”。chkdsk 之类“孤儿簇回收”工具不会把坏簇当
 *     孤儿/空闲簇回收，因此比方案一更抗 chkdsk（这正是方案二的设计动机）。
 *   - 私有布局（只持久化两个簇号）：
 *       4 槽(槽1..槽4) -> 自定义目录簇(F2DR) -> 簇头 +8 -> 注册表头簇(F2FT)。
 *       注册表行[G] = 文件 G 的“私有链头簇”；文件大小存在目录记录里，
 *       块数 nb=ceil(大小/簇字节)，再顺着“每文件一条的私有链簇链”逐块读出
 *       各数据簇真实簇号；链簇末 4 字节 = NEXT 下一链簇(0=尾)，可无限续接。
 *   - 目录簇与注册表簇都可串链（簇头 +12 = NEXT）。目录记录里存的是
 *     【全局槽号 G】= 目录簇序号×每簇记录数 + 簇内槽号，与注册表行号一一对应；
 *     删除/清除时把整条私有链与注册表登记一并还回 FAT32 空闲。
 *   - 支持长文件名：长名/非 ASCII 名会另写若干 attr=0x0F 的 LFN 项（13 个
 *     UTF-16 码元/项、倒序、最高序带 0x40、字节13 存 8.3 校验和，同 FAT32 规范），
 *     并自动生成 XXXXXX~N.EXT 的 8.3 别名；能塞进 8.3 的名字只写短名项。
 *     列目录/导出/删除时按长名或短名都能匹配（大小写不敏感）。
 *
 * 核心引擎在 fat.h 的方案二段(fat_b_*，由宏 FAT_ENGINE_SCHEME2 控制)，其它
 * 代码也可 #include "fat.h"(先 #define FAT_ENGINE_SCHEME2) 复用。
 *
 * 构建：
 *   x86_64-w64-mingw32-g++ -O2 -Wall -DFAT_ENGINE_SCHEME2 -o fat1.exe fat1.cpp
 *   （或在本文件内已 define，见下）
 * 用法：
 *   fat1               交互：先选物理盘
 *   fat1 N             直接对 PhysicalDriveN
 *   fat1 image.img     对 raw 磁盘镜像交互（安全，无需管理员）
 *
 * 物理盘需要管理员权限；写操作会再次要求确认，默认拒绝写 0 号系统盘。
 */
#define FAT_ENGINE_SCHEME2 1
#include "fat.h"

#include <wchar.h>

/* ------------------------------------------------------------------ */
/* 控制台 / 交互辅助（同 fat.cpp，独立副本）                             */
/* ------------------------------------------------------------------ */

static void my_flush(void){fflush(stdout);}

/* 列出物理盘 */
static void list_disks(int*out_count)
{
    long n; int absent_run=0,cnt=0;
    for(n=0;n<64;n++){
        char path[32]; FatDev d; DWORD err;
        snprintf(path,sizeof path,"\\\\.\\PhysicalDrive%ld",n);
        if(fat_dev_open(&d,(int)n,NULL,0,1)){
            char sz[32];
            fat_human(d.total,sz,sizeof sz);
            unsigned char m[512]; const char*tag="?";
            if(fat_rd_bytes(&d,0,m,512))tag=(m[510]==0x55&&m[511]==0xAA)?"MBR/GPT":"无分区表";
            printf("  [%ld] %-10s %-10s %s\n",n,sz,tag,d.title);
            cnt++;absent_run=0;fat_dev_close(&d);continue;
        }
        err=GetLastError();
        if(err==ERROR_ACCESS_DENIED){printf("  [%ld] 存在（无管理员权限无法访问）\n",n);absent_run=0;continue;}
        if(++absent_run>=2)break;
    }
    if(out_count)*out_count=cnt;
}

static int running_elevated(void)
{
    HANDLE h=CreateFileA("\\\\.\\PhysicalDrive0",GENERIC_READ,
                         FILE_SHARE_READ|FILE_SHARE_WRITE,NULL,
                         OPEN_EXISTING,0,NULL);
    if(h!=INVALID_HANDLE_VALUE){CloseHandle(h);return 1;}
    return GetLastError()!=ERROR_ACCESS_DENIED;
}

static void add_arg(char*d,size_t cap,size_t*off,const char*s)
{while(*s&&*off+1<cap)d[(*off)++]=*s++;d[*off]=0;}

static int relaunch_elevated(int argc,char**argv)
{
    typedef HINSTANCE(WINAPI*ShellA)(HWND,LPCSTR,LPCSTR,LPCSTR,LPCSTR,INT);
    HMODULE sh=LoadLibraryA("shell32.dll");
    ShellA runas=NULL; char exe[MAX_PATH],dir[MAX_PATH],args[1024],params[2048];
    size_t off=0; int i; HINSTANCE r;
    if(!sh)return 0;
    runas=(ShellA)(void*)GetProcAddress(sh,"ShellExecuteA");
    if(!runas){FreeLibrary(sh);return 0;}
    GetModuleFileNameA(NULL,exe,sizeof exe);
    GetCurrentDirectoryA(sizeof dir,dir);
    args[0]=0;
    for(i=1;i<argc;i++){if(i>1)add_arg(args,sizeof args,&off," ");add_arg(args,sizeof args,&off,argv[i]);}
    snprintf(params,sizeof params,"/k \"\"%s\" %s\"",exe,args);
    r=runas(NULL,"runas","cmd.exe",params,dir,SW_SHOWNORMAL);
    FreeLibrary(sh);
    return ((INT_PTR)r>32)?1:0;
}

/* 分区卷“拿控制权”（真实物理盘裸写前的自动短暂卸卷接管）。同 fat.cpp。
 * 返回：1=已卸卷接管(成功)；2=目标字节不在任何已挂载卷内(无需接管，可直写)；0=接管失败。 */
static int seize_volume(int disknum,ULONGLONG part_byte,HANDLE*vh)
{
    DWORD mask=GetLogicalDrives();
    int let; int ntry=0,ndisk=0,noopen=0; unsigned long firstopenerr=0;
    *vh=INVALID_HANDLE_VALUE;
    for(let=0;let<26;let++){
        wchar_t p[12]; HANDLE h; VOLUME_DISK_EXTENTS vde; DWORD ret=0; int i;
        ULONGLONG vb=0,vl=0; int ondisk=0,covers=0;
        if(!(mask&(1u<<let)))continue;
        ntry++;
        p[0]=L'\\';p[1]=L'\\';p[2]=L'.';p[3]=L'\\';
        p[4]=(wchar_t)(L'A'+let);p[5]=L':';p[6]=0;
        h=CreateFileW(p,GENERIC_READ,FILE_SHARE_READ|FILE_SHARE_WRITE,
                      NULL,OPEN_EXISTING,0,NULL);
        if(h==INVALID_HANDLE_VALUE){ if(!firstopenerr)firstopenerr=(unsigned long)GetLastError(); noopen++; continue; }
        if(!(DeviceIoControl(h,IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,NULL,0,
                             &vde,sizeof vde,&ret,NULL)&&ret>=sizeof vde)){
            CloseHandle(h);continue;
        }
        for(i=0;i<(int)vde.NumberOfDiskExtents;i++){
            vb=(ULONGLONG)vde.Extents[i].StartingOffset.QuadPart;
            vl=(ULONGLONG)vde.Extents[i].ExtentLength.QuadPart;
            if((int)vde.Extents[i].DiskNumber==disknum){
                ondisk=1;
                if(part_byte>=vb&&part_byte<vb+vl)covers=1;
            }
        }
        if(!ondisk){CloseHandle(h);continue;}
        ndisk++;
        printf("  [接管] 盘符 %lc: 位于磁盘%d，物理区间 %llu..%llu%s\n",
               (wchar_t)(L'A'+let),disknum,vb,vb+vl,covers?"(覆盖目标)":"");
        if(!covers){CloseHandle(h);continue;}
        FlushFileBuffers(h);                  /* 先落盘 OS 挂起的脏写，防卸后丢失 */
        if(!DeviceIoControl(h,FSCTL_LOCK_VOLUME,NULL,0,NULL,0,&ret,NULL))
            printf("  [接管] LOCK 失败(err %lu，卷上可能开着文件/窗口)：仍尝试 DISMOUNT。\n",
                   (unsigned long)GetLastError());
        if(!DeviceIoControl(h,FSCTL_DISMOUNT_VOLUME,NULL,0,NULL,0,&ret,NULL)){
            printf("  [接管] DISMOUNT 失败(err %lu)——没拿到该卷裸写权。\n"
                   "         请关掉停在 U 盘里的窗口/文件后重试，或改用镜像模式测试。\n",
                   (unsigned long)GetLastError());
            DeviceIoControl(h,FSCTL_UNLOCK_VOLUME,NULL,0,NULL,0,&ret,NULL);
            CloseHandle(h);
            return 0;
        }
        *vh=h;
        return 1;
    }
    if(ntry==0)
        printf("  [接管] 系统没有任何盘符。\n");
    else if(noopen==ntry)
        printf("  [接管] %d 个盘符全部打不开(首次 err %lu)。\n",ntry,firstopenerr);
    else if(ndisk==0)
        printf("  [接管] 试了 %d 个盘符，没有落在磁盘%d 上的已挂载卷。\n",ntry,disknum);
    else
        printf("  [接管] 磁盘%d 有 %d 个已挂载盘符，但目标字节 %llu 不在其中——无需接管，可直接裸写。\n",
               disknum,ndisk,part_byte);
    return 2;
}

/* ---- 写盘确认策略（会话级，避免每次重复输盘号） ---- */
static int g_isphys=0, g_disk=0, g_armed=0;

static int confirm_write(const char*what,int num)
{
    char buf[64];
    (void)num;
    if(!g_isphys)return 1;                 /* 镜像：直接放行 */
    if(g_armed&&g_disk!=0)return 1;        /* 本会话已确认过，且不是系统盘 */
    printf("  [写盘] %s。请输盘号 %d 确认%s：",what,g_disk,
           g_disk==0?"（系统盘，每次都要输）":"（此后本会话不再询问）");
    if(!fgets(buf,sizeof buf,stdin))return 0;
    buf[strcspn(buf,"\r\n")]=0;
    if(atoi(buf)==g_disk){ if(g_disk!=0)g_armed=1; return 1;}
    printf("  已取消。\n");
    return 0;
}

static char*g_line(char*buf,size_t cap)
{
    if(!fgets(buf,(int)cap,stdin))return NULL;
    buf[strcspn(buf,"\r\n")]=0;
    return buf;
}

static void usage(void)
{
    printf(
      "fat1 —— FAT32 坏簇私有文件系统工具（方案二，中文输出）\n\n"
      "用法:\n"
      "  fat1                交互：先选物理盘再操作\n"
      "  fat1 N              直接对 PhysicalDriveN\n"
      "  fat1 镜像.img        对 raw 磁盘镜像操作（安全，无需管理员）\n\n"
      "机制: 在 FAT32 卷内偷空闲簇并标为 0x0FFFFFF7“坏簇”(chkdsk 不回收)，自建\n"
      "      私有文件系统：数据簇 + 注册表簇(F2FT) + 自定义目录簇(F2DR)。目录簇号\n"
      "      按方案一冗余存 4 槽(保留扇区尾/盘尾/BPB保留区/MBR末分区项)，注册表头\n"
      "      簇号存在目录簇头 +8。目录记录存“全局槽号G”=注册表行号，行[G]指向该文件\n"
      "      的私有链头簇；私有链按序存各数据簇真实簇号，末4B=NEXT 可无限续接。\n"
      "      目录簇与注册表簇都可串链(+12=NEXT)。支持长文件名(LFN)，并给长名自动\n"
      "      生成 8.3 别名。可对私有文件做 导入/导出/删除。\n"
      "物理盘需管理员；写操作前会再次确认，默认拒绝写 0 号盘。\n");
}

/* ------------------------------------------------------------------ */
/* 单次命令的实现（菜单调用）                                           */
/* ------------------------------------------------------------------ */

static void cmd_status(Fat32*f)
{
    fat_b_print_status(f);
}

static void cmd_list(Fat32*f)
{
    FatBEnt e[256]; int n,i; char sz[24];
    n=fat_b_list(f,e,256);
    if(n<0){printf("  当前没有私有文件系统。先选“初始化”。\n");return;}
    printf("  == 私有文件系统内容 ==\n");
    if(n==0){printf("  （空）\n");return;}
    printf("  序号  名称                   8.3别名      大小       链长(块)  首真实簇(标坏)\n");
    for(i=0;i<n&&i<256;i++){
        fat_human(e[i].size,sz,sizeof sz);
        printf("  %-4d  %-22s %-12s %-10s %-8lu %lu\n",i+1,e[i].name,
               e[i].alias[0]?e[i].alias:"-",sz,
               e[i].chunks,e[i].firstreal);
    }
    printf("  共 %d 个私有文件。这些数据簇在真实 FAT 里都显示为“坏簇”，"
           "普通文件系统/资源管理器看不到。\n",n);
}

static void cmd_init(Fat32*f,int disknum)
{
    char err[256]; unsigned long dirclu=0;
    if(!confirm_write("初始化私有文件系统(偷2个簇并标坏+写4槽备份)",disknum)){
        printf("  已取消。\n");return;
    }
    if(!fat_b_init(f,&dirclu,err,sizeof err)){
        printf("  %s\n",err);
        fat_b_print_status(f);      /* 失败时给出几何/槽位诊断 */
        return;
    }
    printf("  初始化成功：自定义目录簇(真实簇号，已标坏)=%lu，"
           "注册表(F2FT)头簇号记录在目录簇头 +8 字节。\n",dirclu);
    printf("  -> 目录簇号已按方案一写入 4 槽。现在可“导入”宿主文件进私有文件系统。\n");
    printf("  -> 私有文件对操作系统不可见（簇被标 0x0FFFFFF7 坏簇），"
           "chkdsk 也不会把它们当孤儿回收。\n");
}

static void cmd_import(Fat32*f,int disknum)
{
    char buf[1024],err[256];
    printf("  要导入的宿主文件完整路径（支持长名/中文名，如 C:\\a.txt；回车取消）：");
    if(!g_line(buf,sizeof buf))return;
    if(!buf[0])return;
    {
        wchar_t w[2048]; DWORD a;
        /* 路径来自 UTF-8 控制台，必须转 W 再查，否则含中文的路径被按 ANSI(GBK) 解释而“找不到” */
        if(!MultiByteToWideChar(CP_UTF8,0,buf,-1,w,(int)(sizeof w/sizeof w[0])))
            {printf("  路径转宽字符失败。\n");return;}
        a=GetFileAttributesW(w);
        if(a==INVALID_FILE_ATTRIBUTES){printf("  找不到文件：%s\n",buf);return;}
        if(a&FILE_ATTRIBUTE_DIRECTORY){printf("  这是一个目录，请给文件路径。\n");return;}
    }
    if(!confirm_write("导入文件(偷若干簇并标坏+登记私有目录)",disknum))return;
    if(!fat_b_import(f,buf,err,sizeof err)){
        printf("  导入失败：%s\n",err);
        fat_b_print_status(f);
        return;
    }
    printf("  导入成功。文件字节已写入若干“标坏”的数据簇，其簇号按序存进该文件\n");
    printf("  专属的私有链簇链，并在注册表登记“行[G]=链头簇”、目录记录存“全局槽号G”。\n");
    printf("  长名/非 ASCII 名会连同 LFN 长名项一起写入，并自动生成 XXXX~N.EXT 短名别名。\n");
    printf("  -> 选“3 列出”可见；资源管理器看不到它。\n");
}

static void cmd_export(Fat32*f)
{
    char buf[1024],full[2048],err[256]; char base[1024];
    FatBEnt e[256]; int n;
    n=fat_b_list(f,e,256);
    if(n<=0){printf("  私有文件系统为空或未初始化，没有可导出的文件。\n");return;}
    cmd_list(f);
    printf("  输入要导出的文件名（长名/短名/别名都认，大小写不敏感；0 取消）：");
    if(!g_line(buf,sizeof buf))return;
    if(!buf[0]||buf[0]=='0')return;
    snprintf(base,sizeof base,"%s",buf);
    printf("  导出到哪个目录（文件夹需已存在；回车取消）：");
    if(!g_line(buf,sizeof buf))return;
    if(!buf[0])return;
    if(!fat_is_directory(buf)){printf("  目录不存在：%s\n",buf);return;}
    {
        size_t dl=strlen(buf);
        if(dl>0&&buf[dl-1]!='\\'&&buf[dl-1]!='/')
            snprintf(full,sizeof full,"%s\\%s",buf,base);
        else
            snprintf(full,sizeof full,"%s%s",buf,base);
    }
    if(!fat_b_export(f,base,full,err,sizeof err)){
        printf("  导出失败：%s\n",err);return;
    }
    printf("  导出成功 -> %s（私有内容仍保留在私有文件系统里）。\n",full);
}

static void cmd_delete(Fat32*f,int disknum)
{
    char buf[1024],err[256]; FatBEnt e[256]; int n;
    n=fat_b_list(f,e,256);
    if(n<=0){printf("  私有文件系统为空或未初始化，没有可删除的文件。\n");return;}
    cmd_list(f);
    printf("  输入要删除的文件名（0 取消）：");
    if(!g_line(buf,sizeof buf))return;
    if(!buf[0]||buf[0]=='0')return;
    if(!confirm_write("删除私有文件(释放其整条私有链+数据簇回空闲)",disknum))return;
    if(!fat_b_delete(f,buf,err,sizeof err)){
        printf("  删除失败：%s\n",err);return;
    }
    printf("  已删除 %s：注册表登记已清，其数据簇与私有链簇都已还回 FAT 空闲"
           "（不再是坏簇）。\n",buf);
}

static void cmd_wipe(Fat32*f,int disknum)
{
    char err[256];
    if(!confirm_write("彻底清除私有文件系统(释放全部坏簇+清空4槽)",disknum))return;
    if(!fat_b_wipe(f,err,sizeof err)){
        printf("  %s\n",err);return;
    }
    printf("  已清除。全部私有数据簇与两个自定义簇已还回 FAT 空闲，4 槽备份已清空。\n");
    printf("  -> 现在可重新“初始化”，或当作普通 FAT32 卷正常使用。\n");
}

/* ------------------------------------------------------------------ */
/* 主菜单（with_lock 同 fat.cpp）                                       */
/* ------------------------------------------------------------------ */

static int with_lock(int phys,int disknum,void(*fn)(Fat32*,int),Fat32*f)
{
    FatDev*d=f->dev;
    if(phys&&!d->is_image){
        ULONGLONG part_byte=(ULONGLONG)f->part_lba*(ULONGLONG)f->bps;
        int rc;
        d->vol_h=NULL;
        rc=seize_volume(disknum,part_byte,&d->vol_h);
        if(rc==1)
            printf("  [接管] 已锁定并短暂卸下该分区卷，取得其扇区裸写权；写后自动放回重挂。\n");
        else if(rc==0)
            printf("  [提示] 分区卷未能重新卸下接管(可能已处于卸卷态，或卷上开着文件)。\n"
                   "         仍继续尝试裸写：若下方操作成功可忽略本行；若报 Windows 拒绝访问\n"
                   "         (错误码 5)，请关掉停在 U 盘里的窗口/文件后重试，或改用镜像模式。\n");
    }
    fn(f,phys?disknum:0);
    /* 放回卷之前先把裸写刷到设备：否则内容可能还留在系统缓存，卷驱动重挂时用旧视图覆盖。 */
    fat_dev_flush(d);
    if(phys&&d->vol_h&&d->vol_h!=INVALID_HANDLE_VALUE){
        DWORD lr=0;
        DeviceIoControl(d->vol_h,FSCTL_UNLOCK_VOLUME,NULL,0,NULL,0,&lr,NULL);
        CloseHandle(d->vol_h);
        d->vol_h=NULL;
        printf("  [放回] 已解锁放回；Windows 在下次访问盘符时自动重新挂载(没刷新就按 F5)。\n");
    }
    return 1;
}

static void show_menu(Fat32*f,int disknum,int image)
{
    int loop=1,phys=!image;
    char b[32]; int v;
    while(loop){
        char c1[32];
        fat_human((unsigned long long)(f->part_secs)*f->bps,c1,sizeof c1);
        printf("\n==========================================================\n");
        printf("  当前 FAT32 卷%s：起始 LBA %llu，%s；每扇区 %uB，每簇 %u 扇区，"
               "保留 %llu，FAT×%u，根簇 %llu\n",
               f->superfloppy?"(整卷,无分区表)":"分区",
               (unsigned long long)f->part_lba,c1,
               f->bps,f->spc,(unsigned long long)f->rsvd,f->nfat,(unsigned long long)f->rootclu);
        printf("----------------------------------------------------------\n");
        printf("  方案二：坏簇私有文件系统（偷簇标 0x0FFFFFF7，抗 chkdsk 回收）\n");
        printf("  1) 状态/诊断\n");
        printf("  2) 初始化 私有文件系统\n");
        printf("  3) 列出   私有文件\n");
        printf("  4) 导入   宿主文件 -> 私有FS\n");
        printf("  5) 导出   私有文件 -> 宿主\n");
        printf("  6) 删除   私有文件（释放其坏簇）\n");
        printf("  7) 彻底清除私有文件系统（释放全部坏簇+清槽）\n");
        printf("  0) 退出\n");
        printf("  请选择："); my_flush();
        if(!fgets(b,sizeof b,stdin))break;
        v=atoi(b);
        switch(v){
        case 1: cmd_status(f); break;
        case 2: with_lock(phys,disknum,cmd_init,f); break;
        case 3: cmd_list(f); break;
        case 4: with_lock(phys,disknum,cmd_import,f); break;
        case 5: cmd_export(f); break;
        case 6: with_lock(phys,disknum,cmd_delete,f); break;
        case 7: with_lock(phys,disknum,cmd_wipe,f); break;
        case 0: loop=0; break;
        default: printf("  无效选项。\n"); break;
        }
    }
}

int main(int argc,char**argv)
{
    int disknum=-1; const char*image=NULL;
    FatDev d; Fat32 f={0}; char err[256];
    int is_write=1;

    SetConsoleOutputCP(CP_UTF8);
    setvbuf(stdout,NULL,_IONBF,0);
    setvbuf(stderr,NULL,_IONBF,0);
    SetConsoleCP(CP_UTF8);

    printf("fat1 —— FAT32 坏簇私有文件系统工具（方案二）\n");
    if(argc>1){
        if(_stricmp(argv[1],"-h")==0||_stricmp(argv[1],"--help")==0){usage();return 0;}
        if(isdigit((unsigned char)argv[1][0])&&strspn(argv[1],"0123456789")==strlen(argv[1]))
            disknum=atoi(argv[1]);
        else image=argv[1];
    }

    if(!image&&disknum<0){
        int count=0;
        printf("\n  可用物理磁盘：\n");
        list_disks(&count);
        if(count==0&&!running_elevated()){
            printf("\n  未以管理员运行且打不开磁盘。尝试提权……\n");
            if(relaunch_elevated(argc,argv)){
                printf("  UAC 提权窗口已弹出，请在弹窗中选“是”。\n");
                return 0;
            }
            printf("\n  请手动“右键→以管理员身份运行”。\n");
            return 1;
        }
        printf("  输入要操作的磁盘号：");
        {
            char bb[32];
            if(!g_line(bb,sizeof bb))return 0;
            disknum=atoi(bb);
        }
    }
    if(!image&&disknum<0){usage();return 0;}

    if(image){
        if(!fat_dev_open(&d,0,image,is_write,0))return 1;
        printf("  已打开镜像: %s (无需管理员)\n",image);
    } else {
        if(!fat_dev_open(&d,disknum,NULL,is_write,0)){
            if(!running_elevated()){
                printf("\n  未以管理员运行。尝试提权……\n");
                if(relaunch_elevated(argc,argv)){
                    printf("  UAC 提权窗口已弹出，请在弹窗中选“是”。\n");
                    return 0;
                }
            }
            printf("\n  若因权限失败，请右键以管理员身份运行。\n");
            return 1;
        }
    }
    if(d.total==0){printf("  设备长度未知。\n");fat_dev_close(&d);return 1;}

    if(!fat32_open(&d,&f,err,sizeof err)){
        printf("  %s\n",err);
        fat_dev_close(&d);
        return 1;
    }
    {
        char sz[32];
        fat_human(d.total,sz,sizeof sz);
        printf("  设备: %s   容量 %s   扇区 %lu 字节\n",d.title,sz,(unsigned long)d.sector);
    }
    if(!image){
        printf("  [提示] 每个写操作会自动短暂卸卷接管该分区卷，写完立即放回重挂(盘符保留)。\n");
    }
    g_isphys=image?0:1; g_disk=disknum; g_armed=0;

    show_menu(&f,disknum,image?1:0);

    fat_dev_close(&d);   /* 若有遗留的卷锁随句柄关闭一并释放 */
    printf("\n  再见。\n");
    return 0;
}
